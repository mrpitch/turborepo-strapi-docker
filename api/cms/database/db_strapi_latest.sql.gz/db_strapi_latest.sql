-- -------------------------------------------------------------
-- TablePlus 5.3.0(486)
--
-- https://tableplus.com/
--
-- Database: db_strapi
-- Generation Time: 2023-02-26 12:41:04.8180
-- -------------------------------------------------------------


DROP TABLE IF EXISTS "public"."admin_permissions";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS admin_permissions_id_seq;

-- Table Definition
CREATE TABLE "public"."admin_permissions" (
    "id" int4 NOT NULL DEFAULT nextval('admin_permissions_id_seq'::regclass),
    "action" varchar(255),
    "subject" varchar(255),
    "properties" jsonb,
    "conditions" jsonb,
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."admin_permissions_role_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS admin_permissions_role_links_id_seq;

-- Table Definition
CREATE TABLE "public"."admin_permissions_role_links" (
    "id" int4 NOT NULL DEFAULT nextval('admin_permissions_role_links_id_seq'::regclass),
    "permission_id" int4,
    "role_id" int4,
    "permission_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."admin_roles";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS admin_roles_id_seq;

-- Table Definition
CREATE TABLE "public"."admin_roles" (
    "id" int4 NOT NULL DEFAULT nextval('admin_roles_id_seq'::regclass),
    "name" varchar(255),
    "code" varchar(255),
    "description" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."admin_users";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS admin_users_id_seq;

-- Table Definition
CREATE TABLE "public"."admin_users" (
    "id" int4 NOT NULL DEFAULT nextval('admin_users_id_seq'::regclass),
    "firstname" varchar(255),
    "lastname" varchar(255),
    "username" varchar(255),
    "email" varchar(255),
    "password" varchar(255),
    "reset_password_token" varchar(255),
    "registration_token" varchar(255),
    "is_active" bool,
    "blocked" bool,
    "prefered_language" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."admin_users_roles_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS admin_users_roles_links_id_seq;

-- Table Definition
CREATE TABLE "public"."admin_users_roles_links" (
    "id" int4 NOT NULL DEFAULT nextval('admin_users_roles_links_id_seq'::regclass),
    "user_id" int4,
    "role_id" int4,
    "role_order" float8,
    "user_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."categories";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS categories_id_seq;

-- Table Definition
CREATE TABLE "public"."categories" (
    "id" int4 NOT NULL DEFAULT nextval('categories_id_seq'::regclass),
    "title" varchar(255),
    "slug" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "published_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_exercises_descriptions";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_exercises_descriptions_id_seq;

-- Table Definition
CREATE TABLE "public"."components_exercises_descriptions" (
    "id" int4 NOT NULL DEFAULT nextval('components_exercises_descriptions_id_seq'::regclass),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_exercises_descriptions_components";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_exercises_descriptions_components_id_seq;

-- Table Definition
CREATE TABLE "public"."components_exercises_descriptions_components" (
    "id" int4 NOT NULL DEFAULT nextval('components_exercises_descriptions_components_id_seq'::regclass),
    "entity_id" int4,
    "component_id" int4,
    "component_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_exercises_progressions";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_exercises_progressions_id_seq;

-- Table Definition
CREATE TABLE "public"."components_exercises_progressions" (
    "id" int4 NOT NULL DEFAULT nextval('components_exercises_progressions_id_seq'::regclass),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_exercises_progressions_components";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_exercises_progressions_components_id_seq;

-- Table Definition
CREATE TABLE "public"."components_exercises_progressions_components" (
    "id" int4 NOT NULL DEFAULT nextval('components_exercises_progressions_components_id_seq'::regclass),
    "entity_id" int4,
    "component_id" int4,
    "component_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_exercises_steps";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_exercises_steps_id_seq;

-- Table Definition
CREATE TABLE "public"."components_exercises_steps" (
    "id" int4 NOT NULL DEFAULT nextval('components_exercises_steps_id_seq'::regclass),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_exercises_steps_components";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_exercises_steps_components_id_seq;

-- Table Definition
CREATE TABLE "public"."components_exercises_steps_components" (
    "id" int4 NOT NULL DEFAULT nextval('components_exercises_steps_components_id_seq'::regclass),
    "entity_id" int4,
    "component_id" int4,
    "component_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_general_copy_sections";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_general_copy_sections_id_seq;

-- Table Definition
CREATE TABLE "public"."components_general_copy_sections" (
    "id" int4 NOT NULL DEFAULT nextval('components_general_copy_sections_id_seq'::regclass),
    "copy" text,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_general_image_text_sections";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_general_image_text_sections_id_seq;

-- Table Definition
CREATE TABLE "public"."components_general_image_text_sections" (
    "id" int4 NOT NULL DEFAULT nextval('components_general_image_text_sections_id_seq'::regclass),
    "copy" text,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_workout_days";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_workout_days_id_seq;

-- Table Definition
CREATE TABLE "public"."components_workout_days" (
    "id" int4 NOT NULL DEFAULT nextval('components_workout_days_id_seq'::regclass),
    "title" varchar(255),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_workout_days_components";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_workout_days_components_id_seq;

-- Table Definition
CREATE TABLE "public"."components_workout_days_components" (
    "id" int4 NOT NULL DEFAULT nextval('components_workout_days_components_id_seq'::regclass),
    "entity_id" int4,
    "component_id" int4,
    "component_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_workout_exercises";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_workout_exercises_id_seq;

-- Table Definition
CREATE TABLE "public"."components_workout_exercises" (
    "id" int4 NOT NULL DEFAULT nextval('components_workout_exercises_id_seq'::regclass),
    "sets" int4,
    "reps" int4,
    "title" varchar(255),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_workout_exercises_exercise_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_workout_exercises_exercise_links_id_seq;

-- Table Definition
CREATE TABLE "public"."components_workout_exercises_exercise_links" (
    "id" int4 NOT NULL DEFAULT nextval('components_workout_exercises_exercise_links_id_seq'::regclass),
    "exercise_id" int4,
    "inv_exercise_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."exercises";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS exercises_id_seq;

-- Table Definition
CREATE TABLE "public"."exercises" (
    "id" int4 NOT NULL DEFAULT nextval('exercises_id_seq'::regclass),
    "title" varchar(255),
    "slug" varchar(255),
    "purpose" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "published_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    "test" varchar(255),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."exercises_categories_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS exercises_categories_links_id_seq;

-- Table Definition
CREATE TABLE "public"."exercises_categories_links" (
    "id" int4 NOT NULL DEFAULT nextval('exercises_categories_links_id_seq'::regclass),
    "exercise_id" int4,
    "category_id" int4,
    "category_order" float8,
    "exercise_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."exercises_components";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS exercises_components_id_seq;

-- Table Definition
CREATE TABLE "public"."exercises_components" (
    "id" int4 NOT NULL DEFAULT nextval('exercises_components_id_seq'::regclass),
    "entity_id" int4,
    "component_id" int4,
    "component_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."files";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS files_id_seq;

-- Table Definition
CREATE TABLE "public"."files" (
    "id" int4 NOT NULL DEFAULT nextval('files_id_seq'::regclass),
    "name" varchar(255),
    "alternative_text" varchar(255),
    "caption" varchar(255),
    "width" int4,
    "height" int4,
    "formats" jsonb,
    "hash" varchar(255),
    "ext" varchar(255),
    "mime" varchar(255),
    "size" numeric(10,2),
    "url" varchar(255),
    "preview_url" varchar(255),
    "provider" varchar(255),
    "provider_metadata" jsonb,
    "folder_path" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."files_folder_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS files_folder_links_id_seq;

-- Table Definition
CREATE TABLE "public"."files_folder_links" (
    "id" int4 NOT NULL DEFAULT nextval('files_folder_links_id_seq'::regclass),
    "file_id" int4,
    "folder_id" int4,
    "file_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."files_related_morphs";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS files_related_morphs_id_seq;

-- Table Definition
CREATE TABLE "public"."files_related_morphs" (
    "id" int4 NOT NULL DEFAULT nextval('files_related_morphs_id_seq'::regclass),
    "file_id" int4,
    "related_id" int4,
    "related_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."i18n_locale";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS i18n_locale_id_seq;

-- Table Definition
CREATE TABLE "public"."i18n_locale" (
    "id" int4 NOT NULL DEFAULT nextval('i18n_locale_id_seq'::regclass),
    "name" varchar(255),
    "code" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_api_token_permissions";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_api_token_permissions_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_api_token_permissions" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_api_token_permissions_id_seq'::regclass),
    "action" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_api_token_permissions_token_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_api_token_permissions_token_links_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_api_token_permissions_token_links" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_api_token_permissions_token_links_id_seq'::regclass),
    "api_token_permission_id" int4,
    "api_token_id" int4,
    "api_token_permission_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_api_tokens";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_api_tokens_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_api_tokens" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_api_tokens_id_seq'::regclass),
    "name" varchar(255),
    "description" varchar(255),
    "type" varchar(255),
    "access_key" varchar(255),
    "last_used_at" timestamp,
    "expires_at" timestamp,
    "lifespan" int8,
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_core_store_settings";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_core_store_settings_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_core_store_settings" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_core_store_settings_id_seq'::regclass),
    "key" varchar(255),
    "value" text,
    "type" varchar(255),
    "environment" varchar(255),
    "tag" varchar(255),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_database_schema";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_database_schema_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_database_schema" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_database_schema_id_seq'::regclass),
    "schema" json,
    "time" timestamp,
    "hash" varchar(255),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_ee_store_settings";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_ee_store_settings_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_ee_store_settings" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_ee_store_settings_id_seq'::regclass),
    "key" varchar(255),
    "value" text,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_migrations";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_migrations_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_migrations" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_migrations_id_seq'::regclass),
    "name" varchar(255),
    "time" timestamp,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_webhooks";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_webhooks_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_webhooks" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_webhooks_id_seq'::regclass),
    "name" varchar(255),
    "url" text,
    "headers" jsonb,
    "events" jsonb,
    "enabled" bool,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."up_permissions";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS up_permissions_id_seq;

-- Table Definition
CREATE TABLE "public"."up_permissions" (
    "id" int4 NOT NULL DEFAULT nextval('up_permissions_id_seq'::regclass),
    "action" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."up_permissions_role_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS up_permissions_role_links_id_seq;

-- Table Definition
CREATE TABLE "public"."up_permissions_role_links" (
    "id" int4 NOT NULL DEFAULT nextval('up_permissions_role_links_id_seq'::regclass),
    "permission_id" int4,
    "role_id" int4,
    "permission_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."up_roles";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS up_roles_id_seq;

-- Table Definition
CREATE TABLE "public"."up_roles" (
    "id" int4 NOT NULL DEFAULT nextval('up_roles_id_seq'::regclass),
    "name" varchar(255),
    "description" varchar(255),
    "type" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."up_users";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS up_users_id_seq;

-- Table Definition
CREATE TABLE "public"."up_users" (
    "id" int4 NOT NULL DEFAULT nextval('up_users_id_seq'::regclass),
    "username" varchar(255),
    "email" varchar(255),
    "provider" varchar(255),
    "password" varchar(255),
    "reset_password_token" varchar(255),
    "confirmation_token" varchar(255),
    "confirmed" bool,
    "blocked" bool,
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."up_users_role_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS up_users_role_links_id_seq;

-- Table Definition
CREATE TABLE "public"."up_users_role_links" (
    "id" int4 NOT NULL DEFAULT nextval('up_users_role_links_id_seq'::regclass),
    "user_id" int4,
    "role_id" int4,
    "user_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."upload_folders";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS upload_folders_id_seq;

-- Table Definition
CREATE TABLE "public"."upload_folders" (
    "id" int4 NOT NULL DEFAULT nextval('upload_folders_id_seq'::regclass),
    "name" varchar(255),
    "path_id" int4,
    "path" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."upload_folders_parent_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS upload_folders_parent_links_id_seq;

-- Table Definition
CREATE TABLE "public"."upload_folders_parent_links" (
    "id" int4 NOT NULL DEFAULT nextval('upload_folders_parent_links_id_seq'::regclass),
    "folder_id" int4,
    "inv_folder_id" int4,
    "folder_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."workouts";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS workouts_id_seq;

-- Table Definition
CREATE TABLE "public"."workouts" (
    "id" int4 NOT NULL DEFAULT nextval('workouts_id_seq'::regclass),
    "title" varchar(255),
    "slug" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "published_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."workouts_components";
-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS workouts_components_id_seq;

-- Table Definition
CREATE TABLE "public"."workouts_components" (
    "id" int4 NOT NULL DEFAULT nextval('workouts_components_id_seq'::regclass),
    "entity_id" int4,
    "component_id" int4,
    "component_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

INSERT INTO "public"."admin_permissions" ("id", "action", "subject", "properties", "conditions", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(1, 'plugin::content-manager.explorer.create', 'api::category.category', '{"fields": ["title", "slug", "exercises"]}', '[]', '2023-02-02 14:47:03.629', '2023-02-02 14:47:03.629', NULL, NULL),
(2, 'plugin::content-manager.explorer.create', 'api::exercise.exercise', '{"fields": ["title", "slug", "purpose", "thumbnail", "Body", "categories"]}', '[]', '2023-02-02 14:47:03.647', '2023-02-02 14:47:03.647', NULL, NULL),
(3, 'plugin::content-manager.explorer.create', 'api::workout.workout', '{"fields": ["title", "day.title", "day.day.exercise", "day.day.sets", "day.day.reps", "day.day.title", "slug"]}', '[]', '2023-02-02 14:47:03.66', '2023-02-02 14:47:03.66', NULL, NULL),
(4, 'plugin::content-manager.explorer.read', 'api::category.category', '{"fields": ["title", "slug", "exercises"]}', '[]', '2023-02-02 14:47:03.67', '2023-02-02 14:47:03.67', NULL, NULL),
(5, 'plugin::content-manager.explorer.read', 'api::exercise.exercise', '{"fields": ["title", "slug", "purpose", "thumbnail", "Body", "categories"]}', '[]', '2023-02-02 14:47:03.683', '2023-02-02 14:47:03.683', NULL, NULL),
(6, 'plugin::content-manager.explorer.read', 'api::workout.workout', '{"fields": ["title", "day.title", "day.day.exercise", "day.day.sets", "day.day.reps", "day.day.title", "slug"]}', '[]', '2023-02-02 14:47:03.695', '2023-02-02 14:47:03.695', NULL, NULL),
(7, 'plugin::content-manager.explorer.update', 'api::category.category', '{"fields": ["title", "slug", "exercises"]}', '[]', '2023-02-02 14:47:03.706', '2023-02-02 14:47:03.706', NULL, NULL),
(8, 'plugin::content-manager.explorer.update', 'api::exercise.exercise', '{"fields": ["title", "slug", "purpose", "thumbnail", "Body", "categories"]}', '[]', '2023-02-02 14:47:03.716', '2023-02-02 14:47:03.716', NULL, NULL),
(9, 'plugin::content-manager.explorer.update', 'api::workout.workout', '{"fields": ["title", "day.title", "day.day.exercise", "day.day.sets", "day.day.reps", "day.day.title", "slug"]}', '[]', '2023-02-02 14:47:03.728', '2023-02-02 14:47:03.728', NULL, NULL),
(10, 'plugin::content-manager.explorer.delete', 'api::category.category', '{}', '[]', '2023-02-02 14:47:03.738', '2023-02-02 14:47:03.738', NULL, NULL),
(11, 'plugin::content-manager.explorer.delete', 'api::exercise.exercise', '{}', '[]', '2023-02-02 14:47:03.749', '2023-02-02 14:47:03.749', NULL, NULL),
(12, 'plugin::content-manager.explorer.delete', 'api::workout.workout', '{}', '[]', '2023-02-02 14:47:03.759', '2023-02-02 14:47:03.759', NULL, NULL),
(13, 'plugin::content-manager.explorer.publish', 'api::category.category', '{}', '[]', '2023-02-02 14:47:03.769', '2023-02-02 14:47:03.769', NULL, NULL),
(14, 'plugin::content-manager.explorer.publish', 'api::exercise.exercise', '{}', '[]', '2023-02-02 14:47:03.78', '2023-02-02 14:47:03.78', NULL, NULL),
(15, 'plugin::content-manager.explorer.publish', 'api::workout.workout', '{}', '[]', '2023-02-02 14:47:03.79', '2023-02-02 14:47:03.79', NULL, NULL),
(16, 'plugin::upload.read', NULL, '{}', '[]', '2023-02-02 14:47:03.799', '2023-02-02 14:47:03.799', NULL, NULL),
(17, 'plugin::upload.configure-view', NULL, '{}', '[]', '2023-02-02 14:47:03.81', '2023-02-02 14:47:03.81', NULL, NULL),
(18, 'plugin::upload.assets.create', NULL, '{}', '[]', '2023-02-02 14:47:03.819', '2023-02-02 14:47:03.819', NULL, NULL),
(19, 'plugin::upload.assets.update', NULL, '{}', '[]', '2023-02-02 14:47:03.829', '2023-02-02 14:47:03.829', NULL, NULL),
(20, 'plugin::upload.assets.download', NULL, '{}', '[]', '2023-02-02 14:47:03.838', '2023-02-02 14:47:03.838', NULL, NULL),
(21, 'plugin::upload.assets.copy-link', NULL, '{}', '[]', '2023-02-02 14:47:03.849', '2023-02-02 14:47:03.849', NULL, NULL),
(22, 'plugin::content-manager.explorer.create', 'api::category.category', '{"fields": ["title", "slug", "exercises"]}', '["admin::is-creator"]', '2023-02-02 14:47:03.86', '2023-02-02 14:47:03.86', NULL, NULL),
(23, 'plugin::content-manager.explorer.create', 'api::exercise.exercise', '{"fields": ["title", "slug", "purpose", "thumbnail", "Body", "categories"]}', '["admin::is-creator"]', '2023-02-02 14:47:03.87', '2023-02-02 14:47:03.87', NULL, NULL),
(24, 'plugin::content-manager.explorer.create', 'api::workout.workout', '{"fields": ["title", "day.title", "day.day.exercise", "day.day.sets", "day.day.reps", "day.day.title", "slug"]}', '["admin::is-creator"]', '2023-02-02 14:47:03.879', '2023-02-02 14:47:03.879', NULL, NULL),
(25, 'plugin::content-manager.explorer.read', 'api::category.category', '{"fields": ["title", "slug", "exercises"]}', '["admin::is-creator"]', '2023-02-02 14:47:03.887', '2023-02-02 14:47:03.887', NULL, NULL),
(26, 'plugin::content-manager.explorer.read', 'api::exercise.exercise', '{"fields": ["title", "slug", "purpose", "thumbnail", "Body", "categories"]}', '["admin::is-creator"]', '2023-02-02 14:47:03.896', '2023-02-02 14:47:03.896', NULL, NULL),
(27, 'plugin::content-manager.explorer.read', 'api::workout.workout', '{"fields": ["title", "day.title", "day.day.exercise", "day.day.sets", "day.day.reps", "day.day.title", "slug"]}', '["admin::is-creator"]', '2023-02-02 14:47:03.905', '2023-02-02 14:47:03.905', NULL, NULL),
(28, 'plugin::content-manager.explorer.update', 'api::category.category', '{"fields": ["title", "slug", "exercises"]}', '["admin::is-creator"]', '2023-02-02 14:47:03.914', '2023-02-02 14:47:03.914', NULL, NULL),
(29, 'plugin::content-manager.explorer.update', 'api::exercise.exercise', '{"fields": ["title", "slug", "purpose", "thumbnail", "Body", "categories"]}', '["admin::is-creator"]', '2023-02-02 14:47:03.924', '2023-02-02 14:47:03.924', NULL, NULL),
(30, 'plugin::content-manager.explorer.update', 'api::workout.workout', '{"fields": ["title", "day.title", "day.day.exercise", "day.day.sets", "day.day.reps", "day.day.title", "slug"]}', '["admin::is-creator"]', '2023-02-02 14:47:03.933', '2023-02-02 14:47:03.933', NULL, NULL),
(31, 'plugin::content-manager.explorer.delete', 'api::category.category', '{}', '["admin::is-creator"]', '2023-02-02 14:47:03.943', '2023-02-02 14:47:03.943', NULL, NULL),
(32, 'plugin::content-manager.explorer.delete', 'api::exercise.exercise', '{}', '["admin::is-creator"]', '2023-02-02 14:47:03.952', '2023-02-02 14:47:03.952', NULL, NULL),
(33, 'plugin::content-manager.explorer.delete', 'api::workout.workout', '{}', '["admin::is-creator"]', '2023-02-02 14:47:03.961', '2023-02-02 14:47:03.961', NULL, NULL),
(34, 'plugin::upload.read', NULL, '{}', '["admin::is-creator"]', '2023-02-02 14:47:03.971', '2023-02-02 14:47:03.971', NULL, NULL),
(35, 'plugin::upload.configure-view', NULL, '{}', '[]', '2023-02-02 14:47:03.981', '2023-02-02 14:47:03.981', NULL, NULL),
(36, 'plugin::upload.assets.create', NULL, '{}', '[]', '2023-02-02 14:47:03.99', '2023-02-02 14:47:03.99', NULL, NULL),
(37, 'plugin::upload.assets.update', NULL, '{}', '["admin::is-creator"]', '2023-02-02 14:47:03.999', '2023-02-02 14:47:03.999', NULL, NULL),
(38, 'plugin::upload.assets.download', NULL, '{}', '[]', '2023-02-02 14:47:04.01', '2023-02-02 14:47:04.01', NULL, NULL),
(39, 'plugin::upload.assets.copy-link', NULL, '{}', '[]', '2023-02-02 14:47:04.02', '2023-02-02 14:47:04.02', NULL, NULL),
(40, 'plugin::content-manager.explorer.create', 'plugin::users-permissions.user', '{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role"]}', '[]', '2023-02-02 14:47:04.062', '2023-02-02 14:47:04.062', NULL, NULL),
(41, 'plugin::content-manager.explorer.create', 'api::category.category', '{"fields": ["title", "slug", "exercises"]}', '[]', '2023-02-02 14:47:04.077', '2023-02-02 14:47:04.077', NULL, NULL),
(43, 'plugin::content-manager.explorer.create', 'api::workout.workout', '{"fields": ["title", "day.title", "day.day.exercise", "day.day.sets", "day.day.reps", "day.day.title", "slug"]}', '[]', '2023-02-02 14:47:04.106', '2023-02-02 14:47:04.106', NULL, NULL),
(44, 'plugin::content-manager.explorer.read', 'plugin::users-permissions.user', '{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role"]}', '[]', '2023-02-02 14:47:04.121', '2023-02-02 14:47:04.121', NULL, NULL),
(45, 'plugin::content-manager.explorer.read', 'api::category.category', '{"fields": ["title", "slug", "exercises"]}', '[]', '2023-02-02 14:47:04.132', '2023-02-02 14:47:04.132', NULL, NULL),
(47, 'plugin::content-manager.explorer.read', 'api::workout.workout', '{"fields": ["title", "day.title", "day.day.exercise", "day.day.sets", "day.day.reps", "day.day.title", "slug"]}', '[]', '2023-02-02 14:47:04.152', '2023-02-02 14:47:04.152', NULL, NULL),
(48, 'plugin::content-manager.explorer.update', 'plugin::users-permissions.user', '{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role"]}', '[]', '2023-02-02 14:47:04.164', '2023-02-02 14:47:04.164', NULL, NULL),
(49, 'plugin::content-manager.explorer.update', 'api::category.category', '{"fields": ["title", "slug", "exercises"]}', '[]', '2023-02-02 14:47:04.175', '2023-02-02 14:47:04.175', NULL, NULL),
(51, 'plugin::content-manager.explorer.update', 'api::workout.workout', '{"fields": ["title", "day.title", "day.day.exercise", "day.day.sets", "day.day.reps", "day.day.title", "slug"]}', '[]', '2023-02-02 14:47:04.197', '2023-02-02 14:47:04.197', NULL, NULL),
(52, 'plugin::content-manager.explorer.delete', 'plugin::users-permissions.user', '{}', '[]', '2023-02-02 14:47:04.207', '2023-02-02 14:47:04.207', NULL, NULL),
(53, 'plugin::content-manager.explorer.delete', 'api::category.category', '{}', '[]', '2023-02-02 14:47:04.217', '2023-02-02 14:47:04.217', NULL, NULL),
(54, 'plugin::content-manager.explorer.delete', 'api::exercise.exercise', '{}', '[]', '2023-02-02 14:47:04.228', '2023-02-02 14:47:04.228', NULL, NULL),
(55, 'plugin::content-manager.explorer.delete', 'api::workout.workout', '{}', '[]', '2023-02-02 14:47:04.24', '2023-02-02 14:47:04.24', NULL, NULL),
(56, 'plugin::content-manager.explorer.publish', 'api::category.category', '{}', '[]', '2023-02-02 14:47:04.252', '2023-02-02 14:47:04.252', NULL, NULL),
(57, 'plugin::content-manager.explorer.publish', 'api::exercise.exercise', '{}', '[]', '2023-02-02 14:47:04.263', '2023-02-02 14:47:04.263', NULL, NULL),
(58, 'plugin::content-manager.explorer.publish', 'api::workout.workout', '{}', '[]', '2023-02-02 14:47:04.274', '2023-02-02 14:47:04.274', NULL, NULL),
(59, 'plugin::content-manager.single-types.configure-view', NULL, '{}', '[]', '2023-02-02 14:47:04.285', '2023-02-02 14:47:04.285', NULL, NULL),
(60, 'plugin::content-manager.collection-types.configure-view', NULL, '{}', '[]', '2023-02-02 14:47:04.294', '2023-02-02 14:47:04.294', NULL, NULL),
(61, 'plugin::content-manager.components.configure-layout', NULL, '{}', '[]', '2023-02-02 14:47:04.304', '2023-02-02 14:47:04.304', NULL, NULL),
(62, 'plugin::content-type-builder.read', NULL, '{}', '[]', '2023-02-02 14:47:04.314', '2023-02-02 14:47:04.314', NULL, NULL),
(63, 'plugin::email.settings.read', NULL, '{}', '[]', '2023-02-02 14:47:04.323', '2023-02-02 14:47:04.323', NULL, NULL),
(64, 'plugin::upload.read', NULL, '{}', '[]', '2023-02-02 14:47:04.337', '2023-02-02 14:47:04.337', NULL, NULL),
(65, 'plugin::upload.assets.create', NULL, '{}', '[]', '2023-02-02 14:47:04.348', '2023-02-02 14:47:04.348', NULL, NULL),
(66, 'plugin::upload.assets.update', NULL, '{}', '[]', '2023-02-02 14:47:04.358', '2023-02-02 14:47:04.358', NULL, NULL),
(67, 'plugin::upload.assets.download', NULL, '{}', '[]', '2023-02-02 14:47:04.367', '2023-02-02 14:47:04.367', NULL, NULL),
(68, 'plugin::upload.assets.copy-link', NULL, '{}', '[]', '2023-02-02 14:47:04.376', '2023-02-02 14:47:04.376', NULL, NULL),
(69, 'plugin::upload.configure-view', NULL, '{}', '[]', '2023-02-02 14:47:04.386', '2023-02-02 14:47:04.386', NULL, NULL),
(70, 'plugin::upload.settings.read', NULL, '{}', '[]', '2023-02-02 14:47:04.396', '2023-02-02 14:47:04.396', NULL, NULL),
(71, 'plugin::i18n.locale.create', NULL, '{}', '[]', '2023-02-02 14:47:04.407', '2023-02-02 14:47:04.407', NULL, NULL),
(72, 'plugin::i18n.locale.read', NULL, '{}', '[]', '2023-02-02 14:47:04.416', '2023-02-02 14:47:04.416', NULL, NULL),
(73, 'plugin::i18n.locale.update', NULL, '{}', '[]', '2023-02-02 14:47:04.428', '2023-02-02 14:47:04.428', NULL, NULL),
(74, 'plugin::i18n.locale.delete', NULL, '{}', '[]', '2023-02-02 14:47:04.438', '2023-02-02 14:47:04.438', NULL, NULL),
(75, 'plugin::users-permissions.roles.create', NULL, '{}', '[]', '2023-02-02 14:47:04.449', '2023-02-02 14:47:04.449', NULL, NULL),
(76, 'plugin::users-permissions.roles.read', NULL, '{}', '[]', '2023-02-02 14:47:04.462', '2023-02-02 14:47:04.462', NULL, NULL),
(77, 'plugin::users-permissions.roles.update', NULL, '{}', '[]', '2023-02-02 14:47:04.471', '2023-02-02 14:47:04.471', NULL, NULL),
(78, 'plugin::users-permissions.roles.delete', NULL, '{}', '[]', '2023-02-02 14:47:04.481', '2023-02-02 14:47:04.481', NULL, NULL),
(79, 'plugin::users-permissions.providers.read', NULL, '{}', '[]', '2023-02-02 14:47:04.49', '2023-02-02 14:47:04.49', NULL, NULL),
(80, 'plugin::users-permissions.providers.update', NULL, '{}', '[]', '2023-02-02 14:47:04.5', '2023-02-02 14:47:04.5', NULL, NULL),
(81, 'plugin::users-permissions.email-templates.read', NULL, '{}', '[]', '2023-02-02 14:47:04.51', '2023-02-02 14:47:04.51', NULL, NULL),
(82, 'plugin::users-permissions.email-templates.update', NULL, '{}', '[]', '2023-02-02 14:47:04.52', '2023-02-02 14:47:04.52', NULL, NULL),
(83, 'plugin::users-permissions.advanced-settings.read', NULL, '{}', '[]', '2023-02-02 14:47:04.534', '2023-02-02 14:47:04.534', NULL, NULL),
(84, 'plugin::users-permissions.advanced-settings.update', NULL, '{}', '[]', '2023-02-02 14:47:04.553', '2023-02-02 14:47:04.553', NULL, NULL),
(85, 'admin::marketplace.read', NULL, '{}', '[]', '2023-02-02 14:47:04.567', '2023-02-02 14:47:04.567', NULL, NULL),
(88, 'admin::webhooks.create', NULL, '{}', '[]', '2023-02-02 14:47:04.598', '2023-02-02 14:47:04.598', NULL, NULL),
(89, 'admin::webhooks.read', NULL, '{}', '[]', '2023-02-02 14:47:04.608', '2023-02-02 14:47:04.608', NULL, NULL),
(90, 'admin::webhooks.update', NULL, '{}', '[]', '2023-02-02 14:47:04.617', '2023-02-02 14:47:04.617', NULL, NULL),
(91, 'admin::webhooks.delete', NULL, '{}', '[]', '2023-02-02 14:47:04.627', '2023-02-02 14:47:04.627', NULL, NULL),
(92, 'admin::users.create', NULL, '{}', '[]', '2023-02-02 14:47:04.636', '2023-02-02 14:47:04.636', NULL, NULL),
(93, 'admin::users.read', NULL, '{}', '[]', '2023-02-02 14:47:04.647', '2023-02-02 14:47:04.647', NULL, NULL),
(94, 'admin::users.update', NULL, '{}', '[]', '2023-02-02 14:47:04.657', '2023-02-02 14:47:04.657', NULL, NULL),
(95, 'admin::users.delete', NULL, '{}', '[]', '2023-02-02 14:47:04.667', '2023-02-02 14:47:04.667', NULL, NULL),
(96, 'admin::roles.create', NULL, '{}', '[]', '2023-02-02 14:47:04.677', '2023-02-02 14:47:04.677', NULL, NULL),
(97, 'admin::roles.read', NULL, '{}', '[]', '2023-02-02 14:47:04.688', '2023-02-02 14:47:04.688', NULL, NULL),
(98, 'admin::roles.update', NULL, '{}', '[]', '2023-02-02 14:47:04.698', '2023-02-02 14:47:04.698', NULL, NULL),
(99, 'admin::roles.delete', NULL, '{}', '[]', '2023-02-02 14:47:04.708', '2023-02-02 14:47:04.708', NULL, NULL),
(100, 'admin::api-tokens.access', NULL, '{}', '[]', '2023-02-02 14:47:04.718', '2023-02-02 14:47:04.718', NULL, NULL),
(101, 'admin::api-tokens.create', NULL, '{}', '[]', '2023-02-02 14:47:04.729', '2023-02-02 14:47:04.729', NULL, NULL),
(102, 'admin::api-tokens.read', NULL, '{}', '[]', '2023-02-02 14:47:04.74', '2023-02-02 14:47:04.74', NULL, NULL),
(103, 'admin::api-tokens.update', NULL, '{}', '[]', '2023-02-02 14:47:04.75', '2023-02-02 14:47:04.75', NULL, NULL),
(104, 'admin::api-tokens.regenerate', NULL, '{}', '[]', '2023-02-02 14:47:04.762', '2023-02-02 14:47:04.762', NULL, NULL),
(105, 'admin::api-tokens.delete', NULL, '{}', '[]', '2023-02-02 14:47:04.833', '2023-02-02 14:47:04.833', NULL, NULL),
(106, 'admin::project-settings.update', NULL, '{}', '[]', '2023-02-02 14:47:04.912', '2023-02-02 14:47:04.912', NULL, NULL),
(107, 'admin::project-settings.read', NULL, '{}', '[]', '2023-02-02 14:47:04.945', '2023-02-02 14:47:04.945', NULL, NULL),
(110, 'plugin::content-manager.explorer.create', 'api::exercise.exercise', '{"fields": ["title", "slug", "purpose", "thumbnail", "Body", "categories", "test"]}', '[]', '2023-02-26 12:21:34.043', '2023-02-26 12:21:34.043', NULL, NULL),
(111, 'plugin::content-manager.explorer.read', 'api::exercise.exercise', '{"fields": ["title", "slug", "purpose", "thumbnail", "Body", "categories", "test"]}', '[]', '2023-02-26 12:21:34.059', '2023-02-26 12:21:34.059', NULL, NULL),
(112, 'plugin::content-manager.explorer.update', 'api::exercise.exercise', '{"fields": ["title", "slug", "purpose", "thumbnail", "Body", "categories", "test"]}', '[]', '2023-02-26 12:21:34.07', '2023-02-26 12:21:34.07', NULL, NULL);

INSERT INTO "public"."admin_permissions_role_links" ("id", "permission_id", "role_id", "permission_order") VALUES
(1, 1, 2, 1),
(2, 2, 2, 2),
(3, 3, 2, 3),
(4, 4, 2, 4),
(5, 5, 2, 5),
(6, 6, 2, 6),
(7, 7, 2, 7),
(8, 8, 2, 8),
(9, 9, 2, 9),
(10, 10, 2, 10),
(11, 11, 2, 11),
(12, 12, 2, 12),
(13, 13, 2, 13),
(14, 14, 2, 14),
(15, 15, 2, 15),
(16, 16, 2, 16),
(17, 17, 2, 17),
(18, 18, 2, 18),
(19, 19, 2, 19),
(20, 20, 2, 20),
(21, 21, 2, 21),
(22, 22, 3, 1),
(23, 23, 3, 2),
(24, 24, 3, 3),
(25, 25, 3, 4),
(26, 26, 3, 5),
(27, 27, 3, 6),
(28, 28, 3, 7),
(29, 29, 3, 8),
(30, 30, 3, 9),
(31, 31, 3, 10),
(32, 32, 3, 11),
(33, 33, 3, 12),
(34, 34, 3, 13),
(35, 35, 3, 14),
(36, 36, 3, 15),
(37, 37, 3, 16),
(38, 38, 3, 17),
(39, 39, 3, 18),
(40, 40, 1, 1),
(41, 41, 1, 2),
(43, 43, 1, 4),
(44, 44, 1, 5),
(45, 45, 1, 6),
(47, 47, 1, 8),
(48, 48, 1, 9),
(49, 49, 1, 10),
(51, 51, 1, 12),
(52, 52, 1, 13),
(53, 53, 1, 14),
(54, 54, 1, 15),
(55, 55, 1, 16),
(56, 56, 1, 17),
(57, 57, 1, 18),
(58, 58, 1, 19),
(59, 59, 1, 20),
(60, 60, 1, 21),
(61, 61, 1, 22),
(62, 62, 1, 23),
(63, 63, 1, 24),
(64, 64, 1, 25),
(65, 65, 1, 26),
(66, 66, 1, 27),
(67, 67, 1, 28),
(68, 68, 1, 29),
(69, 69, 1, 30),
(70, 70, 1, 31),
(71, 71, 1, 32),
(72, 72, 1, 33),
(73, 73, 1, 34),
(74, 74, 1, 35),
(75, 75, 1, 36),
(76, 76, 1, 37),
(77, 77, 1, 38),
(78, 78, 1, 39),
(79, 79, 1, 40),
(80, 80, 1, 41),
(81, 81, 1, 42),
(82, 82, 1, 43),
(83, 83, 1, 44),
(84, 84, 1, 45),
(85, 85, 1, 46),
(88, 88, 1, 49),
(89, 89, 1, 50),
(90, 90, 1, 51),
(91, 91, 1, 52),
(92, 92, 1, 53),
(93, 93, 1, 54),
(94, 94, 1, 55),
(95, 95, 1, 56),
(96, 96, 1, 57),
(97, 97, 1, 58),
(98, 98, 1, 59),
(99, 99, 1, 60),
(100, 100, 1, 61),
(101, 101, 1, 62),
(102, 102, 1, 63),
(103, 103, 1, 64),
(104, 104, 1, 65),
(105, 105, 1, 66),
(106, 106, 1, 67),
(107, 107, 1, 68),
(109, 110, 1, 69),
(110, 111, 1, 70),
(111, 112, 1, 71);

INSERT INTO "public"."admin_roles" ("id", "name", "code", "description", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(1, 'Super Admin', 'strapi-super-admin', 'Super Admins can access and manage all features and settings.', '2023-02-02 14:47:03.595', '2023-02-02 14:47:03.595', NULL, NULL),
(2, 'Editor', 'strapi-editor', 'Editors can manage and publish contents including those of other users.', '2023-02-02 14:47:03.609', '2023-02-02 14:47:03.609', NULL, NULL),
(3, 'Author', 'strapi-author', 'Authors can manage the content they have created.', '2023-02-02 14:47:03.618', '2023-02-02 14:47:03.618', NULL, NULL);

INSERT INTO "public"."admin_users" ("id", "firstname", "lastname", "username", "email", "password", "reset_password_token", "registration_token", "is_active", "blocked", "prefered_language", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(1, 'Magnus', 'Volkmann', NULL, 'volkmann.magnus@gmail.com', '$2a$10$GwiZsuTpsCXfFMJw2ZT3JegQPJSOtjt4kXq0QfsDb98w3FwrkQ0eG', NULL, NULL, 't', 'f', NULL, '2023-02-02 14:47:48.215', '2023-02-02 14:47:48.215', NULL, NULL);

INSERT INTO "public"."admin_users_roles_links" ("id", "user_id", "role_id", "role_order", "user_order") VALUES
(1, 1, 1, 1, 1);

INSERT INTO "public"."categories" ("id", "title", "slug", "created_at", "updated_at", "published_at", "created_by_id", "updated_by_id") VALUES
(1, 'Mobility', 'mobility', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1),
(2, 'Stability', 'stability', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1),
(3, 'Strength', 'strength', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1),
(4, 'Ankle & Foot', 'ankle-and-foot', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.694', 1, 1),
(5, 'Knee', 'knee', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1),
(6, 'Hips', 'hips', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1),
(7, 'Spine', 'spine', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1),
(8, 'Neck & Head', 'neck-and-head', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1),
(9, 'Shoulder', 'shoulder', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1),
(10, 'Elbow', 'elbow', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1),
(11, 'Wrist & Hand', 'wrist-and-hand', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1),
(12, 'Warm Up', 'warm-up', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1);

INSERT INTO "public"."components_exercises_descriptions" ("id") VALUES
(1),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18),
(19),
(20),
(21),
(22),
(23),
(24);

INSERT INTO "public"."components_exercises_descriptions_components" ("id", "entity_id", "component_id", "component_type", "field", "order") VALUES
(4, 4, 4, 'general.copy-section', 'description', 1),
(5, 5, 5, 'general.copy-section', 'description', 1),
(6, 6, 6, 'general.copy-section', 'description', 1),
(7, 7, 7, 'general.copy-section', 'description', 1),
(8, 8, 8, 'general.copy-section', 'description', 1),
(9, 9, 9, 'general.copy-section', 'description', 1),
(10, 10, 10, 'general.copy-section', 'description', 1),
(11, 11, 11, 'general.copy-section', 'description', 1),
(12, 12, 12, 'general.copy-section', 'description', 1),
(13, 13, 13, 'general.copy-section', 'description', 1),
(14, 14, 14, 'general.copy-section', 'description', 1),
(15, 15, 15, 'general.copy-section', 'description', 1),
(16, 16, 16, 'general.copy-section', 'description', 1),
(17, 17, 17, 'general.copy-section', 'description', 1),
(18, 18, 18, 'general.copy-section', 'description', 1),
(19, 19, 19, 'general.copy-section', 'description', 1),
(20, 20, 20, 'general.copy-section', 'description', 1),
(21, 21, 21, 'general.copy-section', 'description', 1),
(23, 22, 22, 'general.copy-section', 'description', 1),
(24, 23, 23, 'general.copy-section', 'description', 1),
(25, 24, 24, 'general.copy-section', 'description', 1),
(26, 3, 3, 'general.copy-section', 'description', 1),
(27, 1, 1, 'general.copy-section', 'description', 1);

INSERT INTO "public"."components_exercises_progressions" ("id") VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16);

INSERT INTO "public"."components_exercises_progressions_components" ("id", "entity_id", "component_id", "component_type", "field", "order") VALUES
(1, 1, 3, 'general.image-text-section', 'progressions', 1),
(2, 1, 4, 'general.image-text-section', 'progressions', 2),
(7, 4, 21, 'general.image-text-section', 'progressions', 1),
(8, 4, 22, 'general.image-text-section', 'progressions', 2),
(9, 5, 26, 'general.image-text-section', 'progressions', 1),
(10, 6, 29, 'general.image-text-section', 'progressions', 1),
(11, 7, 32, 'general.image-text-section', 'progressions', 1),
(12, 7, 33, 'general.image-text-section', 'progressions', 2),
(13, 8, 40, 'general.image-text-section', 'progressions', 1),
(14, 8, 41, 'general.image-text-section', 'progressions', 2),
(15, 9, 44, 'general.image-text-section', 'progressions', 1),
(16, 9, 45, 'general.image-text-section', 'progressions', 2),
(17, 10, 54, 'general.image-text-section', 'progressions', 1),
(18, 10, 55, 'general.image-text-section', 'progressions', 2),
(19, 11, 58, 'general.image-text-section', 'progressions', 1),
(20, 12, 61, 'general.image-text-section', 'progressions', 1),
(21, 13, 78, 'general.image-text-section', 'progressions', 1),
(22, 14, 90, 'general.image-text-section', 'progressions', 1),
(23, 15, 93, 'general.image-text-section', 'progressions', 1),
(24, 15, 94, 'general.image-text-section', 'progressions', 2),
(25, 16, 105, 'general.image-text-section', 'progressions', 1),
(26, 2, 9, 'general.image-text-section', 'progressions', 1),
(27, 2, 10, 'general.image-text-section', 'progressions', 2),
(28, 3, 15, 'general.image-text-section', 'progressions', 1),
(29, 3, 16, 'general.image-text-section', 'progressions', 2);

INSERT INTO "public"."components_exercises_steps" ("id") VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18),
(19),
(20),
(21),
(22),
(23),
(24),
(25),
(26),
(27),
(28),
(29),
(30),
(31),
(32),
(33),
(34),
(35),
(36);

INSERT INTO "public"."components_exercises_steps_components" ("id", "entity_id", "component_id", "component_type", "field", "order") VALUES
(1, 1, 1, 'general.image-text-section', 'steps', 1),
(2, 1, 2, 'general.image-text-section', 'steps', 2),
(17, 5, 19, 'general.image-text-section', 'steps', 1),
(18, 5, 20, 'general.image-text-section', 'steps', 2),
(22, 6, 23, 'general.image-text-section', 'steps', 1),
(23, 6, 24, 'general.image-text-section', 'steps', 2),
(24, 6, 25, 'general.image-text-section', 'steps', 3),
(25, 7, 27, 'general.image-text-section', 'steps', 1),
(26, 7, 28, 'general.image-text-section', 'steps', 2),
(27, 8, 30, 'general.image-text-section', 'steps', 1),
(28, 8, 31, 'general.image-text-section', 'steps', 2),
(29, 9, 34, 'general.image-text-section', 'steps', 1),
(30, 9, 35, 'general.image-text-section', 'steps', 2),
(31, 10, 36, 'general.image-text-section', 'steps', 1),
(32, 10, 37, 'general.image-text-section', 'steps', 2),
(33, 11, 38, 'general.image-text-section', 'steps', 1),
(34, 11, 39, 'general.image-text-section', 'steps', 2),
(35, 12, 42, 'general.image-text-section', 'steps', 1),
(36, 12, 43, 'general.image-text-section', 'steps', 2),
(37, 13, 46, 'general.image-text-section', 'steps', 1),
(38, 13, 47, 'general.image-text-section', 'steps', 2),
(39, 13, 48, 'general.image-text-section', 'steps', 3),
(40, 14, 49, 'general.image-text-section', 'steps', 1),
(41, 14, 50, 'general.image-text-section', 'steps', 2),
(42, 14, 51, 'general.image-text-section', 'steps', 3),
(43, 15, 52, 'general.image-text-section', 'steps', 1),
(44, 15, 53, 'general.image-text-section', 'steps', 2),
(45, 16, 56, 'general.image-text-section', 'steps', 1),
(46, 16, 57, 'general.image-text-section', 'steps', 2),
(47, 17, 59, 'general.image-text-section', 'steps', 1),
(48, 17, 60, 'general.image-text-section', 'steps', 2),
(49, 18, 62, 'general.image-text-section', 'steps', 1),
(50, 18, 63, 'general.image-text-section', 'steps', 2),
(51, 18, 64, 'general.image-text-section', 'steps', 3),
(52, 18, 65, 'general.image-text-section', 'steps', 4),
(53, 18, 66, 'general.image-text-section', 'steps', 5),
(54, 18, 67, 'general.image-text-section', 'steps', 6),
(55, 18, 68, 'general.image-text-section', 'steps', 7),
(56, 18, 69, 'general.image-text-section', 'steps', 8),
(57, 19, 70, 'general.image-text-section', 'steps', 1),
(58, 19, 71, 'general.image-text-section', 'steps', 2),
(59, 20, 72, 'general.image-text-section', 'steps', 1),
(60, 20, 73, 'general.image-text-section', 'steps', 2),
(61, 20, 74, 'general.image-text-section', 'steps', 3),
(62, 20, 75, 'general.image-text-section', 'steps', 4),
(63, 21, 76, 'general.image-text-section', 'steps', 1),
(64, 21, 77, 'general.image-text-section', 'steps', 2),
(65, 22, 79, 'general.image-text-section', 'steps', 1),
(66, 22, 80, 'general.image-text-section', 'steps', 2),
(67, 23, 81, 'general.image-text-section', 'steps', 1),
(68, 23, 82, 'general.image-text-section', 'steps', 2),
(69, 24, 83, 'general.image-text-section', 'steps', 1),
(70, 24, 84, 'general.image-text-section', 'steps', 2),
(71, 25, 85, 'general.image-text-section', 'steps', 1),
(72, 25, 86, 'general.image-text-section', 'steps', 2),
(73, 26, 87, 'general.image-text-section', 'steps', 1),
(74, 26, 88, 'general.image-text-section', 'steps', 2),
(75, 27, 89, 'general.image-text-section', 'steps', 1),
(76, 28, 91, 'general.image-text-section', 'steps', 1),
(77, 28, 92, 'general.image-text-section', 'steps', 2),
(78, 29, 95, 'general.image-text-section', 'steps', 1),
(79, 29, 96, 'general.image-text-section', 'steps', 2),
(81, 30, 97, 'general.image-text-section', 'steps', 1),
(82, 30, 98, 'general.image-text-section', 'steps', 2),
(85, 31, 99, 'general.image-text-section', 'steps', 1),
(86, 31, 100, 'general.image-text-section', 'steps', 2),
(87, 32, 101, 'general.image-text-section', 'steps', 1),
(88, 32, 102, 'general.image-text-section', 'steps', 2),
(89, 33, 103, 'general.image-text-section', 'steps', 1),
(90, 33, 104, 'general.image-text-section', 'steps', 2),
(91, 34, 106, 'general.image-text-section', 'steps', 1),
(92, 34, 107, 'general.image-text-section', 'steps', 2),
(93, 35, 108, 'general.image-text-section', 'steps', 1),
(94, 35, 109, 'general.image-text-section', 'steps', 2),
(95, 36, 110, 'general.image-text-section', 'steps', 1),
(96, 36, 111, 'general.image-text-section', 'steps', 2),
(97, 4, 17, 'general.image-text-section', 'steps', 1),
(98, 4, 18, 'general.image-text-section', 'steps', 2),
(99, 2, 5, 'general.image-text-section', 'steps', 1),
(100, 2, 6, 'general.image-text-section', 'steps', 2),
(101, 2, 7, 'general.image-text-section', 'steps', 3),
(102, 2, 8, 'general.image-text-section', 'steps', 4),
(103, 3, 11, 'general.image-text-section', 'steps', 1),
(104, 3, 12, 'general.image-text-section', 'steps', 2);

INSERT INTO "public"."components_general_copy_sections" ("id", "copy") VALUES
(1, 'Try this both barefoot and with shoes on. Being barefoot will give you more control over your balance, but since you play golf in shoes, it’s important to be able to feel how balance works without as much connection with the ground. You may be surprised at how different things feel with and without shoes!'),
(3, 'Slowly, while maintaining a good posture and without moving anything else, pull the toes of your left foot up as if you were trying to point them over your head. Your knee should remain bent. All the movement should happen at the ankle. Hold for three to five seconds at the highest point you can point them (and it won’t actually be pointing over your head, trust us). Slowly, with movement only at the ankle, return to the starting position to complete the rep. This is a tough movement, so go slow and stay in control.'),
(4, 'If you’re doing it correctly, you should feel work being done by your right quadriceps and your right glutes and you should get a very deep stretch in your left quadriceps and hip. Work your way up to doing sets of 20 reps on each leg. Once you can do this relatively easily, try doing it carrying light dumbbells in each hand. For the weighted variation, shoot for sets of 15.'),
(5, 'A great exercise for strengthening the hamstrings. If you’re working out on a floor, you can use two dish towels for this. If you’re working out on carpet, you can use a pair of furniture sliders. They’re very inexpensive and can easily be found online or in a hardware store.'),
(6, 'To get a feel for the muscles that control the forward and backward tilting of your pelvis – and to help you correct postural issues that will negatively affect your game – place a 55- or 65-centimeter stability ball against a wall and press your lower back against it. Without letting the ball fall to the ground, assume an address position with good posture and spine angle. This is the starting position.'),
(7, 'Feeling the movement of the ball is a great way to tell that you’re doing the move correctly. And by staying in golf posture, it will help remove a lot of the potential compensations that may want to happen. Over time, you’ll find that you’re able to go deeper into each direction, which is proof of not only a greater and increased range of motion, but also of your ability to control the movement of your hips, which is an invaluable skill on the golf course. Shoot for 10 repetitions.'),
(8, 'Even if you go to the gym on a regular basis, there’s still a good chance that you’re not targeting the muscles on the outsides of the hips. These are the muscles that are going to help you control side-to-side movement of the hips during your swing.'),
(9, 'A great way to help undo the effects of our seated sedentary lifestyle and a great way to increase spinal flexion and extension – or the forward and backward bending of the spine.'),
(10, 'Obviously, one of the jobs of the muscles that act around the spine is to create movement; we’ve gone into great length to point out the advantages of a mobile spine. Just as important, though, is the ability to stabilize the spine to prevent unwanted movement'),
(11, 'To build both the larger and smaller postural muscles in the back, attach a double-handled V-shaped resistance band to a waist-high anchor point. You can go with a higher resistance band for this one. '),
(12, 'This move involves the three ways that a muscle can be challenged. The initial quick pull is a concentric contraction and has the muscles in your back (as well as your biceps) shortening against resistance in a very explosive way. The hold with your shoulder blades squeezed together is an isometric contraction, where the muscles have to hold a shortened position against resistance. The slow-motion finish to the move is an example of an eccentric contraction, where the muscles slowly lengthen against resistance. And having your palms facing up the entire time keeps the chest a little more open. There’s a lot of good in this exercise. Shoot for 10 rows per set.'),
(13, 'To be able to increase range of motion at the neck – and to check where some asymmetry may exist – try these four simple movements. You may want to perform them in front of a mirror to make it easier to assess any left-side/right-side differences.'),
(14, 'While there’s all sorts of equipment and toys available for strengthening the muscles that operate around the neck, two of the safest and most effective ones are your own hands. Stand with feet shoulder-width apart with good posture and relaxed shoulders. You may want to do these movements in front of a mirror to make sure the rest of your body stays quiet.'),
(15, 'Limited external rotation will affect your golf even more than limited internal rotation, so it’s vital to target your external rotators. The external rotators don’t generate as much force as the internal rotators, so you want to go with a lighter resistance band for this one or stand a little bit closer to the anchor point.'),
(16, 'Because the external rotators aren’t as strong as the internal rotators, there are going to be a whole lot of potential compensations to be aware of. As in the previous move, make sure that you move the forearm in a perfectly horizontal plane to avoid recruiting the biceps and triceps. More importantly, though, be aware that your entire body is going to want to help your left hand get that band handle from point A to point B. Be very aware not to let your hips, chest, or shoulders rotate to the left and away from the anchor point. This is a very big red flag that indicates lack of strength in the external rotators. What’s nice about using bands for this exercise is that it’s very easy to reduce the resistance in the band just by moving a few inches closer to the anchor point, so you may end up doing this movement with less tension in the band for one arm than for the other. Over time, these right-side/left-side imbalances will become reduced or disappear entirely. Again, do 10 reps with each arm.'),
(17, 'A great chest exercise that will not only strengthen and stretch your pecs in a golf-specific way, but will also help shore up the infrastructure of the shoulder.'),
(18, 'Strengthening deep postural muscles like the rhomboids aren’t what most people think of when it comes to a shoulder workout, but you’re working to optimize your body for golf, not a mixed martial arts fight in the Octagon. This is a great one for improving your ability to maintain good golf posture and spine angle. It’s also a move that most people have never done in isolation, so it may take a while to get used to. Once you do get a feel for the movement, though, you’ll feel taller every time you do it!'),
(19, 'If the move seems too foreign and difficult using the bands, try it without the bands and just try to isolate the drawing back and squeezing of your shoulder blades while keeping your arms straight. Once you’re able to do this comfortably and with good control, try it again with the bands. Do 10 repetitions with proper form.'),
(20, 'This is a great move for stretching into the biceps and creating more range of motion at the elbow. If you’ve never stretched your biceps before, this one will feel pretty interesting.
'),
(21, 'A great way to increase stability at the elbow and shoulders while also challenging your entire core. 
'),
(22, 'A great way to maintain proper movement at the wrist – especially if you spend a lot of your day with a keyboard and mouse.'),
(23, 'Do three holds in each direction with each arm and then perform the same movements without the aid of your other hand to see if you can get the same stretch and range of motion without assistance.'),
(24, 'We spend most of our day with our fingers in a slightly flexed position. This is a quick and easy way to stretch through the palm and fingers. Think of it as being like yoga for your hands.
');

INSERT INTO "public"."components_general_image_text_sections" ("id", "copy") VALUES
(1, 'Sit on a bench or chair in an upright position with feet flat on the floor. Place a golf ball on the floor just to the right of your right baby toe.'),
(2, 'Keeping your heel on the floor, lift the ball of your foot and toes off the floor and pass it over the ball. When you put your foot down, the ball should now be just to the left of your big toe. Do 10 “hurdles” over the ball and then switch to the left foot. The key to the move is not lifting the heel off the floor. Do three sets of 10 with each foot.
'),
(3, 'To further increase mobility around the ankle, do the same movement, but this time when you do the initial movement with your right foot, only touch the outer edge of the foot to the floor. On the return hurdle, try to only touch the inner edge of the foot to the floor. Again, the heel should be in contact with the floor at all times. This is a very subtle variation of the initial movement, so take your time to get it right.
'),
(4, 'A little bit tougher than the first progression. This time, only touch the INNER edge of the foot to the floor on the initial outward hurdle. On the inward hurdles, try to only touch the OUTER edge of the foot to the floor. Again, shoot for three sets of 10 hurdles on each foot.
'),
(5, 'Stand in a comfortable stance with feet shoulder-width apart. Slowly shift your weight over your right leg and – keeping your left leg straight – slightly lift your left foot off the floor. This is the starting position.'),
(6, 'Imagine that you’re standing in the middle of a giant clockface. Keeping your left leg straight raise it in front of you (or where 12:00 would be on the clock). Hold this position for a two-count and then return to the starting position without touching the foot to the ground.
'),
(7, 'Now, lift it out to the side (or toward 9:00) and hold it for a two-count.'),
(8, 'Return to the starting position again without touching the foot to the ground and now extend the leg in back of you (or toward 6:00). Hold this for a two-count and then return to the starting position. Switch feet and do the same series of movements with the left foot on the floor. Initially, alternate between feet after only one set of the three moves. Work up to the point where you can do three complete sets of 12:00, 9:00 (or 3:00 with your right foot), and 6:00 on each side without putting the foot down before you switch feet.'),
(9, 'Once you’ve mastered the movements on a stable surface, try doing them on a balance pad or balance disc.'),
(10, 'Improve stability even more – and get in some bonus neuromuscular work – by trying the movements with your eyes closed. Start on a solid surface and work your way up to doing them on a balance pad or disc.'),
(11, 'Stand with feet shoulder-width apart.'),
(12, 'Come up as high as you can on your tiptoes, hold this position for a moment, and then slowly lower yourself almost back to the starting position but without quite touching your heels to the floor. Initially shoot for a set of 15 without touching your heels to the floor. Over time, keep increasing sets by five reps until you can do 30 raises relatively easily.
'),
(15, 'Perform the same calf raises as above, but this time holding a 15- or 20-pound dumbbell in each hand. Start with sets of 10 and – over time – increase sets by two reps until you get to 20.'),
(16, 'Stand with feet next to each other holding a dumbbell in each hand. (You can go with lighter dumbbells until you get a feel for the movement.) Raise your left knee up in front of you until your left thigh is parallel to the floor. Come up as high as you can on your tiptoes with your right foot, hold for a moment, and then lower yourself without quite letting your right heel touch the floor. Shoot for 10 on each leg without touching your heel to the floor.'),
(17, 'To target the muscle on the front of your lower leg, sit on the floor with a loop resistance band looped around both your feet. Half of the band will be under the soles of your feet and the other half will be on top of your feet and running over your shoelaces. Place your hands slightly behind and away from both hips.'),
(18, 'Maintaining good upright posture, raise your left knee so your thigh is elevated 30 to 45 degrees from the floor. Establish solid balance in this position. You may be feeling some work going on in the front of your left hip. This is the starting position.'),
(19, 'To keep the hamstrings in the back of your thighs loose – and to give them a strength challenge – stand straight-legged with feet shoulder-width apart and a light dumbbell in each hand. (As you get more efficient with the movement, you can add more weight.) The weights should be against the front of your thighs with your palms facing your thighs. This is the starting position.'),
(20, 'While keeping the weights against your legs and your back straight, push your hips back and slowly lower the dumbbells. Your knees will bend slightly while you do this. When the dumbbells have gotten just below the knee, hold for a second, feel the stretch in the back of your thigh, and then push the hips forward, squeezing your glutes, and straightening your legs until you return to the starting position. Do 10 reps to complete the set.
'),
(21, 'Assume the same starting position as previously, but with your feet together and a dumbbell in your right hand only. As you begin to lower the weight against your leg, extend your left leg in back of you.'),
(22, 'Your right leg will bend slightly, as above, but try to keep the left leg straight. Also try to keep your hips level. In other words, don’t let your left hip raise higher than your right hip, which it will want to do. And don’t let your left hip dip lower than your right hip, which it might also want to do. Picture one of those carpenter’s leveling tools – the one with the bubble in it that moves when it’s not on something flat – laying across your lower back and having the bubble staying firmly in the center. Establish your balance in this position and then slowly return to the starting position to complete the rep. Take your time with these to really fine-tune the movement. Work your way up to sets of 10 on each leg.'),
(23, 'Stand with feet shoulder-width apart holding a club out in front of you horizontally at shoulder height. Your hands should be slightly wider than shoulder-width apart.'),
(24, 'Take a deep step forward into a lunge position with your right leg. In the lunge position, your right knee should be directly over your right heel and your right knee should be bent to around 90 degrees. (Don’t worry if you can’t get your knee to 90 degrees if you’re just starting out. That range of motion will eventually happen if you stick with it.) Your right knee shouldn’t be caved in or bowed out to the side. It should be tracking right along the line of your second toe.'),
(25, 'Maintaining a very upright posture, slowly rotate your upper body toward the right, keeping the club extended out in front of you at shoulder height. Make sure to turn your head as you turn your upper body. This will not only let you rotate a little deeper but will also challenge your balance more. Your right knee will want to bow out a bit to the right when you do this, but try to keep it tracking over your second toe. Hold this position for a beat and then return to a forward-facing lunge position.

Reestablish your balance in the lunge position and then rotate your upper body to the left – or away from your lead leg. This time, your knee will want to follow your upper body and cave in to the left. Again, try not to let this happen. Hold this position for a beat, return to the forward-facing lunge position, reestablish your balance, and then, pushing off your right leg, return to the standing starting position. Now, step into a lunge with the left leg and do both rotations. Shoot for 10 lunges with rotations on each leg.'),
(26, 'Perform the same movements holding a 55- or 65-centimeter stability ball instead of a golf club. This will add extra weight to the movement and the tweaked hand position and the way you’re forced to hold the ball will add a chest-opening element to the exercise.'),
(27, 'To build strength in the quadriceps, stand about two feet in front of a weight bench or anything else that’s solid, stable, and stands about 18" to 24" off the floor. Carefully, extend your left leg in back of you and place your foot on the bench with your toes curled under. Hop forward or backward until your right knee is directly over your right heel. This is the starting position.'),
(28, 'Keeping your right knee over your heel, slowly lower your hips until your knee is flexed to an angle smaller than 90 degrees. Hold for a moment and then slowly raise your hips back to the starting position by driving through the heel of your right foot. There’ll be a tendency to do most of the work by bouncing on the toes of your left foot. Try not to let this happen. You’ll end up looking like you’re doing the movement correctly, but this compensation will take the focus off the quads.'),
(29, 'Perform the same movement with the front foot on a balance pad. Definitely make sure you’re comfortable with the added balance challenge of this variation before adding any dumbbells to the movement! This progression will add some bonus stability work for the knee and ankle and some extra work for the muscles of the lower leg.'),
(30, 'Lie on the floor with your knees bent and your feet flat on the ground on either towels or furniture sliders. You should be able to just touch your heels with your fingertips. Without arching your lower back, lift your hips off the ground until there’s no bend at the hips and your body is a straight line from your knees to your shoulders. This is the starting position.
'),
(31, 'Keeping the hips up as much as possible, slide your right foot out until your right leg is almost straight. Try to maintain pressure on the towel or furniture slider as you do this to avoid it slipping away from you. When the right leg is fully extended, begin to pull it back toward you as you let your left leg slide out. The goal is to get a continuous motion going where one leg is sliding out as the other is pulling in. Ideally, when done correctly, you should look like a bug on its back flailing desperately to get back onto its feet. Hey, no one said this was going to be pretty! Try to do sets of 20 alternating curls – 10 with each leg.'),
(32, 'To challenge the hamstrings a bit more, try doing the move with both feet moving in and out together. From the same starting position and without dropping your hips or arching your lower back, slowly let your feet slide away from you. When your legs are almost straight, reverse the movement and pull your feet back in toward you. Your hips are going to want to drop when you begin to bring your feet back in. Try not to let that happen. These can be tough. Initially try for sets of 6 to 8 repetitions, but work your way up to sets of 20.'),
(33, 'Take Progression One to a new level by doing the movement with your feet on a 55- or 65-centimeter stability ball instead of towels or sliders. Elevating the feet allows for a much greater range of motion for the movement, which will make it a little bit tougher. And placing your feet on something that doesn’t want to stay in one place will make it a lot tougher.'),
(34, 'Slowly and with good control, tilt your hips forward as if you were trying to point your belt buckle toward the floor. Try to avoid any other movement. When you do this, you should feel the ball sliding slightly up your back. Hold this for a three-count.'),
(35, 'Reverse the move and tilt your hips as far back as possible, as if you were trying to point your belt buckle toward the ceiling. You might feel tension in your glutes when you do this – and that’s a good thing! Again, watch for any other body parts like your knees or your back trying to help out. You should feel the ball sliding down your back when you do this. Hold this position for a three-count and then tilt your hips slightly forward until you are back to the starting position to complete the rep.'),
(36, 'To get your hips used to internal and external rotation, stand with your feet shoulder-width apart. Toes should be facing forward. This is the starting position. Raise your right leg so that your thigh is at waist height and parallel to the floor. Establish balance in this position.
'),
(37, 'Slowly rotate your right leg outward until your knee is aimed directly to your right. Try to do this without turning your entire body. In other words, while your knee may be facing to the right, your hips, chest, and shoulders are still squared forward. Hold for a three-count and then return to the starting position. You’ll not only feel this in the hips, but also in your core. These are the muscles that are working to prevent your upper body from rotating toward the moving leg. Do 10 hip openers on each side.'),
(38, 'Put a looped resistance band around your ankles and stand with your feet about six inches apart. Even with this narrow stance, there should be a tiny bit of tension in the band. This is the starting position.'),
(39, 'Keeping your toes pointed forward, step sideways with your right leg into a slightly wider than shoulder-width stance. You should quickly feel some awareness at the sides of your hips. It’s key that the toes face forward throughout the movement. There’s going to be a tendency to turn your right foot out as you step. If this happens, then it becomes your hip flexors that are doing the work. We don’t want them doing the work here. By keeping the toes forward, it guarantees that your hip abductors on the outside part of the hip are being engaged. Hold this stance for a beat and then step your left foot toward your right foot until you’re back in the starting position. Take five steps to the right and then five steps to the left to complete each set.'),
(40, 'From the same starting position, step into a slightly wider than shoulder-width stance with your right foot and instead of simply holding the position, throw your hips back and – keeping your knees directly over your heels – drop into a squat position. Keeping your knees directly over your heels will not only keep your knees healthy, it will also force your quads and glutes to work harder. You might also feel your knees caving in toward each other. By preventing this from happening and keeping your knees wide apart, you’re getting your hip abductors on the outside of the hip to work harder. Hold the squat position for a moment and slowly come out of the squat and back into the slightly wider than shoulder-width stance. Step your left foot toward your right foot to return to the starting position. Adding a squat to the movement will add extra work for the muscles on the sides of the hips as well as a good amount of glute work. Try for sets of five step-and-squats to each side.'),
(41, 'Similar to the movement on the previous page, but instead of breaking the move into four parts, try to break it into only two parts. From the same starting position, step into a slightly wider than shoulder-width stance at the same time that you’re lowering your hips into a squat. Hold the squat for a moment and then simultaneously come out of the squat and step your left foot toward your right until you’re back to the starting position. There’s a lot going on with this progression, so make sure you’ve mastered Progression One before moving on to this one. As previously, shoot for sets of five side-stepping squats to both the right and the left.
'),
(42, 'Lie on your back with your knees bent and your feet flat on the ground. If you reach down, you should just be able to touch your heels.'),
(43, 'Without arching your lower back, slowly lift your hips off the ground. See if you’re able to lift them so that your body forms a straight line from your knees to your shoulders. You might feel a nice stretch across the tops of your hips and quadriceps here. Hold this for a second and then return to the starting position. As you get stronger, instead of returning to the completely relaxed starting position, lower yourself until your back is an inch from the ground before beginning the next hip raise. Initially, shoot for sets of 10, but don’t be afraid to challenge yourself with as many as 25 reps as long as you can keep proper form without any lower back arching.
'),
(44, 'Perform the same movement with your feet flat on top of a 55- or 65-centimeter stability ball about hip-width apart. (Depending on the size of the ball, you may not be able to completely flatten your foot on top of the ball in the setup position.) You’ll want to extend your arms out to the sides with palms down to help with balance. You will feel this almost immediately in your hamstrings and calves. Try not to let your knees cave in toward each other or bow out. Ideally, the distance between your knees should be the same as the distance between your feet. Shoot for 10 to 15 reps.'),
(45, 'Set up as in the first progression, but with your feet very close to each other on the ball. Lift your hips off the floor as before, but this time slowly straighten your left leg toward the ceiling. To keep your lower back in proper position, keep your left leg slightly bent with your knee directly above your navel. Keeping the left leg raised and very quiet, slowly lower your body until your back is an inch off the ground and then return to the raised hip position. You will feel this very profoundly in your right hamstring and calf and your balance will definitely be challenged. These will be tough, but try for 8 to 10 reps.
'),
(46, 'Get onto all fours. Your hands should be directly under your shoulders and your knees should be directly under your hips.
'),
(47, 'Slowly round your back as far as you can do comfortably. Imagine trying to touch the middle of your back to the ceiling. This will involve more than just the muscles alongside the spine, you’ll feel a stretch into your hips and shoulders, as well. This is the “cat” portion of the move.'),
(48, 'Now, slowly reverse the movement and arch your back as if you were trying to drop your stomach to the floor. This is the “cow” portion. You may feel more restriction in this part of the exercise – especially in the lower back. Hold this position for a moment and then transfer back to the “cat” phase by rounding your back again. Continue until you’ve done 10 “cats” and 10 “cows.” Don’t be surprised if you’re able to go deeper into each move as your body loosens. We guarantee you will feel better after doing this than you did before you started. It’s that good of a movement.'),
(49, 'To increase rotational mobility of the spine, attach a double-handled V-shaped resistance band to a knee-high anchor point. Stand facing the anchor point in address position with a handle in each hand with your palms facing in and toward each other. Your arms should be extended in front of you and angled toward the anchor point as if they were extensions of the bands. There should be slight tension in the bands. This is the starting position.'),
(50, 'Keeping your left arm straight, dynamically rotate your arm and upper body to the left. Since you’re trying to simulate a follow-through-like movement, pivot on the ball of the right foot to allow the hips to aid in rotation. Try to keep your right arm still and angled at the anchor point. 
'),
(51, 'Since we want to involve the entire spine, rotate your head to the left, as well, as if you were trying to see your ball landing far down the fairway. You should get a deep stretch across the chest and into the shoulders. Reverse the motion and return to the starting position in a controlled fashion – don’t just let the tension in the band whip you back to the starting position. Now, do the same move to the right as if you were a left-handed player finishing their swing. Do 10 follow-throughs to both sides.'),
(52, 'Stand holding the handle of a single resistance band in both hands. The anchor point of the band should be at chest height and instead of it being in front of you, it should be directly to your left. Your feet, hips, chest, and shoulders should be squared forward. Hold the handle up against your chest with bent elbows. There should be a decent amount of tension in the band. This is the starting position.'),
(53, 'Slowly, push your hands out in a straight line from your chest until they’re extended directly in front of you. You should feel a good amount of torque pulling you to the left in this arms-extended position. Don’t let your arms, chest, hips, knees, or anything else rotate to the left. Hold this position for 10 seconds and then return to the starting position to complete the repetition. You’ll feel this in your midsection. Do four holds with the anchor point to your left and then do four holds with the band anchored to your right.'),
(54, 'Perform the same move as above, but instead of holding the arms-extended position for a ten-count, hold it for a three-count and then return to the starting position to complete the rep. The added movement will add to the challenge of keeping your body from being rotated by the band. In addition to keeping your body quiet, the other major challenge is to move your hands in a perfectly straight line forward in front of you as you extend your arms. The body will try to come up with very creative ways to “cheat” this movement by taking a curving route. This is a tough one when done correctly. If you’re finding it very easy to do, double-check to make sure your entire body is squared forward and that your hands are following a straight path away from and back toward your chest. If you’re still finding it easy, then you have a really stable spine! Do 10 repetitions with the band anchored to the right and then 10 repetitions with the band anchored to the left. '),
(55, 'Perform the same movements as in the above progression, but instead of being in an upright standing position, do the move in golf posture. You’ll feel it in your legs, hips, core, and back. This is a great way to create the feeling of full-body stabilization in your address position. Again, 10 reps with a right-side anchored band and 10 reps with a left-side anchored band to complete the set.'),
(56, 'Face the anchor point with a handle in each hand. Bend your knees slightly and assume an athletic stance – feet a bit wider than shoulder-width apart, hips back, upper body slightly leaning forward with a strong and straight spine. There should be some tension in the bands. This is the starting point.'),
(57, 'Dynamically pull the bands back by drawing your elbows and shoulder blades back, turning your palms up as you pull. Try not to lose the slight forward lean of your upper body. Your arms should be the only things moving. Hold this pull position for a three-count being aware of keeping your shoulder blades squeezed together. Very slowly, reverse the initial pulling motion to return to the starting position. Let this last part of the move take several seconds.'),
(58, 'Perform the same movement as above, but in golf posture with the anchor point set below knee-level. The slightly deeper lean that this will force your upper body into will make this version a little more challenging on the muscles of the back. But it’s a great way to strengthen the muscles that you’ll need to maintain proper posture from the first tee to the last.'),
(59, 'To strengthen the postural muscles of the back while also working on lower body strength and balance, attach a resistance band to a chest-high anchor point. Face the anchor point in a very tall, upright stance with the band in your right hand with your palm facing toward the left. There should be slight tension in the band. Raise your right leg so that your right thigh is waist-height and parallel to the floor. This is the starting position.'),
(60, 'Slowly pull the band back by drawing your elbow and shoulder blade back. Hold this position for a beat and then reverse the movement to return to the starting position to complete the repetition. Try to remain tall and minimize any movement other than your right arm. Your right hip will want to rotate forward or backward. Use the strength in your hips to prevent this. You might also feel this in your left foot as it’s working hard to keep you from falling over. Do 10 reps of one-legged rows on each side.'),
(61, 'If you thought that maintaining your balance was difficult in the previous movement, try doing it standing on the leg on the same side of the hand that’s pulling. Standing on the right leg while doing the row with the right arm is an adventure in balance. The good news is that if you can master this movement, you’ll not only be strengthening the postural muscles around the spine, you’ll also be one step closer to having the balancing skills of a mountain goat. As above, shoot for 10 reps on each side.'),
(62, 'Stand with feet about shoulder-width apart with strong posture and relaxed shoulders. This is the starting position. Slowly tilt your head as far forward as you can comfortably. Don’t force movement if there’s discomfort. It should feel like a good stretch in the back of your neck, but there shouldn’t be pain. Hold for a three-count.'),
(63, 'Then, tilt your head as far back as it can go comfortably. You should feel a stretch – but not pain – in the front of your neck across the throat. Hold for a three-count and then return to the starting position. Do five holds in both the forward flexion and backward extension positions.'),
(64, 'From the same starting position, tilt your head to the right side as if you were trying to touch your right ear to your shoulder. Try not to lean or raise your left shoulder. Again, only go as far as you can comfortably. You should feel a stretch on the left side of your neck. Hold for a three-count.'),
(65, 'Then, tilt your head to the opposite direction, as if you were trying to touch your left ear to your shoulder and hold for a three-count. You should now feel this on the right side of your neck. Do five holds tilting to the right and five holds tilting to the left.
'),
(66, 'Again, from the same starting position and keeping your head perfectly upright, turn your head to the right. Remember to only go as far as feels comfortable. The rest of your body will want to help out on this one, so try to avoid any extra movement at the shoulders and hips. Hold for a three-count.'),
(67, 'Then, turn your head to the left for a three-count. You may be surprised that you have more freedom of movement in one direction than the other. The ultimate goal is to lessen that difference. Do five holds in each direction.'),
(68, 'Finally, from the same position, jut your head forward keeping your eyes staring straight ahead. If you’re using a mirror, keep your eyes on your eyes in your reflection. If you find yourself looking up or down, it means you’re tilting your head. Hold this jutted-out position for a three-count and then return to the starting position.'),
(69, 'Now, pull your head straight back. Imagine you’re trying to discreetly distance yourself as much as possible from someone with bad breath. Keep your eyes forward. If you find yourself looking up or down, your head is tilting and you won’t be working to increase the targeted range of motion. Hold this for a three-count and return to the starting position. Do five holds in both the jutted-out and the pulled-back position.'),
(70, 'Hold a club horizontally in front of you with hands a little bit wider than shoulder-width apart. Assume an address position with good posture and proper spine angle. Fix your eyes on a spot on the floor where your ball would be.'),
(71, 'From this starting position, rotate to your left into a left-handed player’s takeaway position. There’ll be a little rotation at the hips, but the majority will be around the spine. The key is to keep your head from turning and keep your eyes fixed on where the ball would be. Hold this position for a beat and then return to your address position. Now, rotate to your right into a right-handed player’s takeaway position. Again, try to keep your head still. Hold for a beat and then return to your address position. Do 10 takeaways in each direction.'),
(72, 'Place the palm of your right hand against your forehead and press gently as if you were trying to tilt your head back. Resist the pressure from your hand and try to keep your head from moving. You may feel this in the muscles in the front of your neck across your throat. This is an example of an isometric contraction. The muscles are engaged, but they’re neither shortening (as they usually do when we use them) or lengthening. In an isometric contraction, the muscle maintains its current length. Hold this for a five-count.
'),
(73, 'Now, press gently on the back of your head and use the muscles of the neck to prevent your head from tilting forward. Hold for a five-count.'),
(74, 'Press gently on the right side of your head and resist the pressure to tilt your head to the right. Hold for a five-count and then press on the left side of your head and resist the pressure to tilt your head to the left for a five-count.'),
(75, 'Place your palm along your jaw on the right side and press gently. Use the muscles in your neck to prevent your head from turning to the left, and then press gently on the left side of your jaw and resist the pressure to turn your head to the right. Hold both of these for a five-count.'),
(76, 'To create stability at the shoulder, stand facing a wall. Your feet should be about a foot from the base of the wall. Place your forearms vertically against the wall with your palms facing in toward each other. In this position, just your pinkie fingers should be in contact with the wall with your thumbs pointing toward your ears. Your elbows should be just below chest level and your hands should be about at the same height as your face. This is the starting position.'),
(77, 'Slowly, keeping your forearms vertical and in contact with the wall, slide them upward. Keep sliding until your arms are straight. Hold this for a moment and then, keeping your forearms vertical and in contact with the wall, reverse the movement until you''re back to the starting position. If one or both shoulders don’t have adequate stability, you might find it difficult to maintain constant contact with the wall or to keep your forearms vertical. You might also find that your shoulders move way up toward your ears. If any of these compensations were an issue, reduce the range of motion of the movement until you can do a limited version of this movement without any compensations. Over time, you’ll be able to create greater range of motion and you’ll find that you’re doing the movement with far less stress in the shoulders. Try for 10 slides without any compensations to complete the set.'),
(78, 'Perform the previous movement with a light-resistance looped band around your forearms right above the elbow. There should be light tension in the band at the starting position of the move. If there’s any instability, it will become obvious immediately, as your forearms will either angle in toward each other or they’ll come away from the wall. Again, as previously mentioned, if you’re able to do a limited range version of this without any compensations, perform the limited range version until the stabilizers in the shoulders become strong enough to complete the full range version. Whether there were any compensations or not, you may be feeling this exercise in places that you’ve never felt anything before. Congrats! You’ve discovered some new body parts!'),
(79, 'As we’ve discussed, limited ability to rotate the shoulder will negatively affect your game in a major way. To strengthen the muscles that rotate the shoulders internally, stand sideways to the anchor point of a light resistance band set between waist and chest height. The right side of your body should be facing the anchor point, and you should have the band handle in your right hand. Press your upper arm tight against your body and flex your elbow 90 degrees. With the band handle in your hand, the back of your hand should be facing the anchor point. This is the starting position.'),
(80, 'Keeping your hips, chest, and shoulders squared forward and your upper arm against your body, rotate your forearm away from the anchor point and across your body. There are many keys to doing this one correctly, but the main one is to make sure the rotation happens in a true horizontal plane and that your forearm stays parallel to the floor the entire time. If it’s not moving in a parallel plane, you’re not targeting the rotators. (For example, if you’re moving at a slightly upward angle, you’re actually doing a strange version of a biceps curl, and if you’re moving at a slightly downward angle, you’re allowing your triceps to get involved.) You also want to prevent your arm from coming away from your body. A good way to prevent this is to place a folded towel under your arm between your upper arm and your body. If the towel falls to the floor, you’ll know that you’ve lost contact. 

Hold this forearm-across-your-body position for a three-count and then return to the starting position in a controlled manner to complete the rep. You may find that it’s incredibly easy to do the move with one arm, but that it’s far more difficult with the other. The goal, as it is with everything we’re doing, is to reduce whatever asymmetry exists. Shoot for 10 reps with each arm.'),
(81, 'Position yourself as you did in the previous exercise with a band handle in your left hand, your upper arm pressed tight against your body, and your elbow flexed at 90 degrees with your forearm parallel to the floor. The right side of your body and the palm of your left hand should both be facing the anchor point. Let the tension of the band pull your forearm toward the anchor point without letting it pull your upper arm away from your body. This is the starting point.'),
(82, 'Keeping your hips, chest, and shoulders squared forward and your upper arm against your body, rotate your forearm away from the anchor point as if your forearm was a door opening. Hold this position for a three-count and then slowly reverse the move and return to the starting position in a controlled manner with your forearm staying parallel to the floor to complete the rep.
'),
(83, 'With a band handle in your right hand, stand with feet shoulder-width apart with the band anchor point in back of and to the right of you. Extend your right arm directly out to the side with a slight bend at your elbow. Your right hand should now be directly in front of the anchor point with your palm facing forward and there should be tension in the band. Your hips, chest, and shoulders should be squared forward, and your upper body should be upright with good posture. This is the starting point.'),
(84, 'Keeping the rest of your body still and quiet and maintaining a slight bend at the elbow, draw your arm forward until it’s extended directly in front of you. The movement should happen in a horizontal plane parallel to the floor and it should involve movement only at the shoulder. You should not only feel this in your chest and shoulder, but because of the imbalances that are being created by the one-sidedness of the movement, you should also feel it in the core, hips, and legs. Hold this position for a second and then slowly reverse the move to return to the starting position. To get the most out of this exercise, don’t simply let the tension of the band pull you back to the starting position. Resist the tension and return to the starting position in a controlled fashion. Do 10 flies with each arm to complete the set.'),
(85, 'Stand facing a band anchor point set at shoulder height with a band handle in each hand. Straighten your arms toward the anchor point. There should be slight tension in the bands. This is the starting point.'),
(86, 'Moving just your arms, pull back your shoulders by squeezing your shoulder blades together. This isn’t a big movement. Your arms will retract a total of six to eight inches. But, again, this one might be tough at first. If you find your elbows bending, it’s because your body is going to want to use the big muscles in the back and turn this into a pulling motion. You also may find yourself leaning backward to move your shoulders back. Avoid either of these compensations. When you’ve drawn the band back as far as you can comfortably go, hold the position for a three-count before letting the arms return back toward the anchor point to complete the rep.'),
(87, 'Get onto all fours on the ground with your wrists aligned directly under your shoulders and your knees directly aligned under your hips. If you did this the way 99 percent of the population would, your fingers of both hands are pointing forward with your palms on the ground.
'),
(88, 'Carefully rotate your arms to try to get your fingers facing out to the sides with your palms on the floor. Now gently press your elbows inward and toward each other as you straighten your arms as much as possible. You should feel a deep stretch into both your biceps and the front of your forearms. Hold the stretch for 20 seconds. Do three 20-second holds with a 20-second break in between each to complete the set.'),
(89, 'Assume an “up” push-up position with your hands aligned directly under your shoulders. Your body should be in a straight line from the top of your head to your heels. This is the position you’re shooting for. You may want to do this using a mirror so that you can see a sideways view of your body.

Hold the plank position only so long as you can without either of the above compensations becoming too powerful to correct. Shoot initially for three 10-second holds for each set and work your way up to three 20-second holds per set.

A bunch of things are going to want to happen. Your hips are going to want to drop and your lower back is going to want to arch. This is a sign of weak glutes. Curl your hips under to prevent this from happening. When you do, you should feel your glutes engaging and your body straightening. This corrective move is essentially the same hip movement that you did in the Cat/Cow mobility exercise from the Spine chapter.

The other thing to look for and to try to avoid is having your body pike and your butt raise up in the air. This is the sign of a weak core. Drop your hips and engage your abdominal muscles to realign your body into a straight line.'),
(90, 'From the same starting plank position, challenge the stability at the elbow and shoulder even more by taking your right hand off the floor and bringing it to your left shoulder. Hold for a five-count and then return it to the floor. Now bring your left hand to your right shoulder for a five-count. The unsupported shoulder is going to want to drop. Try not to let this happen. Also, try not to let the other two compensations discussed above happen.

Initially, for each set, shoot for three planks with two alternating holds on each side and eventually work your way up three planks where you’re able to do five alternating holds on each side.'),
(91, 'This is a great move for strengthening the back of the upper arm and lessening any biceps/triceps muscular imbalances that may exist. Stand facing a band anchor point set at chest height with a band handle in each hand. Assume a comfortable address position with knees bent, shoulders relaxed, and with good posture and spine angle. Bring your upper arms tight against your sides and flex your elbows so that the bands and your forearms are in a perfectly straight line from the anchor point to your elbows. Turn your palms down, so that they’re facing the floor. This is the starting position. '),
(92, 'Keeping your upper arms tight against your sides and your palms facing down, straighten your arms by moving only at the elbow. At the end of the movement, your arms should be as straight as you can get them with your hands now in back of you with your palms facing up. You should feel this in the back of your upper arms, but because of the added stability requirements of being in golf posture, you may feel this in the lower back, hips, and legs. If you’re unable to do the move without your upper arm moving, move a few inches closer to the anchor point. Hold this position for a second and then reverse the movement to return to the starting position to complete the rep. And to get the most out of this move, it’s just as important that the upper arm remains glued to your side during the return phase of the exercise as it is during the initial phase. Shoot for 10 reps with good form. '),
(93, 'From the same starting position, perform the same move as on the previous page, but now alternate the movements so that as one arm is straightening away from the anchor point, the other arm is flexing back toward the anchor point. This will add a few interesting, challenging, and beneficial wrinkles to the exercise. In the original move, there was exertion, a static hold, a slow return, and then a rest period. Here, there’s constant motion. There’s also a slight increase in the full-body stability needed to maintain proper golf posture as both arms are constantly moving in opposite directions. As a result, this one may get your heart rate up a little faster and you may feel more of a burn in your triceps. Do 10 alternating reps with each arm to complete the set. '),
(94, 'As long as we’re throwing some chaos at you, let’s turn the knob even more. This time perform the progression above, but while standing on two balance pads. Now, we’ve opened up the gates for a lot to go wrong. The added full-body stability required to deal with the alternating arm movements gets increased further by your need to maintain proper posture and spine angle while balancing on unstable surfaces. And don’t let the added balance challenge distract you from the primary focus of the move. Make sure to keep your upper arms by your side throughout the entire move to force your triceps to do as much work as possible. As with the above progression, shoot for 10 reps with each arm.'),
(95, 'To strengthen the muscles that help you turn your wrists over and to help prevent golfer’s elbow, sit comfortably on a bench or a chair with a band anchor point directly to your right set at slightly higher than knee height. Your feet should be slightly wider than hip-width apart with your feet flat on the ground. Grab the band – not the handle – with your right hand and place your right forearm on your right thigh. Your fist should be extended slightly past your knee with your palm facing the ceiling. In this position, the anchor point should be on the same side as your thumb. Hold your right forearm in place with your left hand to prevent any unnecessary movement. This is the starting position.'),
(96, 'Holding the band tightly and without letting your forearm move, turn your fist so that your palm is now facing the floor. Hold for a three-count and then slowly reverse the move to return to the starting position to complete the repetition. Make sure to keep your forearm quiet and stable as you return to the starting position. Go with a relatively light resistance band for this one to make sure that you’re able to perform the move without any compensations. For each set, do 10 reps with each arm.'),
(97, 'To work the forearm muscles responsible for turning the wrist and hand in the opposite and upward facing direction, assume the same starting position, but this time have the anchor point set up on your left side at slightly higher than knee height. With the band in your right hand – again, the band, not the handle – place your forearm against your thigh with your palm facing the floor. In this position, the anchor point should again be on the same side as your thumb. Use your left hand to brace and stabilize your right forearm. This is the starting position.'),
(98, 'Without moving your forearm, turn your fist over until your palm is now facing the ceiling. Hold this position for a three-count and then reverse the movement while keeping the forearm from moving to complete the rep. Don’t let the tension in the band pull you back to the starting position. Slowly return to the starting position to get the most out of the movement. Again, you’re going to want to go with a lighter resistance band to make sure that you can do the exercise without any compensations or extra movement. As with the previous exercise, do 10 reps with each arm to complete the set.'),
(99, 'Raise your right arm up in front of you with your elbow flexed at 90 degrees and the palm facing down. Your forearm should be parallel to – and directly in front of – your chest. This is the starting position.'),
(100, 'With the heel of your left palm, push gently on the back of your right hand, bending your wrist as if you were trying to make your right palm touch your right forearm. You should feel a stretch on the back of your right forearm. Hold for a five-count and then return to the starting position. Now, perform the opposite movement – push on the palm of your right hand, bending your wrist back as if you were trying to get the back of your right hand to touch your forearm. You should now feel a stretch on the front of your right forearm. Hold for a five-count and return to the starting position.'),
(101, 'Make a tight fist with your right hand'),
(102, 'Open your hand up and try to pull your fingers as far back as possible. You should get a stretch in your palm and into each finger. Return to the starting position to complete the rep. Do 10 extensions with each hand.'),
(103, 'l at chest height. Don’t let your palms touch the wall. Keeping your body perfectly straight from your heels to your head, slowly lower yourself toward the wall as if you were trying to get your chest to touch it. Hold the position when your chest is about two inches from the wall. This is the starting position.'),
(104, 'Keeping your body straight and just your fingertips connected to the wall, push yourself away from the wall until your arms are straight and you’re almost in an upright position. Slowly lower yourself back to the starting position to complete the rep. Start by doing sets of 10 push-ups and work your way up to doing sets of 20.'),
(105, 'Perform the same movement standing about three feet away from the wall. This time, push off the wall so explosively that your fingertips come off the wall. Try to push yourself back onto your heels. Fall forward back toward the wall and – using just your fingertips – gently decelerate your body back to the starting position without letting your chest (or your face!) touch the wall. Again, start with sets of 10 and work your way up to sets of 20.'),
(106, 'Sit comfortably with feet about hip-width apart. Holding a light dumbbell in your right hand, rest your forearm on your right thigh with your palm facing up. Your wrist and hand should be hanging over your thigh, past your knee. Let the weight roll down your hand until you’re holding it in your fingertips. This is the starting position.'),
(107, 'Begin the movement by lifting the weight up by curling the fingers into a fist. This will target the muscles in the palm and fingers. Keeping your forearm against your thigh, continue the movement by raising your fist up by bending at the wrist. This will target the muscles in the forearm that flex the wrist. Hold this position for a moment and then slowly lower the weight back to the starting position to complete the rep. Shoot for sets of 20 on both the right and left side.'),
(108, 'To work the muscles that extend the wrist backward, assume the same starting position as the previous movement, but with your palm facing down and your hand already in a fist. With the weight in your hand, your wrist should be bent to almost 90 degrees in this position. You may want to go with an even lighter weight than in the last exercise.'),
(109, 'Keeping your forearm tight against your thigh, lift the weight by pulling your fist up and back. Hold the position for a beat and then slowly return to the starting position to complete the rep. The key is to keep your forearm from moving, which is what it’s going to want to do. Do sets of 20 reps on each side. If you haven’t done any wrist or forearm exercises before, you will feel these pretty quickly.'),
(110, 'To work the muscles that move the hand to the left and right, use the same setup position as on the previous page, but with the palm of your right hand facing to the left. The dumbbell will almost be in a vertical position. Keeping your forearm tight against your thigh, tilt the dumbbell forward as if it were a microphone and you were interviewing someone sitting directly in front of you. This is the starting position.'),
(111, 'Without moving the forearm, pull the dumbbell backward until it’s angled toward you. (If you want to stick to the microphone analogy, it now should be aimed at you.) Hold this position for a second and then slowly return to the starting position. Shoot for sets of 20 reps on each side.');

INSERT INTO "public"."components_workout_days" ("id", "title") VALUES
(1, 'Workout 1'),
(2, 'Workout 2'),
(3, 'Workout 3'),
(4, 'Workout 1'),
(5, 'Workout 2'),
(6, 'Workout 3'),
(7, 'Workout 1'),
(8, 'Workout 2'),
(9, 'Workout 3'),
(10, 'Workout 1'),
(11, 'Workout 2'),
(12, 'Workout 3');

INSERT INTO "public"."components_workout_days_components" ("id", "entity_id", "component_id", "component_type", "field", "order") VALUES
(322, 1, 1, 'workout.exercise', 'day', 1),
(323, 1, 2, 'workout.exercise', 'day', 2),
(324, 1, 3, 'workout.exercise', 'day', 3),
(325, 1, 4, 'workout.exercise', 'day', 4),
(326, 1, 5, 'workout.exercise', 'day', 5),
(327, 1, 6, 'workout.exercise', 'day', 6),
(328, 1, 7, 'workout.exercise', 'day', 7),
(329, 1, 8, 'workout.exercise', 'day', 8),
(330, 1, 9, 'workout.exercise', 'day', 9),
(331, 2, 10, 'workout.exercise', 'day', 1),
(332, 2, 11, 'workout.exercise', 'day', 2),
(333, 2, 12, 'workout.exercise', 'day', 3),
(334, 2, 13, 'workout.exercise', 'day', 4),
(335, 2, 14, 'workout.exercise', 'day', 5),
(336, 2, 15, 'workout.exercise', 'day', 6),
(337, 2, 16, 'workout.exercise', 'day', 7),
(338, 2, 17, 'workout.exercise', 'day', 8),
(339, 2, 18, 'workout.exercise', 'day', 9),
(340, 2, 19, 'workout.exercise', 'day', 10),
(341, 3, 20, 'workout.exercise', 'day', 1),
(342, 3, 21, 'workout.exercise', 'day', 2),
(343, 3, 22, 'workout.exercise', 'day', 3),
(344, 3, 23, 'workout.exercise', 'day', 4),
(345, 3, 24, 'workout.exercise', 'day', 5),
(346, 3, 25, 'workout.exercise', 'day', 6),
(347, 3, 26, 'workout.exercise', 'day', 7),
(348, 3, 27, 'workout.exercise', 'day', 8),
(349, 3, 28, 'workout.exercise', 'day', 9),
(350, 3, 29, 'workout.exercise', 'day', 10),
(377, 7, 57, 'workout.exercise', 'day', 1),
(378, 7, 58, 'workout.exercise', 'day', 2),
(379, 7, 59, 'workout.exercise', 'day', 3),
(380, 7, 60, 'workout.exercise', 'day', 4),
(381, 7, 61, 'workout.exercise', 'day', 5),
(382, 7, 62, 'workout.exercise', 'day', 6),
(383, 7, 63, 'workout.exercise', 'day', 7),
(384, 7, 64, 'workout.exercise', 'day', 8),
(385, 8, 65, 'workout.exercise', 'day', 1),
(386, 8, 66, 'workout.exercise', 'day', 2),
(387, 8, 67, 'workout.exercise', 'day', 3),
(388, 8, 68, 'workout.exercise', 'day', 4),
(389, 8, 69, 'workout.exercise', 'day', 5),
(390, 8, 70, 'workout.exercise', 'day', 6),
(391, 8, 71, 'workout.exercise', 'day', 7),
(392, 8, 72, 'workout.exercise', 'day', 8),
(393, 9, 73, 'workout.exercise', 'day', 1),
(394, 9, 74, 'workout.exercise', 'day', 2),
(395, 9, 75, 'workout.exercise', 'day', 3),
(396, 9, 76, 'workout.exercise', 'day', 4),
(397, 9, 77, 'workout.exercise', 'day', 5),
(398, 9, 78, 'workout.exercise', 'day', 6),
(399, 9, 79, 'workout.exercise', 'day', 7),
(400, 9, 80, 'workout.exercise', 'day', 8),
(401, 9, 81, 'workout.exercise', 'day', 9),
(402, 9, 82, 'workout.exercise', 'day', 10),
(429, 10, 83, 'workout.exercise', 'day', 1),
(430, 10, 84, 'workout.exercise', 'day', 2),
(431, 10, 85, 'workout.exercise', 'day', 3),
(432, 10, 86, 'workout.exercise', 'day', 4),
(433, 10, 87, 'workout.exercise', 'day', 5),
(434, 10, 88, 'workout.exercise', 'day', 6),
(435, 10, 89, 'workout.exercise', 'day', 7),
(436, 11, 90, 'workout.exercise', 'day', 1),
(437, 11, 91, 'workout.exercise', 'day', 2),
(438, 11, 92, 'workout.exercise', 'day', 3),
(439, 11, 93, 'workout.exercise', 'day', 4),
(440, 11, 94, 'workout.exercise', 'day', 5),
(441, 11, 95, 'workout.exercise', 'day', 6),
(442, 11, 96, 'workout.exercise', 'day', 7),
(443, 11, 97, 'workout.exercise', 'day', 8),
(444, 11, 98, 'workout.exercise', 'day', 9),
(445, 12, 99, 'workout.exercise', 'day', 1),
(446, 12, 100, 'workout.exercise', 'day', 2),
(447, 12, 101, 'workout.exercise', 'day', 3),
(448, 12, 102, 'workout.exercise', 'day', 4),
(449, 12, 103, 'workout.exercise', 'day', 5),
(450, 12, 104, 'workout.exercise', 'day', 6),
(451, 12, 105, 'workout.exercise', 'day', 7),
(452, 12, 106, 'workout.exercise', 'day', 8),
(453, 12, 107, 'workout.exercise', 'day', 9),
(454, 12, 108, 'workout.exercise', 'day', 10),
(455, 4, 30, 'workout.exercise', 'day', 1),
(456, 4, 31, 'workout.exercise', 'day', 2),
(457, 4, 32, 'workout.exercise', 'day', 3),
(458, 4, 33, 'workout.exercise', 'day', 4),
(459, 4, 34, 'workout.exercise', 'day', 5),
(460, 4, 35, 'workout.exercise', 'day', 6),
(461, 4, 36, 'workout.exercise', 'day', 7),
(462, 5, 37, 'workout.exercise', 'day', 1),
(463, 5, 38, 'workout.exercise', 'day', 2),
(464, 5, 39, 'workout.exercise', 'day', 3),
(465, 5, 40, 'workout.exercise', 'day', 4),
(466, 5, 41, 'workout.exercise', 'day', 5),
(467, 5, 42, 'workout.exercise', 'day', 6),
(468, 5, 43, 'workout.exercise', 'day', 7),
(469, 5, 44, 'workout.exercise', 'day', 8),
(470, 5, 45, 'workout.exercise', 'day', 9),
(471, 5, 46, 'workout.exercise', 'day', 10),
(472, 5, 47, 'workout.exercise', 'day', 11),
(473, 6, 48, 'workout.exercise', 'day', 1),
(474, 6, 49, 'workout.exercise', 'day', 2),
(475, 6, 50, 'workout.exercise', 'day', 3),
(476, 6, 51, 'workout.exercise', 'day', 4),
(477, 6, 52, 'workout.exercise', 'day', 5),
(478, 6, 53, 'workout.exercise', 'day', 6),
(479, 6, 54, 'workout.exercise', 'day', 7),
(480, 6, 55, 'workout.exercise', 'day', 8),
(481, 6, 56, 'workout.exercise', 'day', 9);

INSERT INTO "public"."components_workout_exercises" ("id", "sets", "reps", "title") VALUES
(1, 3, 10, 'Cat Cow Strech'),
(2, 3, 10, 'Golf Ball Foot Hurdles'),
(3, 3, 10, 'Follow-through with Bands'),
(4, 3, 3, 'Single-Leg Standing Balance'),
(5, 3, 4, 'Standing Anti-rotation with Bands'),
(6, 3, 30, 'Standing Calf Raise'),
(7, 3, 10, 'Standing Row with Bands'),
(8, 3, 10, 'Toe Raises with looped Band'),
(9, 3, 10, 'Single Arm Row one Foot'),
(10, 3, 10, 'Standing Hip Opener'),
(11, 3, 3, 'Wrist Flexion & Extension'),
(12, 3, 10, 'Hand Extension'),
(13, 3, 10, 'Hip Tilt with Stability Ball'),
(14, 3, 5, 'Lateral Movement with looped Band'),
(15, 3, 20, 'Fingertips Wall Push-Pups'),
(16, 3, 20, 'Wrist Curls'),
(17, 3, 25, 'Hip Bridges'),
(18, 3, 20, 'Reverse Wrist Curls'),
(19, 3, 20, 'Lateral Wrist Raises'),
(20, 3, 10, 'Internal Rotation with Band'),
(21, 3, 10, 'External Rotation with Band'),
(22, 3, 3, 'Biceps Stretch'),
(23, 3, 10, 'Forearm Slides'),
(24, 3, 3, 'Straight Arm Planks'),
(25, 3, 10, 'Wrist Pronation with Band'),
(26, 3, 10, 'Wrist Supination with Band'),
(27, 3, 10, 'Shoulder Blade Retraction with Band'),
(28, 3, 10, 'Triceps Extensions'),
(29, 3, 10, 'Single Arm Flies witn Bands'),
(30, 3, 5, 'Omni Directional Movement'),
(31, 3, 10, 'Romanian Deadlift'),
(32, 3, 10, 'Rotation with Eyes on the Ball'),
(33, 3, 10, 'Lunges with Rotation'),
(34, 3, 20, 'Hamstring Curls'),
(35, 3, 1, 'Manual Resistance'),
(36, 3, 20, 'Split Lunge'),
(37, 3, 10, 'Cat Cow Stretch'),
(38, 3, 10, 'Follow-Through with Bands'),
(39, 3, 3, 'Wrist Flexion & Extension'),
(40, 3, 10, 'Hand Extension'),
(41, 3, 4, 'Standing Anti Rotation with Band'),
(42, 3, 20, 'Fingertips Wall Push-Ups'),
(43, 3, 10, 'Standing Row with Band'),
(44, 3, 20, 'Wrist Curls'),
(45, 3, 20, 'Recerse Wrist Curls'),
(46, 3, 20, 'Lateral Wrist Raises'),
(47, 3, 10, 'Single Arm Row one Foot'),
(48, 3, 10, 'Standing Hip Opener'),
(49, 3, 10, 'Hip Tilt with Stability Ball'),
(50, 3, 10, 'Biceps Stretch'),
(51, 3, 3, 'Straight Arm Planks'),
(52, 3, 5, 'Lateral Movements with looped Band'),
(53, 3, 10, 'Triceps Extension'),
(54, 3, 10, 'Wrist Pronation with Band'),
(55, 3, 10, 'Wrist Supination with Band'),
(56, 3, 25, 'Hip Bridges'),
(57, 3, 10, 'Internal Rotation with Band'),
(58, 3, 10, 'External Rotation with Band'),
(59, 3, 5, 'Omni Directional Mvement'),
(60, 3, 10, 'Forearm Slides'),
(61, 3, 10, 'Rotation with Eyes on Ball'),
(62, 3, 10, 'Shoulder Blade Retraction with Band'),
(63, 3, 10, 'Single Arm Flies with Band'),
(64, 3, 10, 'Romanian Deadlift'),
(65, 3, 10, 'Golf Ball Foot Hurdles'),
(66, 3, 10, 'Romanian Deadlift'),
(67, 3, 3, 'Single-Leg Standing Balance'),
(68, 3, 10, 'Lunges with Rotation'),
(69, 3, 10, 'Toe Raises with looped Band'),
(70, 3, 20, 'Hamstring Curls'),
(71, 3, 20, 'Split Lunge'),
(72, 3, 30, 'Standing Calf Raises'),
(73, 3, 10, 'Cat Cow Stretch'),
(74, 3, 3, 'Biceps Stretch'),
(75, 3, 10, 'Follow Through with Bands'),
(76, 3, 4, 'Standing Anti Rotation with Bands'),
(77, 3, 3, 'Straight Arm Planks'),
(78, 3, 10, 'Standing Row with Bands'),
(79, 3, 10, 'Wrist Pronation with Bands'),
(80, 3, 10, 'Wrist Supination with Bands'),
(81, 3, 10, 'Single Arm Row one Foot'),
(82, 3, 10, 'Triceps Extensions'),
(83, 3, 10, 'Standing Hip Opener'),
(84, 3, 10, 'Hip Tilt with Stability Ball'),
(85, 3, 5, 'Omni Directional Movement'),
(86, 3, 5, 'Lateral Movement with looped Band'),
(87, 3, 10, 'Rotation with Eyes on the Ball'),
(88, 3, 25, 'Hip Bridges'),
(89, 3, 1, 'Manual Resistance'),
(90, 3, 10, 'Internal Rotation with Band'),
(91, 3, 10, 'External Rotation with Band'),
(92, 3, 10, 'Golf Ball Foot Hurdles'),
(93, 3, 10, 'Forearm Slides'),
(94, 3, 3, 'Single-Leg Standing Balance'),
(95, 3, 10, 'Toe Raises with looped Band'),
(96, 3, 10, 'Shoulder Blade Retraction with Band'),
(97, 3, 30, 'Standing Calf Raises'),
(98, 3, 10, 'Single Arm Flies with Band'),
(99, 3, 10, 'Romanian Deadlift'),
(100, 3, 3, 'Wrist Flexion & Extension'),
(101, 3, 10, 'Hand Extension'),
(102, 3, 10, 'Lunges with Rotation'),
(103, 3, 20, 'Fingertips Wall Push-Ups'),
(104, 3, 20, 'Hamstring Curls'),
(105, 3, 20, 'Wrist Curls'),
(106, 3, 20, 'Reverse Wrist Curls'),
(107, 3, 20, 'Lateral Wrist Raises'),
(108, 3, 20, 'Split Lunge');

INSERT INTO "public"."components_workout_exercises_exercise_links" ("id", "exercise_id", "inv_exercise_id") VALUES
(321, 1, 13),
(322, 2, 1),
(323, 3, 14),
(324, 4, 2),
(325, 5, 15),
(326, 6, 3),
(327, 7, 16),
(328, 8, 4),
(329, 9, 17),
(330, 10, 10),
(331, 11, 31),
(332, 12, 32),
(333, 13, 9),
(334, 14, 11),
(335, 15, 33),
(336, 16, 34),
(337, 17, 12),
(338, 18, 35),
(339, 19, 36),
(340, 20, 22),
(341, 21, 23),
(342, 22, 26),
(343, 23, 21),
(344, 24, 27),
(345, 25, 29),
(346, 26, 30),
(347, 27, 25),
(348, 28, 28),
(349, 29, 24),
(376, 57, 22),
(377, 58, 23),
(378, 59, 18),
(379, 60, 21),
(380, 61, 19),
(381, 62, 25),
(382, 63, 24),
(383, 64, 5),
(384, 65, 1),
(385, 66, 5),
(386, 67, 2),
(387, 68, 6),
(388, 69, 4),
(389, 70, 8),
(390, 71, 7),
(391, 72, 3),
(392, 73, 13),
(393, 74, 26),
(394, 75, 14),
(395, 76, 15),
(396, 77, 27),
(397, 78, 16),
(398, 79, 29),
(399, 80, 30),
(400, 81, 17),
(401, 82, 28),
(428, 83, 10),
(429, 84, 9),
(430, 85, 18),
(431, 86, 11),
(432, 87, 19),
(433, 88, 12),
(434, 89, 20),
(435, 90, 22),
(436, 91, 23),
(437, 92, 1),
(438, 93, 21),
(439, 94, 2),
(440, 95, 4),
(441, 96, 25),
(442, 97, 3),
(443, 98, 24),
(444, 99, 5),
(445, 100, 31),
(446, 101, 32),
(447, 102, 6),
(448, 103, 33),
(449, 104, 8),
(450, 105, 34),
(451, 106, 35),
(452, 107, 36),
(453, 108, 7),
(454, 30, 18),
(455, 31, 5),
(456, 32, 19),
(457, 33, 6),
(458, 34, 8),
(459, 35, 20),
(460, 36, 7),
(461, 37, 13),
(462, 38, 14),
(463, 39, 31),
(464, 40, 32),
(465, 41, 15),
(466, 42, 33),
(467, 43, 16),
(468, 44, 34),
(469, 45, 35),
(470, 46, 36),
(471, 47, 17),
(472, 48, 10),
(473, 49, 9),
(474, 50, 26),
(475, 51, 27),
(476, 52, 11),
(477, 53, 28),
(478, 54, 29),
(479, 55, 30),
(480, 56, 12);

INSERT INTO "public"."exercises" ("id", "title", "slug", "purpose", "created_at", "updated_at", "published_at", "created_by_id", "updated_by_id", "test") VALUES
(1, 'Golf Ball Foot Hurdles', 'golf-ball-foot-hurdles', 'Ankle & Foot Mobility', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(2, 'Single-Leg Standing Balance', 'single-leg-standing-balance', 'Ankle Stability', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(3, 'Standing Calf Raise', 'standing-calf-raise', 'Gastrocnemius Strength at the ankle', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(4, 'Toe Raises with looped Band', 'toe-raises-with-looped-band', 'Antereor Tibialis Strength at the Ankle', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(5, 'Romanian deadlift', 'romanian-deadlift', 'Knee Mobility & Hamstring Strength', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(6, 'Lunges with Rotation', 'lunges-with-rotation', 'Knee Stability', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(7, 'Split Lunge', 'split-lunge', 'Quadriceps Strength at the Knee', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(8, 'Hamstring Curls', 'hamstring-curls', 'Hamstring Strength at the Knee', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(9, 'Hip Tilt with Stability Ball', 'hip-tilt-with-stability-ball', 'Hip Mobility', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(10, 'Standing Hip Opener', 'standing-hip-opener', 'Hip Mobility', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(11, 'Lateral Movement with looped band', 'lateral-movement-with-looped-band', 'Hip Stability', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(12, 'Hip Bridges', 'hip-bridges', 'Glute Strength at the Hips', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(13, 'Cat Cow Stretch', 'cat-cow-stretch', 'Spinal Mobility', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(14, 'Follow-Through with Bands', 'follow-through-with-bands', 'Spinal Mobility', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(15, 'Standing Anti-Rotation with Bands', 'standing-anti-rotation-with-bands', 'Spinal Stability', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(16, 'Standing Row with Bands', 'standing-row-with-bands', 'Latissimus Dorsi & Rhoboid Strength at the Spine', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(17, 'Single Arm Row one Foot', 'single-arm-row-one-foot', 'Latissimus Dorsi Strength at the Spine', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(18, 'Omni Directional Movement', 'omni-directional-movement', 'Neck Mobility', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(19, 'Rotation with Eyes on the Ball', 'rotation-with-eyes-on-the-ball', 'Neck Stability', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(20, 'Manual Resistance', 'manual-resistence', 'Neck Strength', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(21, 'Forearm Slides', 'forearm-slides', 'Shoulder Stability', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(22, 'Internal Rotation with Band', 'internal-rotation-with-band', 'Shoulder Mobility', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(23, 'External Rotation with Band', 'external-rotation-with-band', 'Shoulder Mobility', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(24, 'Single Arm Flies with Band', 'single-arm-flies-with-band', 'Chest Strength at the Shoulder', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(25, 'Shoulder Blade Retraction with Band', 'shoulder-blade-retraction-with-band', 'Rhomboid Strength at the Shoulder', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(26, 'Biceps Stretch', 'biceps-stretch', 'Elbow Mobility', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(27, 'Straight Arm Planks', 'straight-arm-planks', 'Elbow Stability', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(28, 'Triceps Extensions', 'triceps-extensions', 'Triceps Strength at the Elbow', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(29, 'Wrist Pronation with Band', 'wrist-pronation-with-band', 'Forearm Strength at the Elbow', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(30, 'Wrist Supination with Band', 'wrist-supination-with-band', 'Forearm Strength at the Elbow', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(31, 'Wrist Flexion & Extension', 'wrist-flexion-and-extension', 'Wrist Mobility', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(32, 'Hand Extension', 'hand-extension', 'Hand Mobility', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(33, 'Fingertips Wall Push-Ups', 'fingertips-wall-push-ups', 'Wrist & Hand Stability', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(34, 'Wrist Curls', 'wrist-curls', 'Forearm Strength at the Wrist', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(35, 'Revers Wrist Curls', 'revers-wrist-curls', 'Forearm Strength at the Wrist', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL),
(36, 'Lateral Wrist Raises', 'lateral-wrist-curls', 'Forearm Strength at the Wrist', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, 1, NULL);

INSERT INTO "public"."exercises_categories_links" ("id", "exercise_id", "category_id", "category_order", "exercise_order") VALUES
(3, 1, 1, 1, 1),
(4, 1, 4, NULL, NULL),
(24, 5, 1, 1, 2),
(25, 5, 3, NULL, NULL),
(26, 5, 5, NULL, NULL),
(31, 6, 2, 1, 1),
(35, 7, 3, NULL, NULL),
(36, 7, 5, NULL, NULL),
(39, 8, 3, NULL, NULL),
(40, 8, 5, NULL, NULL),
(43, 9, 6, NULL, NULL),
(44, 9, 1, 1, 3),
(48, 10, 1, 1, 4),
(49, 10, 6, NULL, NULL),
(52, 11, 2, NULL, NULL),
(53, 11, 6, NULL, NULL),
(56, 12, 3, NULL, NULL),
(57, 12, 6, NULL, NULL),
(60, 13, 1, 1, 5),
(61, 13, 7, NULL, NULL),
(64, 14, 1, 1, 6),
(65, 14, 7, NULL, NULL),
(68, 15, 2, NULL, NULL),
(69, 15, 7, NULL, NULL),
(72, 16, 3, NULL, NULL),
(73, 16, 7, NULL, NULL),
(76, 17, 3, NULL, NULL),
(77, 17, 7, NULL, NULL),
(80, 18, 1, 1, 7),
(81, 18, 8, NULL, NULL),
(84, 19, 2, NULL, NULL),
(85, 19, 8, NULL, NULL),
(88, 20, 3, NULL, NULL),
(89, 20, 8, NULL, NULL),
(92, 21, 9, NULL, NULL),
(93, 21, 2, NULL, NULL),
(96, 22, 1, 1, 8),
(97, 22, 9, NULL, NULL),
(100, 23, 1, 1, 9),
(101, 23, 9, NULL, NULL),
(104, 24, 3, NULL, NULL),
(105, 24, 9, NULL, NULL),
(108, 25, 3, NULL, NULL),
(109, 25, 9, NULL, NULL),
(112, 26, 10, 2, 1),
(113, 26, 1, 1, 1),
(116, 28, 3, NULL, NULL),
(117, 28, 10, NULL, NULL),
(122, 29, 3, NULL, NULL),
(123, 29, 10, NULL, NULL),
(128, 30, 3, NULL, NULL),
(129, 30, 10, NULL, NULL),
(134, 31, 1, 1, 11),
(135, 31, 11, NULL, NULL),
(138, 32, 1, 1, 12),
(139, 32, 11, NULL, NULL),
(142, 33, 2, NULL, NULL),
(143, 33, 11, NULL, NULL),
(146, 34, 3, NULL, NULL),
(147, 34, 11, NULL, NULL),
(148, 35, 3, NULL, NULL),
(149, 35, 11, NULL, NULL),
(152, 36, 3, NULL, NULL),
(153, 36, 11, NULL, NULL),
(154, 4, 3, NULL, NULL),
(155, 4, 4, NULL, NULL),
(156, 2, 2, NULL, NULL),
(157, 2, 4, NULL, NULL),
(158, 3, 3, 1, 1),
(160, 27, 2, 1, 1),
(161, 27, 10, 2, 1),
(162, 6, 5, 2, 1),
(163, 3, 4, 2, 1);

INSERT INTO "public"."exercises_components" ("id", "entity_id", "component_id", "component_type", "field", "order") VALUES
(1, 1, 1, 'exercises.steps', 'Body', 1),
(2, 1, 1, 'exercises.progressions', 'Body', 2),
(12, 5, 5, 'exercises.steps', 'Body', 1),
(13, 5, 4, 'exercises.progressions', 'Body', 2),
(17, 7, 7, 'exercises.steps', 'Body', 1),
(18, 7, 4, 'exercises.description', 'Body', 2),
(19, 7, 6, 'exercises.progressions', 'Body', 3),
(20, 8, 5, 'exercises.description', 'Body', 1),
(21, 8, 8, 'exercises.steps', 'Body', 2),
(22, 8, 7, 'exercises.progressions', 'Body', 3),
(23, 9, 6, 'exercises.description', 'Body', 1),
(24, 9, 9, 'exercises.steps', 'Body', 2),
(25, 9, 7, 'exercises.description', 'Body', 3),
(26, 10, 10, 'exercises.steps', 'Body', 1),
(27, 11, 8, 'exercises.description', 'Body', 1),
(28, 11, 11, 'exercises.steps', 'Body', 2),
(29, 11, 8, 'exercises.progressions', 'Body', 3),
(30, 12, 12, 'exercises.steps', 'Body', 1),
(31, 12, 9, 'exercises.progressions', 'Body', 2),
(32, 13, 9, 'exercises.description', 'Body', 1),
(33, 13, 13, 'exercises.steps', 'Body', 2),
(34, 14, 14, 'exercises.steps', 'Body', 1),
(35, 15, 10, 'exercises.description', 'Body', 1),
(36, 15, 15, 'exercises.steps', 'Body', 2),
(37, 15, 10, 'exercises.progressions', 'Body', 3),
(38, 16, 11, 'exercises.description', 'Body', 1),
(39, 16, 16, 'exercises.steps', 'Body', 2),
(40, 16, 12, 'exercises.description', 'Body', 3),
(41, 16, 11, 'exercises.progressions', 'Body', 4),
(42, 17, 17, 'exercises.steps', 'Body', 1),
(43, 17, 12, 'exercises.progressions', 'Body', 2),
(44, 18, 13, 'exercises.description', 'Body', 1),
(45, 18, 18, 'exercises.steps', 'Body', 2),
(46, 19, 19, 'exercises.steps', 'Body', 1),
(47, 20, 14, 'exercises.description', 'Body', 1),
(48, 20, 20, 'exercises.steps', 'Body', 2),
(49, 21, 21, 'exercises.steps', 'Body', 1),
(50, 21, 13, 'exercises.progressions', 'Body', 2),
(51, 22, 22, 'exercises.steps', 'Body', 1),
(52, 23, 15, 'exercises.description', 'Body', 1),
(53, 23, 23, 'exercises.steps', 'Body', 2),
(54, 23, 16, 'exercises.description', 'Body', 3),
(55, 24, 17, 'exercises.description', 'Body', 1),
(56, 24, 24, 'exercises.steps', 'Body', 2),
(57, 25, 18, 'exercises.description', 'Body', 1),
(58, 25, 25, 'exercises.steps', 'Body', 2),
(59, 25, 19, 'exercises.description', 'Body', 3),
(60, 26, 20, 'exercises.description', 'Body', 1),
(61, 26, 26, 'exercises.steps', 'Body', 2),
(65, 28, 28, 'exercises.steps', 'Body', 1),
(66, 28, 15, 'exercises.progressions', 'Body', 2),
(67, 29, 29, 'exercises.steps', 'Body', 1),
(69, 30, 30, 'exercises.steps', 'Body', 1),
(72, 31, 22, 'exercises.description', 'Body', 1),
(73, 31, 31, 'exercises.steps', 'Body', 2),
(74, 31, 23, 'exercises.description', 'Body', 3),
(75, 32, 24, 'exercises.description', 'Body', 1),
(76, 32, 32, 'exercises.steps', 'Body', 2),
(77, 33, 33, 'exercises.steps', 'Body', 1),
(78, 33, 16, 'exercises.progressions', 'Body', 2),
(79, 34, 34, 'exercises.steps', 'Body', 1),
(80, 35, 35, 'exercises.steps', 'Body', 1),
(81, 36, 36, 'exercises.steps', 'Body', 1),
(82, 4, 4, 'exercises.steps', 'Body', 1),
(83, 4, 3, 'exercises.description', 'Body', 2),
(84, 2, 2, 'exercises.steps', 'Body', 1),
(85, 2, 1, 'exercises.description', 'Body', 2),
(86, 2, 2, 'exercises.progressions', 'Body', 3),
(89, 27, 21, 'exercises.description', 'Body', 1),
(90, 27, 27, 'exercises.steps', 'Body', 2),
(91, 27, 14, 'exercises.progressions', 'Body', 3),
(92, 6, 6, 'exercises.steps', 'Body', 1),
(93, 6, 5, 'exercises.progressions', 'Body', 2),
(94, 3, 3, 'exercises.steps', 'Body', 1),
(95, 3, 3, 'exercises.progressions', 'Body', 2);

INSERT INTO "public"."files" ("id", "name", "alternative_text", "caption", "width", "height", "formats", "hash", "ext", "mime", "size", "url", "preview_url", "provider", "provider_metadata", "folder_path", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(5, 'cat-cow-stretch-550x235-step-1.png', 'cat-cow-stretch-550x235-step-1.png', 'cat-cow-stretch-550x235-step-1.png', 522, 235, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_cat_cow_stretch_550x235_step_1_ba848b636c.png", "hash": "thumbnail_cat_cow_stretch_550x235_step_1_ba848b636c", "mime": "image/png", "name": "thumbnail_cat-cow-stretch-550x235-step-1.png", "path": null, "size": 30.1, "width": 245, "height": 110}}', 'cat_cow_stretch_550x235_step_1_ba848b636c', '.png', 'image/png', 91.45, '/uploads/cat_cow_stretch_550x235_step_1_ba848b636c.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(6, 'cat-cow-stretch-550x235-step-3.png', 'cat-cow-stretch-550x235-step-3.png', 'cat-cow-stretch-550x235-step-3.png', 509, 276, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_cat_cow_stretch_550x235_step_3_a3c6898260.png", "hash": "thumbnail_cat_cow_stretch_550x235_step_3_a3c6898260", "mime": "image/png", "name": "thumbnail_cat-cow-stretch-550x235-step-3.png", "path": null, "size": 29.8, "width": 245, "height": 133}}', 'cat_cow_stretch_550x235_step_3_a3c6898260', '.png', 'image/png', 91.89, '/uploads/cat_cow_stretch_550x235_step_3_a3c6898260.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(7, 'cat-cow-stretch-550x235-step-2.png', 'cat-cow-stretch-550x235-step-2.png', 'cat-cow-stretch-550x235-step-2.png', 518, 235, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_cat_cow_stretch_550x235_step_2_c9616b10c8.png", "hash": "thumbnail_cat_cow_stretch_550x235_step_2_c9616b10c8", "mime": "image/png", "name": "thumbnail_cat-cow-stretch-550x235-step-2.png", "path": null, "size": 30.01, "width": 245, "height": 111}}', 'cat_cow_stretch_550x235_step_2_c9616b10c8', '.png', 'image/png', 95.39, '/uploads/cat_cow_stretch_550x235_step_2_c9616b10c8.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(8, 'biceps-stretch-275x300-step-1.png', 'biceps-stretch-275x300-step-1.png', 'biceps-stretch-275x300-step-1.png', 275, 260, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_biceps_stretch_275x300_step_1_52fc9799da.png", "hash": "thumbnail_biceps_stretch_275x300_step_1_52fc9799da", "mime": "image/png", "name": "thumbnail_biceps-stretch-275x300-step-1.png", "path": null, "size": 31.95, "width": 165, "height": 156}}', 'biceps_stretch_275x300_step_1_52fc9799da', '.png', 'image/png', 68.93, '/uploads/biceps_stretch_275x300_step_1_52fc9799da.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(9, 'biceps-stretch-275x300-step-2.png', 'biceps-stretch-275x300-step-2.png', 'biceps-stretch-275x300-step-2.png', 265, 241, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_biceps_stretch_275x300_step_2_79d396cb2d.png", "hash": "thumbnail_biceps_stretch_275x300_step_2_79d396cb2d", "mime": "image/png", "name": "thumbnail_biceps-stretch-275x300-step-2.png", "path": null, "size": 37.68, "width": 172, "height": 156}}', 'biceps_stretch_275x300_step_2_79d396cb2d', '.png', 'image/png', 66.50, '/uploads/biceps_stretch_275x300_step_2_79d396cb2d.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(10, 'external-rotation-with-band-275x410-step-1.png', 'external-rotation-with-band-275x410-step-1.png', 'external-rotation-with-band-275x410-step-1.png', 233, 408, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_external_rotation_with_band_275x410_step_1_ddf1f6b665.png", "hash": "thumbnail_external_rotation_with_band_275x410_step_1_ddf1f6b665", "mime": "image/png", "name": "thumbnail_external-rotation-with-band-275x410-step-1.png", "path": null, "size": 15.57, "width": 89, "height": 156}}', 'external_rotation_with_band_275x410_step_1_ddf1f6b665', '.png', 'image/png', 66.58, '/uploads/external_rotation_with_band_275x410_step_1_ddf1f6b665.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(11, 'follow-through-with-bands-275x340-step-3.png', 'follow-through-with-bands-275x340-step-3.png', 'follow-through-with-bands-275x340-step-3.png', 275, 331, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_follow_through_with_bands_275x340_step_3_5afce4ffd0.png", "hash": "thumbnail_follow_through_with_bands_275x340_step_3_5afce4ffd0", "mime": "image/png", "name": "thumbnail_follow-through-with-bands-275x340-step-3.png", "path": null, "size": 19.74, "width": 130, "height": 156}}', 'follow_through_with_bands_275x340_step_3_5afce4ffd0', '.png', 'image/png', 60.40, '/uploads/follow_through_with_bands_275x340_step_3_5afce4ffd0.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(12, 'external-rotation-with-band-275x410-step-2.png', 'external-rotation-with-band-275x410-step-2.png', 'external-rotation-with-band-275x410-step-2.png', 230, 410, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_external_rotation_with_band_275x410_step_2_ded3b54a3f.png", "hash": "thumbnail_external_rotation_with_band_275x410_step_2_ded3b54a3f", "mime": "image/png", "name": "thumbnail_external-rotation-with-band-275x410-step-2.png", "path": null, "size": 15.77, "width": 88, "height": 156}}', 'external_rotation_with_band_275x410_step_2_ded3b54a3f', '.png', 'image/png', 67.86, '/uploads/external_rotation_with_band_275x410_step_2_ded3b54a3f.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(13, 'fingertip-wall-pushes-275x340-step-1.png', 'fingertip-wall-pushes-275x340-step-1.png', 'fingertip-wall-pushes-275x340-step-1.png', 275, 317, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_fingertip_wall_pushes_275x340_step_1_ac9d223552.png", "hash": "thumbnail_fingertip_wall_pushes_275x340_step_1_ac9d223552", "mime": "image/png", "name": "thumbnail_fingertip-wall-pushes-275x340-step-1.png", "path": null, "size": 28.02, "width": 135, "height": 156}}', 'fingertip_wall_pushes_275x340_step_1_ac9d223552', '.png', 'image/png', 74.50, '/uploads/fingertip_wall_pushes_275x340_step_1_ac9d223552.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(14, 'fingertip-wall-pushes-275x340-step-2.png', 'fingertip-wall-pushes-275x340-step-2.png', 'fingertip-wall-pushes-275x340-step-2.png', 268, 316, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_fingertip_wall_pushes_275x340_step_2_fe764a9e46.png", "hash": "thumbnail_fingertip_wall_pushes_275x340_step_2_fe764a9e46", "mime": "image/png", "name": "thumbnail_fingertip-wall-pushes-275x340-step-2.png", "path": null, "size": 27.39, "width": 132, "height": 156}}', 'fingertip_wall_pushes_275x340_step_2_fe764a9e46', '.png', 'image/png', 72.25, '/uploads/fingertip_wall_pushes_275x340_step_2_fe764a9e46.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(15, 'follow-through-with-bands-275x410-step-1.png', 'follow-through-with-bands-275x410-step-1.png', 'follow-through-with-bands-275x410-step-1.png', 263, 410, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_follow_through_with_bands_275x410_step_1_d93f9cfa05.png", "hash": "thumbnail_follow_through_with_bands_275x410_step_1_d93f9cfa05", "mime": "image/png", "name": "thumbnail_follow-through-with-bands-275x410-step-1.png", "path": null, "size": 14.37, "width": 100, "height": 156}}', 'follow_through_with_bands_275x410_step_1_d93f9cfa05', '.png', 'image/png', 69.19, '/uploads/follow_through_with_bands_275x410_step_1_d93f9cfa05.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(16, 'forearm-slides-275x340-step-1.png', 'forearm-slides-275x340-step-1.png', 'forearm-slides-275x340-step-1.png', 267, 340, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_forearm_slides_275x340_step_1_6ec62e5046.png", "hash": "thumbnail_forearm_slides_275x340_step_1_6ec62e5046", "mime": "image/png", "name": "thumbnail_forearm-slides-275x340-step-1.png", "path": null, "size": 23.52, "width": 123, "height": 156}}', 'forearm_slides_275x340_step_1_6ec62e5046', '.png', 'image/png', 76.66, '/uploads/forearm_slides_275x340_step_1_6ec62e5046.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(17, 'forearm-slides-275x340-step-2.png', 'forearm-slides-275x340-step-2.png', 'forearm-slides-275x340-step-2.png', 243, 340, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_forearm_slides_275x340_step_2_eb817d9744.png", "hash": "thumbnail_forearm_slides_275x340_step_2_eb817d9744", "mime": "image/png", "name": "thumbnail_forearm-slides-275x340-step-2.png", "path": null, "size": 22.9, "width": 111, "height": 156}}', 'forearm_slides_275x340_step_2_eb817d9744', '.png', 'image/png', 69.50, '/uploads/forearm_slides_275x340_step_2_eb817d9744.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(18, 'golf-ball-foot-hurdles-275x340-prog-1.png', 'golf-ball-foot-hurdles-275x340-prog-1.png', 'golf-ball-foot-hurdles-275x340-prog-1.png', 255, 340, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_golf_ball_foot_hurdles_275x340_prog_1_260caf371d.png", "hash": "thumbnail_golf_ball_foot_hurdles_275x340_prog_1_260caf371d", "mime": "image/png", "name": "thumbnail_golf-ball-foot-hurdles-275x340-prog-1.png", "path": null, "size": 28.42, "width": 117, "height": 156}}', 'golf_ball_foot_hurdles_275x340_prog_1_260caf371d', '.png', 'image/png', 85.03, '/uploads/golf_ball_foot_hurdles_275x340_prog_1_260caf371d.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(19, 'hamstring-curls-550x235-step-1.png', 'hamstring-curls-550x235-step-1.png', 'hamstring-curls-550x235-step-1.png', 484, 194, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_hamstring_curls_550x235_step_1_c191ad7e03.png", "hash": "thumbnail_hamstring_curls_550x235_step_1_c191ad7e03", "mime": "image/png", "name": "thumbnail_hamstring-curls-550x235-step-1.png", "path": null, "size": 26.99, "width": 245, "height": 98}}', 'hamstring_curls_550x235_step_1_c191ad7e03', '.png', 'image/png', 73.01, '/uploads/hamstring_curls_550x235_step_1_c191ad7e03.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(20, 'follow-through-with-bands-275x410-step-2.png', 'follow-through-with-bands-275x410-step-2.png', 'follow-through-with-bands-275x410-step-2.png', 267, 410, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_follow_through_with_bands_275x410_step_2_9b533cb6be.png", "hash": "thumbnail_follow_through_with_bands_275x410_step_2_9b533cb6be", "mime": "image/png", "name": "thumbnail_follow-through-with-bands-275x410-step-2.png", "path": null, "size": 15.75, "width": 102, "height": 156}}', 'follow_through_with_bands_275x410_step_2_9b533cb6be', '.png', 'image/png', 76.55, '/uploads/follow_through_with_bands_275x410_step_2_9b533cb6be.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(21, 'golf-ball-foot-hurdles-275x340-step-1.png', 'golf-ball-foot-hurdles-275x340-step-1.png', 'golf-ball-foot-hurdles-275x340-step-1.png', 245, 340, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_golf_ball_foot_hurdles_275x340_step_1_1007965809.png", "hash": "thumbnail_golf_ball_foot_hurdles_275x340_step_1_1007965809", "mime": "image/png", "name": "thumbnail_golf-ball-foot-hurdles-275x340-step-1.png", "path": null, "size": 27.84, "width": 112, "height": 156}}', 'golf_ball_foot_hurdles_275x340_step_1_1007965809', '.png', 'image/png', 85.13, '/uploads/golf_ball_foot_hurdles_275x340_step_1_1007965809.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(22, 'golf-ball-foot-hurdles-275x340-step-2.png', 'golf-ball-foot-hurdles-275x340-step-2.png', 'golf-ball-foot-hurdles-275x340-step-2.png', 242, 340, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_golf_ball_foot_hurdles_275x340_step_2_955ae4939d.png", "hash": "thumbnail_golf_ball_foot_hurdles_275x340_step_2_955ae4939d", "mime": "image/png", "name": "thumbnail_golf-ball-foot-hurdles-275x340-step-2.png", "path": null, "size": 27.06, "width": 111, "height": 156}}', 'golf_ball_foot_hurdles_275x340_step_2_955ae4939d', '.png', 'image/png', 81.46, '/uploads/golf_ball_foot_hurdles_275x340_step_2_955ae4939d.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(23, 'hamstring-curls-550x235-step-2.png', 'hamstring-curls-550x235-step-2.png', 'hamstring-curls-550x235-step-2.png', 510, 196, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_hamstring_curls_550x235_step_2_6f4e013629.png", "hash": "thumbnail_hamstring_curls_550x235_step_2_6f4e013629", "mime": "image/png", "name": "thumbnail_hamstring-curls-550x235-step-2.png", "path": null, "size": 25.29, "width": 245, "height": 94}}', 'hamstring_curls_550x235_step_2_6f4e013629', '.png', 'image/png', 75.86, '/uploads/hamstring_curls_550x235_step_2_6f4e013629.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(24, 'hand-extension-275x300-step-1.png', 'hand-extension-275x300-step-1.png', 'hand-extension-275x300-step-1.png', 266, 296, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_hand_extension_275x300_step_1_bcdaa525f3.png", "hash": "thumbnail_hand_extension_275x300_step_1_bcdaa525f3", "mime": "image/png", "name": "thumbnail_hand-extension-275x300-step-1.png", "path": null, "size": 25.22, "width": 140, "height": 156}}', 'hand_extension_275x300_step_1_bcdaa525f3', '.png', 'image/png', 65.65, '/uploads/hand_extension_275x300_step_1_bcdaa525f3.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(25, 'hand-extension-275x300-step-2.png', 'hand-extension-275x300-step-2.png', 'hand-extension-275x300-step-2.png', 267, 294, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_hand_extension_275x300_step_2_235af48000.png", "hash": "thumbnail_hand_extension_275x300_step_2_235af48000", "mime": "image/png", "name": "thumbnail_hand-extension-275x300-step-2.png", "path": null, "size": 28.01, "width": 142, "height": 156}}', 'hand_extension_275x300_step_2_235af48000', '.png', 'image/png', 69.30, '/uploads/hand_extension_275x300_step_2_235af48000.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(26, 'hip-bridges-550x235-step-1.png', 'hip-bridges-550x235-step-1.png', 'hip-bridges-550x235-step-1.png', 513, 211, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_hip_bridges_550x235_step_1_7b3dd6541c.png", "hash": "thumbnail_hip_bridges_550x235_step_1_7b3dd6541c", "mime": "image/png", "name": "thumbnail_hip-bridges-550x235-step-1.png", "path": null, "size": 30.1, "width": 245, "height": 101}}', 'hip_bridges_550x235_step_1_7b3dd6541c', '.png', 'image/png', 90.32, '/uploads/hip_bridges_550x235_step_1_7b3dd6541c.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(27, 'golf-ball-foot-hurdles-275x340-prog-2.png', 'golf-ball-foot-hurdles-275x340-prog-2.png', 'golf-ball-foot-hurdles-275x340-prog-2.png', 248, 340, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_golf_ball_foot_hurdles_275x340_prog_2_7202dae3d4.png", "hash": "thumbnail_golf_ball_foot_hurdles_275x340_prog_2_7202dae3d4", "mime": "image/png", "name": "thumbnail_golf-ball-foot-hurdles-275x340-prog-2.png", "path": null, "size": 27.15, "width": 114, "height": 156}}', 'golf_ball_foot_hurdles_275x340_prog_2_7202dae3d4', '.png', 'image/png', 81.23, '/uploads/golf_ball_foot_hurdles_275x340_prog_2_7202dae3d4.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(28, 'hamstring-curls-550x235-prog-2.png', 'hamstring-curls-550x235-prog-2.png', 'hamstring-curls-550x235-prog-2.png', 532, 207, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_hamstring_curls_550x235_prog_2_b8baeb8a2c.png", "hash": "thumbnail_hamstring_curls_550x235_prog_2_b8baeb8a2c", "mime": "image/png", "name": "thumbnail_hamstring-curls-550x235-prog-2.png", "path": null, "size": 27.27, "width": 245, "height": 95}}', 'hamstring_curls_550x235_prog_2_b8baeb8a2c', '.png', 'image/png', 92.00, '/uploads/hamstring_curls_550x235_prog_2_b8baeb8a2c.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(29, 'hip-bridges-550x235-step-2.png', 'hip-bridges-550x235-step-2.png', 'hip-bridges-550x235-step-2.png', 519, 219, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_hip_bridges_550x235_step_2_618030c776.png", "hash": "thumbnail_hip_bridges_550x235_step_2_618030c776", "mime": "image/png", "name": "thumbnail_hip-bridges-550x235-step-2.png", "path": null, "size": 31.97, "width": 245, "height": 103}}', 'hip_bridges_550x235_step_2_618030c776', '.png', 'image/png', 97.89, '/uploads/hip_bridges_550x235_step_2_618030c776.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(30, 'hamstring-curls-550x235-prog-1.png', 'hamstring-curls-550x235-prog-1.png', 'hamstring-curls-550x235-prog-1.png', 526, 200, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_hamstring_curls_550x235_prog_1_c18ed86615.png", "hash": "thumbnail_hamstring_curls_550x235_prog_1_c18ed86615", "mime": "image/png", "name": "thumbnail_hamstring-curls-550x235-prog-1.png", "path": null, "size": 26.15, "width": 245, "height": 93}}', 'hamstring_curls_550x235_prog_1_c18ed86615', '.png', 'image/png', 85.44, '/uploads/hamstring_curls_550x235_prog_1_c18ed86615.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(31, 'hip-opener-275x410-step-1.png', 'hip-opener-275x410-step-1.png', 'hip-opener-275x410-step-1.png', 264, 410, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_hip_opener_275x410_step_1_f0e1fb8527.png", "hash": "thumbnail_hip_opener_275x410_step_1_f0e1fb8527", "mime": "image/png", "name": "thumbnail_hip-opener-275x410-step-1.png", "path": null, "size": 15.74, "width": 100, "height": 156}}', 'hip_opener_275x410_step_1_f0e1fb8527', '.png', 'image/png', 70.79, '/uploads/hip_opener_275x410_step_1_f0e1fb8527.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(32, 'hip-opener-275x410-step-2.png', 'hip-opener-275x410-step-2.png', 'hip-opener-275x410-step-2.png', 248, 407, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_hip_opener_275x410_step_2_2c7c9dcd1a.png", "hash": "thumbnail_hip_opener_275x410_step_2_2c7c9dcd1a", "mime": "image/png", "name": "thumbnail_hip-opener-275x410-step-2.png", "path": null, "size": 17.79, "width": 95, "height": 156}}', 'hip_opener_275x410_step_2_2c7c9dcd1a', '.png', 'image/png', 80.09, '/uploads/hip_opener_275x410_step_2_2c7c9dcd1a.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(33, 'hip-bridges-550x540-prog-1.png', 'hip-bridges-550x540-prog-1.png', 'hip-bridges-550x540-prog-1.png', 531, 529, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_hip_bridges_550x540_prog_1_85d532087c.png", "hash": "thumbnail_hip_bridges_550x540_prog_1_85d532087c", "mime": "image/png", "name": "thumbnail_hip-bridges-550x540-prog-1.png", "path": null, "size": 33.03, "width": 157, "height": 156}}', 'hip_bridges_550x540_prog_1_85d532087c', '.png', 'image/png', 236.11, '/uploads/hip_bridges_550x540_prog_1_85d532087c.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(34, 'hip-bridges-550x540-prog-2.png', 'hip-bridges-550x540-prog-2.png', 'hip-bridges-550x540-prog-2.png', 519, 598, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_hip_bridges_550x540_prog_2_92bd86e9c8.png", "hash": "thumbnail_hip_bridges_550x540_prog_2_92bd86e9c8", "mime": "image/png", "name": "thumbnail_hip-bridges-550x540-prog-2.png", "path": null, "size": 26.73, "width": 135, "height": 156}}', 'hip_bridges_550x540_prog_2_92bd86e9c8', '.png', 'image/png', 236.54, '/uploads/hip_bridges_550x540_prog_2_92bd86e9c8.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(35, 'hip-tilt-with-stability-ball-275x340-step-1.png', 'hip-tilt-with-stability-ball-275x340-step-1.png', 'hip-tilt-with-stability-ball-275x340-step-1.png', 259, 335, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_hip_tilt_with_stability_ball_275x340_step_1_73e89eac3a.png", "hash": "thumbnail_hip_tilt_with_stability_ball_275x340_step_1_73e89eac3a", "mime": "image/png", "name": "thumbnail_hip-tilt-with-stability-ball-275x340-step-1.png", "path": null, "size": 18.3, "width": 121, "height": 156}}', 'hip_tilt_with_stability_ball_275x340_step_1_73e89eac3a', '.png', 'image/png', 59.38, '/uploads/hip_tilt_with_stability_ball_275x340_step_1_73e89eac3a.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(36, 'hip-tilt-with-stability-ball-275x340-step-2.png', 'hip-tilt-with-stability-ball-275x340-step-2.png', 'hip-tilt-with-stability-ball-275x340-step-2.png', 266, 331, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_hip_tilt_with_stability_ball_275x340_step_2_1cc89dedef.png", "hash": "thumbnail_hip_tilt_with_stability_ball_275x340_step_2_1cc89dedef", "mime": "image/png", "name": "thumbnail_hip-tilt-with-stability-ball-275x340-step-2.png", "path": null, "size": 18.22, "width": 125, "height": 156}}', 'hip_tilt_with_stability_ball_275x340_step_2_1cc89dedef', '.png', 'image/png', 57.87, '/uploads/hip_tilt_with_stability_ball_275x340_step_2_1cc89dedef.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(37, 'internal-rotation-with-band-275x410-step-1.png', 'internal-rotation-with-band-275x410-step-1.png', 'internal-rotation-with-band-275x410-step-1.png', 215, 410, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_internal_rotation_with_band_275x410_step_1_c9f1a5bbcd.png", "hash": "thumbnail_internal_rotation_with_band_275x410_step_1_c9f1a5bbcd", "mime": "image/png", "name": "thumbnail_internal-rotation-with-band-275x410-step-1.png", "path": null, "size": 14.72, "width": 82, "height": 156}}', 'internal_rotation_with_band_275x410_step_1_c9f1a5bbcd', '.png', 'image/png', 63.02, '/uploads/internal_rotation_with_band_275x410_step_1_c9f1a5bbcd.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(38, 'internal-rotation-with-band-275x410-step-2.png', 'internal-rotation-with-band-275x410-step-2.png', 'internal-rotation-with-band-275x410-step-2.png', 230, 407, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_internal_rotation_with_band_275x410_step_2_8e3ce5878c.png", "hash": "thumbnail_internal_rotation_with_band_275x410_step_2_8e3ce5878c", "mime": "image/png", "name": "thumbnail_internal-rotation-with-band-275x410-step-2.png", "path": null, "size": 15.02, "width": 88, "height": 156}}', 'internal_rotation_with_band_275x410_step_2_8e3ce5878c', '.png', 'image/png', 64.16, '/uploads/internal_rotation_with_band_275x410_step_2_8e3ce5878c.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(39, 'lateral-movement-with-looped-band-275x410-prog-1.png', 'lateral-movement-with-looped-band-275x410-prog-1.png', 'lateral-movement-with-looped-band-275x410-prog-1.png', 537, 410, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_lateral_movement_with_looped_band_275x410_prog_1_1c32ec0635.png", "hash": "thumbnail_lateral_movement_with_looped_band_275x410_prog_1_1c32ec0635", "mime": "image/png", "name": "thumbnail_lateral-movement-with-looped-band-275x410-prog-1.png", "path": null, "size": 32.08, "width": 204, "height": 156}}', 'lateral_movement_with_looped_band_275x410_prog_1_1c32ec0635', '.png', 'image/png', 150.86, '/uploads/lateral_movement_with_looped_band_275x410_prog_1_1c32ec0635.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(40, 'lateral-movement-with-looped-band-275x410-prog-2.png', 'lateral-movement-with-looped-band-275x410-prog-2.png', 'lateral-movement-with-looped-band-275x410-prog-2.png', 521, 410, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_lateral_movement_with_looped_band_275x410_prog_2_47d1cc0446.png", "hash": "thumbnail_lateral_movement_with_looped_band_275x410_prog_2_47d1cc0446", "mime": "image/png", "name": "thumbnail_lateral-movement-with-looped-band-275x410-prog-2.png", "path": null, "size": 32.84, "width": 198, "height": 156}}', 'lateral_movement_with_looped_band_275x410_prog_2_47d1cc0446', '.png', 'image/png', 153.12, '/uploads/lateral_movement_with_looped_band_275x410_prog_2_47d1cc0446.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(41, 'lateral-movement-with-looped-band-275x410-step-2.png', 'lateral-movement-with-looped-band-275x410-step-2.png', 'lateral-movement-with-looped-band-275x410-step-2.png', 252, 404, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_lateral_movement_with_looped_band_275x410_step_2_d589cf490f.png", "hash": "thumbnail_lateral_movement_with_looped_band_275x410_step_2_d589cf490f", "mime": "image/png", "name": "thumbnail_lateral-movement-with-looped-band-275x410-step-2.png", "path": null, "size": 17.47, "width": 97, "height": 156}}', 'lateral_movement_with_looped_band_275x410_step_2_d589cf490f', '.png', 'image/png', 76.77, '/uploads/lateral_movement_with_looped_band_275x410_step_2_d589cf490f.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(42, 'lateral-movement-with-looped-band-275x410-step-1.png', 'lateral-movement-with-looped-band-275x410-step-1.png', 'lateral-movement-with-looped-band-275x410-step-1.png', 256, 406, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_lateral_movement_with_looped_band_275x410_step_1_8b53c888ec.png", "hash": "thumbnail_lateral_movement_with_looped_band_275x410_step_1_8b53c888ec", "mime": "image/png", "name": "thumbnail_lateral-movement-with-looped-band-275x410-step-1.png", "path": null, "size": 16.8, "width": 98, "height": 156}}', 'lateral_movement_with_looped_band_275x410_step_1_8b53c888ec', '.png', 'image/png', 73.87, '/uploads/lateral_movement_with_looped_band_275x410_step_1_8b53c888ec.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(43, 'lateral-wrist-raises-275x340-step-1.png', 'lateral-wrist-raises-275x340-step-1.png', 'lateral-wrist-raises-275x340-step-1.png', 248, 331, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_lateral_wrist_raises_275x340_step_1_cbffc90390.png", "hash": "thumbnail_lateral_wrist_raises_275x340_step_1_cbffc90390", "mime": "image/png", "name": "thumbnail_lateral-wrist-raises-275x340-step-1.png", "path": null, "size": 26.65, "width": 117, "height": 156}}', 'lateral_wrist_raises_275x340_step_1_cbffc90390', '.png', 'image/png', 77.11, '/uploads/lateral_wrist_raises_275x340_step_1_cbffc90390.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(44, 'lunges-with-rotation-275x410-step-1.png', 'lunges-with-rotation-275x410-step-1.png', 'lunges-with-rotation-275x410-step-1.png', 258, 371, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_lunges_with_rotation_275x410_step_1_37f45a0966.png", "hash": "thumbnail_lunges_with_rotation_275x410_step_1_37f45a0966", "mime": "image/png", "name": "thumbnail_lunges-with-rotation-275x410-step-1.png", "path": null, "size": 16.32, "width": 108, "height": 156}}', 'lunges_with_rotation_275x410_step_1_37f45a0966', '.png', 'image/png', 65.05, '/uploads/lunges_with_rotation_275x410_step_1_37f45a0966.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(45, 'lateral-wrist-raises-275x340-step-2.png', 'lateral-wrist-raises-275x340-step-2.png', 'lateral-wrist-raises-275x340-step-2.png', 254, 335, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_lateral_wrist_raises_275x340_step_2_675af27241.png", "hash": "thumbnail_lateral_wrist_raises_275x340_step_2_675af27241", "mime": "image/png", "name": "thumbnail_lateral-wrist-raises-275x340-step-2.png", "path": null, "size": 25.6, "width": 118, "height": 156}}', 'lateral_wrist_raises_275x340_step_2_675af27241', '.png', 'image/png', 75.56, '/uploads/lateral_wrist_raises_275x340_step_2_675af27241.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(46, 'lunges-with-rotation-275x410-step-2.png', 'lunges-with-rotation-275x410-step-2.png', 'lunges-with-rotation-275x410-step-2.png', 275, 349, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_lunges_with_rotation_275x410_step_2_aa1cc51c40.png", "hash": "thumbnail_lunges_with_rotation_275x410_step_2_aa1cc51c40", "mime": "image/png", "name": "thumbnail_lunges-with-rotation-275x410-step-2.png", "path": null, "size": 15.84, "width": 123, "height": 156}}', 'lunges_with_rotation_275x410_step_2_aa1cc51c40', '.png', 'image/png', 57.07, '/uploads/lunges_with_rotation_275x410_step_2_aa1cc51c40.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(47, 'lunges-with-rotation-275x410-step-3.png', 'lunges-with-rotation-275x410-step-3.png', 'lunges-with-rotation-275x410-step-3.png', 275, 401, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_lunges_with_rotation_275x410_step_3_6db487f9b4.png", "hash": "thumbnail_lunges_with_rotation_275x410_step_3_6db487f9b4", "mime": "image/png", "name": "thumbnail_lunges-with-rotation-275x410-step-3.png", "path": null, "size": 16.33, "width": 107, "height": 156}}', 'lunges_with_rotation_275x410_step_3_6db487f9b4', '.png', 'image/png', 71.01, '/uploads/lunges_with_rotation_275x410_step_3_6db487f9b4.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(48, 'manual-resistance-275x300-step-1.png', 'manual-resistance-275x300-step-1.png', 'manual-resistance-275x300-step-1.png', 273, 300, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_manual_resistance_275x300_step_1_dd3462149d.png", "hash": "thumbnail_manual_resistance_275x300_step_1_dd3462149d", "mime": "image/png", "name": "thumbnail_manual-resistance-275x300-step-1.png", "path": null, "size": 29.18, "width": 142, "height": 156}}', 'manual_resistance_275x300_step_1_dd3462149d', '.png', 'image/png', 72.71, '/uploads/manual_resistance_275x300_step_1_dd3462149d.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(49, 'manual-resistance-275x300-step-2.png', 'manual-resistance-275x300-step-2.png', 'manual-resistance-275x300-step-2.png', 256, 300, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_manual_resistance_275x300_step_2_44a333f2f8.png", "hash": "thumbnail_manual_resistance_275x300_step_2_44a333f2f8", "mime": "image/png", "name": "thumbnail_manual-resistance-275x300-step-2.png", "path": null, "size": 27.87, "width": 133, "height": 156}}', 'manual_resistance_275x300_step_2_44a333f2f8', '.png', 'image/png', 71.45, '/uploads/manual_resistance_275x300_step_2_44a333f2f8.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(50, 'manual-resistance-550x340-step-3.png', 'manual-resistance-550x340-step-3.png', 'manual-resistance-550x340-step-3.png', 536, 313, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_manual_resistance_550x340_step_3_b913c9395a.png", "hash": "thumbnail_manual_resistance_550x340_step_3_b913c9395a", "mime": "image/png", "name": "thumbnail_manual-resistance-550x340-step-3.png", "path": null, "size": 42.88, "width": 245, "height": 143}}', 'manual_resistance_550x340_step_3_b913c9395a', '.png', 'image/png', 151.41, '/uploads/manual_resistance_550x340_step_3_b913c9395a.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(51, 'omnidirectional-movement-275x310-step-2.png', 'omnidirectional-movement-275x310-step-2.png', 'omnidirectional-movement-275x310-step-2.png', 267, 295, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_omnidirectional_movement_275x310_step_2_1719089f4b.png", "hash": "thumbnail_omnidirectional_movement_275x310_step_2_1719089f4b", "mime": "image/png", "name": "thumbnail_omnidirectional-movement-275x310-step-2.png", "path": null, "size": 26.78, "width": 141, "height": 156}}', 'omnidirectional_movement_275x310_step_2_1719089f4b', '.png', 'image/png', 72.93, '/uploads/omnidirectional_movement_275x310_step_2_1719089f4b.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(52, 'manual-resistance-550x340-step-4.png', 'manual-resistance-550x340-step-4.png', 'manual-resistance-550x340-step-4.png', 527, 340, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_manual_resistance_550x340_step_4_49c2c2eb11.png", "hash": "thumbnail_manual_resistance_550x340_step_4_49c2c2eb11", "mime": "image/png", "name": "thumbnail_manual-resistance-550x340-step-4.png", "path": null, "size": 38.64, "width": 242, "height": 156}}', 'manual_resistance_550x340_step_4_49c2c2eb11', '.png', 'image/png', 117.81, '/uploads/manual_resistance_550x340_step_4_49c2c2eb11.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(53, 'omnidirectional-movement-275x310-step-1.png', 'omnidirectional-movement-275x310-step-1.png', 'omnidirectional-movement-275x310-step-1.png', 271, 297, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_omnidirectional_movement_275x310_step_1_9bda4e8391.png", "hash": "thumbnail_omnidirectional_movement_275x310_step_1_9bda4e8391", "mime": "image/png", "name": "thumbnail_omnidirectional-movement-275x310-step-1.png", "path": null, "size": 26.89, "width": 142, "height": 156}}', 'omnidirectional_movement_275x310_step_1_9bda4e8391', '.png', 'image/png', 74.07, '/uploads/omnidirectional_movement_275x310_step_1_9bda4e8391.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(54, 'omnidirectional-movement-275x310-step-3.png', 'omnidirectional-movement-275x310-step-3.png', 'omnidirectional-movement-275x310-step-3.png', 267, 298, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_omnidirectional_movement_275x310_step_3_ef07594ed7.png", "hash": "thumbnail_omnidirectional_movement_275x310_step_3_ef07594ed7", "mime": "image/png", "name": "thumbnail_omnidirectional-movement-275x310-step-3.png", "path": null, "size": 29.35, "width": 140, "height": 156}}', 'omnidirectional_movement_275x310_step_3_ef07594ed7', '.png', 'image/png', 81.45, '/uploads/omnidirectional_movement_275x310_step_3_ef07594ed7.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(55, 'omnidirectional-movement-275x310-step-4.png', 'omnidirectional-movement-275x310-step-4.png', 'omnidirectional-movement-275x310-step-4.png', 263, 299, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_omnidirectional_movement_275x310_step_4_ac78a695de.png", "hash": "thumbnail_omnidirectional_movement_275x310_step_4_ac78a695de", "mime": "image/png", "name": "thumbnail_omnidirectional-movement-275x310-step-4.png", "path": null, "size": 28.35, "width": 137, "height": 156}}', 'omnidirectional_movement_275x310_step_4_ac78a695de', '.png', 'image/png', 80.31, '/uploads/omnidirectional_movement_275x310_step_4_ac78a695de.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(56, 'omnidirectional-movement-275x310-step-5.png', 'omnidirectional-movement-275x310-step-5.png', 'omnidirectional-movement-275x310-step-5.png', 272, 293, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_omnidirectional_movement_275x310_step_5_0a9ce61d54.png", "hash": "thumbnail_omnidirectional_movement_275x310_step_5_0a9ce61d54", "mime": "image/png", "name": "thumbnail_omnidirectional-movement-275x310-step-5.png", "path": null, "size": 27.16, "width": 145, "height": 156}}', 'omnidirectional_movement_275x310_step_5_0a9ce61d54', '.png', 'image/png', 74.23, '/uploads/omnidirectional_movement_275x310_step_5_0a9ce61d54.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(57, 'omnidirectional-movement-275x310-step-7.png', 'omnidirectional-movement-275x310-step-7.png', 'omnidirectional-movement-275x310-step-7.png', 275, 299, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_omnidirectional_movement_275x310_step_7_f4cd8f653f.png", "hash": "thumbnail_omnidirectional_movement_275x310_step_7_f4cd8f653f", "mime": "image/png", "name": "thumbnail_omnidirectional-movement-275x310-step-7.png", "path": null, "size": 21.44, "width": 143, "height": 156}}', 'omnidirectional_movement_275x310_step_7_f4cd8f653f', '.png', 'image/png', 52.37, '/uploads/omnidirectional_movement_275x310_step_7_f4cd8f653f.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(58, 'omnidirectional-movement-275x310-step-6.png', 'omnidirectional-movement-275x310-step-6.png', 'omnidirectional-movement-275x310-step-6.png', 266, 284, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_omnidirectional_movement_275x310_step_6_b257a14229.png", "hash": "thumbnail_omnidirectional_movement_275x310_step_6_b257a14229", "mime": "image/png", "name": "thumbnail_omnidirectional-movement-275x310-step-6.png", "path": null, "size": 28.36, "width": 146, "height": 156}}', 'omnidirectional_movement_275x310_step_6_b257a14229', '.png', 'image/png', 72.68, '/uploads/omnidirectional_movement_275x310_step_6_b257a14229.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(59, 'omnidirectional-movement-275x310-step-8.png', 'omnidirectional-movement-275x310-step-8.png', 'omnidirectional-movement-275x310-step-8.png', 264, 300, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_omnidirectional_movement_275x310_step_8_7d9af9c784.png", "hash": "thumbnail_omnidirectional_movement_275x310_step_8_7d9af9c784", "mime": "image/png", "name": "thumbnail_omnidirectional-movement-275x310-step-8.png", "path": null, "size": 20.43, "width": 137, "height": 156}}', 'omnidirectional_movement_275x310_step_8_7d9af9c784', '.png', 'image/png', 50.59, '/uploads/omnidirectional_movement_275x310_step_8_7d9af9c784.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(60, 'reverse-wrist-curls-275x340-step-1.png', 'reverse-wrist-curls-275x340-step-1.png', 'reverse-wrist-curls-275x340-step-1.png', 243, 331, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_reverse_wrist_curls_275x340_step_1_471038a7e7.png", "hash": "thumbnail_reverse_wrist_curls_275x340_step_1_471038a7e7", "mime": "image/png", "name": "thumbnail_reverse-wrist-curls-275x340-step-1.png", "path": null, "size": 27.25, "width": 115, "height": 156}}', 'reverse_wrist_curls_275x340_step_1_471038a7e7', '.png', 'image/png', 79.76, '/uploads/reverse_wrist_curls_275x340_step_1_471038a7e7.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(61, 'romanian-deadlift-275x340-prog-1.png', 'romanian-deadlift-275x340-prog-1.png', 'romanian-deadlift-275x340-prog-1.png', 247, 315, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_romanian_deadlift_275x340_prog_1_a4dc610ed8.png", "hash": "thumbnail_romanian_deadlift_275x340_prog_1_a4dc610ed8", "mime": "image/png", "name": "thumbnail_romanian-deadlift-275x340-prog-1.png", "path": null, "size": 17.73, "width": 122, "height": 156}}', 'romanian_deadlift_275x340_prog_1_a4dc610ed8', '.png', 'image/png', 52.83, '/uploads/romanian_deadlift_275x340_prog_1_a4dc610ed8.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(62, 'reverse-wrist-curls-275x340-step-2.png', 'reverse-wrist-curls-275x340-step-2.png', 'reverse-wrist-curls-275x340-step-2.png', 248, 334, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_reverse_wrist_curls_275x340_step_2_069640555f.png", "hash": "thumbnail_reverse_wrist_curls_275x340_step_2_069640555f", "mime": "image/png", "name": "thumbnail_reverse-wrist-curls-275x340-step-2.png", "path": null, "size": 26.02, "width": 116, "height": 156}}', 'reverse_wrist_curls_275x340_step_2_069640555f', '.png', 'image/png', 76.90, '/uploads/reverse_wrist_curls_275x340_step_2_069640555f.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(63, 'romanian-deadlift-275x340-prog-2.png', 'romanian-deadlift-275x340-prog-2.png', 'romanian-deadlift-275x340-prog-2.png', 275, 295, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_romanian_deadlift_275x340_prog_2_f52b40e5e1.png", "hash": "thumbnail_romanian_deadlift_275x340_prog_2_f52b40e5e1", "mime": "image/png", "name": "thumbnail_romanian-deadlift-275x340-prog-2.png", "path": null, "size": 20.54, "width": 145, "height": 156}}', 'romanian_deadlift_275x340_prog_2_f52b40e5e1', '.png', 'image/png', 53.90, '/uploads/romanian_deadlift_275x340_prog_2_f52b40e5e1.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(64, 'romanian-deadlift-275x340-step-1.png', 'romanian-deadlift-275x340-step-1.png', 'romanian-deadlift-275x340-step-1.png', 260, 340, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_romanian_deadlift_275x340_step_1_bc040e28b2.png", "hash": "thumbnail_romanian_deadlift_275x340_step_1_bc040e28b2", "mime": "image/png", "name": "thumbnail_romanian-deadlift-275x340-step-1.png", "path": null, "size": 14.29, "width": 119, "height": 156}}', 'romanian_deadlift_275x340_step_1_bc040e28b2', '.png', 'image/png', 46.07, '/uploads/romanian_deadlift_275x340_step_1_bc040e28b2.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(65, 'romanian-deadlift-275x340-step-2.png', 'romanian-deadlift-275x340-step-2.png', 'romanian-deadlift-275x340-step-2.png', 241, 340, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_romanian_deadlift_275x340_step_2_cc3f6b4b2c.png", "hash": "thumbnail_romanian_deadlift_275x340_step_2_cc3f6b4b2c", "mime": "image/png", "name": "thumbnail_romanian-deadlift-275x340-step-2.png", "path": null, "size": 15.57, "width": 111, "height": 156}}', 'romanian_deadlift_275x340_step_2_cc3f6b4b2c', '.png', 'image/png', 49.81, '/uploads/romanian_deadlift_275x340_step_2_cc3f6b4b2c.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(66, 'rotation-with-eyes-on-ball-275x410-step-1.png', 'rotation-with-eyes-on-ball-275x410-step-1.png', 'rotation-with-eyes-on-ball-275x410-step-1.png', 275, 410, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_rotation_with_eyes_on_ball_275x410_step_1_0463777261.png", "hash": "thumbnail_rotation_with_eyes_on_ball_275x410_step_1_0463777261", "mime": "image/png", "name": "thumbnail_rotation-with-eyes-on-ball-275x410-step-1.png", "path": null, "size": 18.88, "width": 105, "height": 156}}', 'rotation_with_eyes_on_ball_275x410_step_1_0463777261', '.png', 'image/png', 84.65, '/uploads/rotation_with_eyes_on_ball_275x410_step_1_0463777261.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(67, 'rotation-with-eyes-on-ball-275x410-step-2.png', 'rotation-with-eyes-on-ball-275x410-step-2.png', 'rotation-with-eyes-on-ball-275x410-step-2.png', 202, 405, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_rotation_with_eyes_on_ball_275x410_step_2_31c93452ac.png", "hash": "thumbnail_rotation_with_eyes_on_ball_275x410_step_2_31c93452ac", "mime": "image/png", "name": "thumbnail_rotation-with-eyes-on-ball-275x410-step-2.png", "path": null, "size": 15.33, "width": 78, "height": 156}}', 'rotation_with_eyes_on_ball_275x410_step_2_31c93452ac', '.png', 'image/png', 65.40, '/uploads/rotation_with_eyes_on_ball_275x410_step_2_31c93452ac.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(68, 'shoulder-blade-retraction-with-bands-274x410-step-1.png', 'shoulder-blade-retraction-with-bands-274x410-step-1.png', 'shoulder-blade-retraction-with-bands-274x410-step-1.png', 250, 403, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_shoulder_blade_retraction_with_bands_274x410_step_1_eb75188926.png", "hash": "thumbnail_shoulder_blade_retraction_with_bands_274x410_step_1_eb75188926", "mime": "image/png", "name": "thumbnail_shoulder-blade-retraction-with-bands-274x410-step-1.png", "path": null, "size": 14.76, "width": 97, "height": 156}}', 'shoulder_blade_retraction_with_bands_274x410_step_1_eb75188926', '.png', 'image/png', 63.80, '/uploads/shoulder_blade_retraction_with_bands_274x410_step_1_eb75188926.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(69, 'shoulder-blade-retraction-with-bands-274x410-step-2.png', 'shoulder-blade-retraction-with-bands-274x410-step-2.png', 'shoulder-blade-retraction-with-bands-274x410-step-2.png', 258, 400, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_shoulder_blade_retraction_with_bands_274x410_step_2_72684d3158.png", "hash": "thumbnail_shoulder_blade_retraction_with_bands_274x410_step_2_72684d3158", "mime": "image/png", "name": "thumbnail_shoulder-blade-retraction-with-bands-274x410-step-2.png", "path": null, "size": 14.45, "width": 101, "height": 156}}', 'shoulder_blade_retraction_with_bands_274x410_step_2_72684d3158', '.png', 'image/png', 61.59, '/uploads/shoulder_blade_retraction_with_bands_274x410_step_2_72684d3158.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(70, 'single-arm-flies-with-band-275x410-step-1.png', 'single-arm-flies-with-band-275x410-step-1.png', 'single-arm-flies-with-band-275x410-step-1.png', 274, 410, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_single_arm_flies_with_band_275x410_step_1_6a93f35dd0.png", "hash": "thumbnail_single_arm_flies_with_band_275x410_step_1_6a93f35dd0", "mime": "image/png", "name": "thumbnail_single-arm-flies-with-band-275x410-step-1.png", "path": null, "size": 16, "width": 104, "height": 156}}', 'single_arm_flies_with_band_275x410_step_1_6a93f35dd0', '.png', 'image/png', 78.18, '/uploads/single_arm_flies_with_band_275x410_step_1_6a93f35dd0.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(71, 'single-arm-flies-with-band-275x410-step-2.png', 'single-arm-flies-with-band-275x410-step-2.png', 'single-arm-flies-with-band-275x410-step-2.png', 262, 410, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_single_arm_flies_with_band_275x410_step_2_4acf8011fb.png", "hash": "thumbnail_single_arm_flies_with_band_275x410_step_2_4acf8011fb", "mime": "image/png", "name": "thumbnail_single-arm-flies-with-band-275x410-step-2.png", "path": null, "size": 15.49, "width": 100, "height": 156}}', 'single_arm_flies_with_band_275x410_step_2_4acf8011fb', '.png', 'image/png', 75.39, '/uploads/single_arm_flies_with_band_275x410_step_2_4acf8011fb.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(72, 'single-arm-row-one-foot-275x410-step-1.png', 'single-arm-row-one-foot-275x410-step-1.png', 'single-arm-row-one-foot-275x410-step-1.png', 265, 400, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_single_arm_row_one_foot_275x410_step_1_6d47fc7953.png", "hash": "thumbnail_single_arm_row_one_foot_275x410_step_1_6d47fc7953", "mime": "image/png", "name": "thumbnail_single-arm-row-one-foot-275x410-step-1.png", "path": null, "size": 16.02, "width": 103, "height": 156}}', 'single_arm_row_one_foot_275x410_step_1_6d47fc7953', '.png', 'image/png', 75.30, '/uploads/single_arm_row_one_foot_275x410_step_1_6d47fc7953.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(73, 'single-leg-standing-balance-275x410-step-1.png', 'single-leg-standing-balance-275x410-step-1.png', 'single-leg-standing-balance-275x410-step-1.png', 245, 362, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_single_leg_standing_balance_275x410_step_1_8a15c4dca5.png", "hash": "thumbnail_single_leg_standing_balance_275x410_step_1_8a15c4dca5", "mime": "image/png", "name": "thumbnail_single-leg-standing-balance-275x410-step-1.png", "path": null, "size": 15.26, "width": 106, "height": 156}}', 'single_leg_standing_balance_275x410_step_1_8a15c4dca5', '.png', 'image/png', 53.51, '/uploads/single_leg_standing_balance_275x410_step_1_8a15c4dca5.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(74, 'single-arm-row-one-foot-275x410-step-2.png', 'single-arm-row-one-foot-275x410-step-2.png', 'single-arm-row-one-foot-275x410-step-2.png', 274, 401, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_single_arm_row_one_foot_275x410_step_2_07273e211b.png", "hash": "thumbnail_single_arm_row_one_foot_275x410_step_2_07273e211b", "mime": "image/png", "name": "thumbnail_single-arm-row-one-foot-275x410-step-2.png", "path": null, "size": 16.47, "width": 107, "height": 156}}', 'single_arm_row_one_foot_275x410_step_2_07273e211b', '.png', 'image/png', 76.40, '/uploads/single_arm_row_one_foot_275x410_step_2_07273e211b.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(75, 'single-leg-standing-balance-275x410-step-2.png', 'single-leg-standing-balance-275x410-step-2.png', 'single-leg-standing-balance-275x410-step-2.png', 231, 348, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_single_leg_standing_balance_275x410_step_2_3bd313e819.png", "hash": "thumbnail_single_leg_standing_balance_275x410_step_2_3bd313e819", "mime": "image/png", "name": "thumbnail_single-leg-standing-balance-275x410-step-2.png", "path": null, "size": 16.55, "width": 104, "height": 156}}', 'single_leg_standing_balance_275x410_step_2_3bd313e819', '.png', 'image/png', 54.88, '/uploads/single_leg_standing_balance_275x410_step_2_3bd313e819.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(76, 'standing-calf-raise-275x410-step-3.png', 'standing-calf-raise-275x410-step-3.png', 'standing-calf-raise-275x410-step-3.png', 262, 362, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_single_leg_standing_balance_275x410_step_3_b800991c5f.png", "hash": "thumbnail_single_leg_standing_balance_275x410_step_3_b800991c5f", "mime": "image/png", "name": "thumbnail_single-leg-standing-balance-275x410-step-3.png", "path": null, "size": 17.04, "width": 113, "height": 156}}', 'single_leg_standing_balance_275x410_step_3_b800991c5f', '.png', 'image/png', 60.45, '/uploads/single_leg_standing_balance_275x410_step_3_b800991c5f.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(77, 'standing-calf-raise-275x410-step-4.png', 'standing-calf-raise-275x410-step-4.png', 'standing-calf-raise-275x410-step-4.png', 240, 360, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_single_leg_standing_balance_275x410_step_4_11b28553d6.png", "hash": "thumbnail_single_leg_standing_balance_275x410_step_4_11b28553d6", "mime": "image/png", "name": "thumbnail_single-leg-standing-balance-275x410-step-4.png", "path": null, "size": 16.97, "width": 104, "height": 156}}', 'single_leg_standing_balance_275x410_step_4_11b28553d6', '.png', 'image/png', 59.69, '/uploads/single_leg_standing_balance_275x410_step_4_11b28553d6.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(78, 'split-lunge-275x340-step-1.png', 'split-lunge-275x340-step-1.png', 'split-lunge-275x340-step-1.png', 258, 340, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_split_lunge_275x340_step_1_f50b12ca01.png", "hash": "thumbnail_split_lunge_275x340_step_1_f50b12ca01", "mime": "image/png", "name": "thumbnail_split-lunge-275x340-step-1.png", "path": null, "size": 21.98, "width": 118, "height": 156}}', 'split_lunge_275x340_step_1_f50b12ca01', '.png', 'image/png', 73.70, '/uploads/split_lunge_275x340_step_1_f50b12ca01.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(79, 'split-lunge-275x340-step-2.png', 'split-lunge-275x340-step-2.png', 'split-lunge-275x340-step-2.png', 268, 338, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_split_lunge_275x340_step_2_760ccc6a8e.png", "hash": "thumbnail_split_lunge_275x340_step_2_760ccc6a8e", "mime": "image/png", "name": "thumbnail_split-lunge-275x340-step-2.png", "path": null, "size": 21.12, "width": 124, "height": 156}}', 'split_lunge_275x340_step_2_760ccc6a8e', '.png', 'image/png', 68.96, '/uploads/split_lunge_275x340_step_2_760ccc6a8e.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(80, 'standing-anti-rotation-with-bands-275x410-step-1.png', 'standing-anti-rotation-with-bands-275x410-step-1.png', 'standing-anti-rotation-with-bands-275x410-step-1.png', 264, 410, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_standing_anti_rotation_with_bands_275x410_step_1_7522a4f3d6.png", "hash": "thumbnail_standing_anti_rotation_with_bands_275x410_step_1_7522a4f3d6", "mime": "image/png", "name": "thumbnail_standing-anti-rotation-with-bands-275x410-step-1.png", "path": null, "size": 16.29, "width": 100, "height": 156}}', 'standing_anti_rotation_with_bands_275x410_step_1_7522a4f3d6', '.png', 'image/png', 73.04, '/uploads/standing_anti_rotation_with_bands_275x410_step_1_7522a4f3d6.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(81, 'standing-anti-rotation-with-bands-275x410-step-2.png', 'standing-anti-rotation-with-bands-275x410-step-2.png', 'standing-anti-rotation-with-bands-275x410-step-2.png', 271, 410, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_standing_anti_rotation_with_bands_275x410_step_2_887c44ef05.png", "hash": "thumbnail_standing_anti_rotation_with_bands_275x410_step_2_887c44ef05", "mime": "image/png", "name": "thumbnail_standing-anti-rotation-with-bands-275x410-step-2.png", "path": null, "size": 17.66, "width": 103, "height": 156}}', 'standing_anti_rotation_with_bands_275x410_step_2_887c44ef05', '.png', 'image/png', 79.94, '/uploads/standing_anti_rotation_with_bands_275x410_step_2_887c44ef05.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(82, 'standing-calf-raise-275x410-step-1.png', 'standing-calf-raise-275x410-step-1.png', 'standing-calf-raise-275x410-step-1.png', 261, 379, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_standing_calf_raise_275x410_step_1_5be38bd17f.png", "hash": "thumbnail_standing_calf_raise_275x410_step_1_5be38bd17f", "mime": "image/png", "name": "thumbnail_standing-calf-raise-275x410-step-1.png", "path": null, "size": 14.8, "width": 107, "height": 156}}', 'standing_calf_raise_275x410_step_1_5be38bd17f', '.png', 'image/png', 55.69, '/uploads/standing_calf_raise_275x410_step_1_5be38bd17f.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(83, 'standing-calf-raise-275x410-step-2.png', 'standing-calf-raise-275x410-step-2.png', 'standing-calf-raise-275x410-step-2.png', 230, 375, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_standing_calf_raise_275x410_step_2_70b5afbbc1.png", "hash": "thumbnail_standing_calf_raise_275x410_step_2_70b5afbbc1", "mime": "image/png", "name": "thumbnail_standing-calf-raise-275x410-step-2.png", "path": null, "size": 14.63, "width": 96, "height": 156}}', 'standing_calf_raise_275x410_step_2_70b5afbbc1', '.png', 'image/png', 54.51, '/uploads/standing_calf_raise_275x410_step_2_70b5afbbc1.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(84, 'standing-row-with-bands-275x410-step-1.png', 'standing-row-with-bands-275x410-step-1.png', 'standing-row-with-bands-275x410-step-1.png', 269, 410, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_standing_row_with_bands_275x410_step_1_39f2b0f2b3.png", "hash": "thumbnail_standing_row_with_bands_275x410_step_1_39f2b0f2b3", "mime": "image/png", "name": "thumbnail_standing-row-with-bands-275x410-step-1.png", "path": null, "size": 16.37, "width": 102, "height": 156}}', 'standing_row_with_bands_275x410_step_1_39f2b0f2b3', '.png', 'image/png', 73.86, '/uploads/standing_row_with_bands_275x410_step_1_39f2b0f2b3.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(85, 'standing-row-with-bands-275x410-step-2.png', 'standing-row-with-bands-275x410-step-2.png', 'standing-row-with-bands-275x410-step-2.png', 275, 410, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_standing_row_with_bands_275x410_step_2_c75b124d71.png", "hash": "thumbnail_standing_row_with_bands_275x410_step_2_c75b124d71", "mime": "image/png", "name": "thumbnail_standing-row-with-bands-275x410-step-2.png", "path": null, "size": 15.32, "width": 105, "height": 156}}', 'standing_row_with_bands_275x410_step_2_c75b124d71', '.png', 'image/png', 68.77, '/uploads/standing_row_with_bands_275x410_step_2_c75b124d71.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(86, 'toe-raises-275x310-step-1.png', 'toe-raises-275x310-step-1.png', 'toe-raises-275x310-step-1.png', 247, 219, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_toe_raises_275x310_step_1_211f7d36c4.png", "hash": "thumbnail_toe_raises_275x310_step_1_211f7d36c4", "mime": "image/png", "name": "thumbnail_toe-raises-275x310-step-1.png", "path": null, "size": 30.92, "width": 176, "height": 156}}', 'toe_raises_275x310_step_1_211f7d36c4', '.png', 'image/png', 46.12, '/uploads/toe_raises_275x310_step_1_211f7d36c4.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(87, 'straight-arm-blanks-550x340-prog-1.png', 'straight-arm-blanks-550x340-prog-1.png', 'straight-arm-blanks-550x340-prog-1.png', 524, 340, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_straight_arm_blanks_550x340_prog_1_aaa786bfaa.png", "hash": "thumbnail_straight_arm_blanks_550x340_prog_1_aaa786bfaa", "mime": "image/png", "name": "thumbnail_straight-arm-blanks-550x340-prog-1.png", "path": null, "size": 29.3, "width": 240, "height": 156}}', 'straight_arm_blanks_550x340_prog_1_aaa786bfaa', '.png', 'image/png', 99.08, '/uploads/straight_arm_blanks_550x340_prog_1_aaa786bfaa.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(88, 'toe-raises-275x310-step2.png', 'toe-raises-275x310-step2.png', 'toe-raises-275x310-step2.png', 272, 221, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_toe_raises_275x310_step2_1098ec6de8.png", "hash": "thumbnail_toe_raises_275x310_step2_1098ec6de8", "mime": "image/png", "name": "thumbnail_toe-raises-275x310-step2.png", "path": null, "size": 33, "width": 192, "height": 156}}', 'toe_raises_275x310_step2_1098ec6de8', '.png', 'image/png', 51.57, '/uploads/toe_raises_275x310_step2_1098ec6de8.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(89, 'straight-arm-blanks-550x340-step-1.png', 'straight-arm-blanks-550x340-step-1.png', 'straight-arm-blanks-550x340-step-1.png', 526, 335, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_straight_arm_blanks_550x340_step_1_81cd16bbf7.png", "hash": "thumbnail_straight_arm_blanks_550x340_step_1_81cd16bbf7", "mime": "image/png", "name": "thumbnail_straight-arm-blanks-550x340-step-1.png", "path": null, "size": 33.77, "width": 245, "height": 156}}', 'straight_arm_blanks_550x340_step_1_81cd16bbf7', '.png', 'image/png', 113.16, '/uploads/straight_arm_blanks_550x340_step_1_81cd16bbf7.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(90, 'triceps-extension-275x410-step-1.png', 'triceps-extension-275x410-step-1.png', 'triceps-extension-275x410-step-1.png', 260, 395, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_triceps_extension_275x410_step_1_92ab06b421.png", "hash": "thumbnail_triceps_extension_275x410_step_1_92ab06b421", "mime": "image/png", "name": "thumbnail_triceps-extension-275x410-step-1.png", "path": null, "size": 17.76, "width": 103, "height": 156}}', 'triceps_extension_275x410_step_1_92ab06b421', '.png', 'image/png', 75.84, '/uploads/triceps_extension_275x410_step_1_92ab06b421.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(91, 'triceps-extension-275x410-step-2.png', 'triceps-extension-275x410-step-2.png', 'triceps-extension-275x410-step-2.png', 272, 408, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_triceps_extension_275x410_step_2_a6f1ad54bc.png", "hash": "thumbnail_triceps_extension_275x410_step_2_a6f1ad54bc", "mime": "image/png", "name": "thumbnail_triceps-extension-275x410-step-2.png", "path": null, "size": 17.63, "width": 104, "height": 156}}', 'triceps_extension_275x410_step_2_a6f1ad54bc', '.png', 'image/png', 78.99, '/uploads/triceps_extension_275x410_step_2_a6f1ad54bc.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(92, 'wrist-curls-275x340-step-1.png', 'wrist-curls-275x340-step-1.png', 'wrist-curls-275x340-step-1.png', 254, 340, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_wrist_curls_275x340_step_1_afd38777f3.png", "hash": "thumbnail_wrist_curls_275x340_step_1_afd38777f3", "mime": "image/png", "name": "thumbnail_wrist-curls-275x340-step-1.png", "path": null, "size": 26.11, "width": 117, "height": 156}}', 'wrist_curls_275x340_step_1_afd38777f3', '.png', 'image/png', 78.57, '/uploads/wrist_curls_275x340_step_1_afd38777f3.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(93, 'wrist-flex-extension-275x300-step-1.png', 'wrist-flex-extension-275x300-step-1.png', 'wrist-flex-extension-275x300-step-1.png', 264, 295, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_wrist_flex_extension_275x300_step_1_04598ebc6f.png", "hash": "thumbnail_wrist_flex_extension_275x300_step_1_04598ebc6f", "mime": "image/png", "name": "thumbnail_wrist-flex-extension-275x300-step-1.png", "path": null, "size": 29.97, "width": 140, "height": 156}}', 'wrist_flex_extension_275x300_step_1_04598ebc6f', '.png', 'image/png', 76.30, '/uploads/wrist_flex_extension_275x300_step_1_04598ebc6f.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(94, 'wrist-curls-275x340-step-2.png', 'wrist-curls-275x340-step-2.png', 'wrist-curls-275x340-step-2.png', 258, 331, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_wrist_curls_275x340_step_2_41f5cf5d53.png", "hash": "thumbnail_wrist_curls_275x340_step_2_41f5cf5d53", "mime": "image/png", "name": "thumbnail_wrist-curls-275x340-step-2.png", "path": null, "size": 28.55, "width": 122, "height": 156}}', 'wrist_curls_275x340_step_2_41f5cf5d53', '.png', 'image/png', 82.16, '/uploads/wrist_curls_275x340_step_2_41f5cf5d53.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(95, 'wrist-flex-extension-275x300-step-2.png', 'wrist-flex-extension-275x300-step-2.png', 'wrist-flex-extension-275x300-step-2.png', 272, 294, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_wrist_flex_extension_275x300_step_2_af59981a96.png", "hash": "thumbnail_wrist_flex_extension_275x300_step_2_af59981a96", "mime": "image/png", "name": "thumbnail_wrist-flex-extension-275x300-step-2.png", "path": null, "size": 29.14, "width": 144, "height": 156}}', 'wrist_flex_extension_275x300_step_2_af59981a96', '.png', 'image/png', 74.03, '/uploads/wrist_flex_extension_275x300_step_2_af59981a96.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(96, 'wrist-pronation-with-band-275x300-step-1.png', 'wrist-pronation-with-band-275x300-step-1.png', 'wrist-pronation-with-band-275x300-step-1.png', 273, 300, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_wrist_pronation_with_band_275x300_step_1_efb31599e9.png", "hash": "thumbnail_wrist_pronation_with_band_275x300_step_1_efb31599e9", "mime": "image/png", "name": "thumbnail_wrist-pronation-with-band-275x300-step-1.png", "path": null, "size": 29.87, "width": 142, "height": 156}}', 'wrist_pronation_with_band_275x300_step_1_efb31599e9', '.png', 'image/png', 77.23, '/uploads/wrist_pronation_with_band_275x300_step_1_efb31599e9.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(97, 'wrist-pronation-with-band-275x300-step-2.png', 'wrist-pronation-with-band-275x300-step-2.png', 'wrist-pronation-with-band-275x300-step-2.png', 275, 300, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_wrist_pronation_with_band_275x300_step_2_91061b4325.png", "hash": "thumbnail_wrist_pronation_with_band_275x300_step_2_91061b4325", "mime": "image/png", "name": "thumbnail_wrist-pronation-with-band-275x300-step-2.png", "path": null, "size": 29.44, "width": 143, "height": 156}}', 'wrist_pronation_with_band_275x300_step_2_91061b4325', '.png', 'image/png', 77.68, '/uploads/wrist_pronation_with_band_275x300_step_2_91061b4325.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(98, 'wrist-supination-with-band-275x300-step-2.png', 'wrist-supination-with-band-275x300-step-2.png', 'wrist-supination-with-band-275x300-step-2.png', 264, 300, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_wrist_supination_with_band_275x300_step_2_6dde5b0318.png", "hash": "thumbnail_wrist_supination_with_band_275x300_step_2_6dde5b0318", "mime": "image/png", "name": "thumbnail_wrist-supination-with-band-275x300-step-2.png", "path": null, "size": 30.14, "width": 137, "height": 156}}', 'wrist_supination_with_band_275x300_step_2_6dde5b0318', '.png', 'image/png', 80.22, '/uploads/wrist_supination_with_band_275x300_step_2_6dde5b0318.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1),
(99, 'wrist-supination-with-band-275x300-step-1.png', 'wrist-supination-with-band-275x300-step-1.png', 'wrist-supination-with-band-275x300-step-1.png', 270, 300, '{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_wrist_supination_with_band_275x300_step_1_4169452e45.png", "hash": "thumbnail_wrist_supination_with_band_275x300_step_1_4169452e45", "mime": "image/png", "name": "thumbnail_wrist-supination-with-band-275x300-step-1.png", "path": null, "size": 29.76, "width": 140, "height": 156}}', 'wrist_supination_with_band_275x300_step_1_4169452e45', '.png', 'image/png', 78.49, '/uploads/wrist_supination_with_band_275x300_step_1_4169452e45.png', '', 'local', NULL, '/1', NULL, NULL, 1, 1);

INSERT INTO "public"."files_folder_links" ("id", "file_id", "folder_id", "file_order") VALUES
(5, 5, 1, NULL),
(6, 6, 1, NULL),
(7, 7, 1, NULL),
(8, 8, 1, NULL),
(9, 9, 1, NULL),
(10, 10, 1, NULL),
(11, 11, 1, NULL),
(12, 12, 1, NULL),
(13, 13, 1, NULL),
(14, 14, 1, NULL),
(15, 15, 1, NULL),
(16, 16, 1, NULL),
(17, 17, 1, NULL),
(18, 18, 1, NULL),
(19, 19, 1, NULL),
(20, 20, 1, NULL),
(21, 21, 1, NULL),
(22, 22, 1, NULL),
(23, 23, 1, NULL),
(24, 24, 1, NULL),
(25, 25, 1, NULL),
(26, 26, 1, NULL),
(27, 27, 1, NULL),
(28, 28, 1, NULL),
(29, 29, 1, NULL),
(30, 30, 1, NULL),
(31, 31, 1, NULL),
(32, 32, 1, NULL),
(33, 33, 1, NULL),
(34, 34, 1, NULL),
(35, 35, 1, NULL),
(36, 36, 1, NULL),
(38, 38, 1, NULL),
(39, 39, 1, NULL),
(40, 40, 1, NULL),
(41, 41, 1, NULL),
(42, 42, 1, NULL),
(43, 43, 1, NULL),
(44, 44, 1, NULL),
(45, 45, 1, NULL),
(46, 46, 1, NULL),
(47, 47, 1, NULL),
(48, 48, 1, NULL),
(49, 49, 1, NULL),
(50, 50, 1, NULL),
(51, 51, 1, NULL),
(52, 52, 1, NULL),
(53, 53, 1, NULL),
(54, 54, 1, NULL),
(55, 55, 1, NULL),
(56, 56, 1, NULL),
(57, 57, 1, NULL),
(58, 58, 1, NULL),
(59, 59, 1, NULL),
(60, 60, 1, NULL),
(61, 61, 1, NULL),
(62, 62, 1, NULL),
(63, 63, 1, NULL),
(64, 64, 1, NULL),
(65, 65, 1, NULL),
(66, 66, 1, NULL),
(68, 68, 1, NULL),
(69, 69, 1, NULL),
(70, 70, 1, NULL),
(71, 71, 1, NULL),
(72, 72, 1, NULL),
(74, 74, 1, NULL),
(75, 75, 1, NULL),
(78, 78, 1, NULL),
(79, 79, 1, NULL),
(80, 80, 1, NULL),
(81, 81, 1, NULL),
(82, 82, 1, NULL),
(83, 83, 1, NULL),
(84, 84, 1, NULL),
(85, 85, 1, NULL),
(86, 86, 1, NULL),
(87, 87, 1, NULL),
(88, 88, 1, NULL),
(89, 89, 1, NULL),
(90, 90, 1, NULL),
(91, 91, 1, NULL),
(92, 92, 1, NULL),
(93, 93, 1, NULL),
(94, 94, 1, NULL),
(95, 95, 1, NULL),
(96, 96, 1, NULL),
(97, 97, 1, NULL),
(98, 98, 1, NULL),
(99, 99, 1, NULL),
(100, 77, 1, NULL),
(101, 76, 1, NULL),
(102, 67, 1, NULL),
(103, 37, 1, NULL),
(105, 73, 1, NULL);

INSERT INTO "public"."files_related_morphs" ("id", "file_id", "related_id", "related_type", "field", "order") VALUES
(7, 21, 1, 'general.image-text-section', 'thumbnail', 1),
(8, 22, 2, 'general.image-text-section', 'thumbnail', 1),
(9, 18, 3, 'general.image-text-section', 'thumbnail', 1),
(10, 27, 4, 'general.image-text-section', 'thumbnail', 1),
(11, 21, 1, 'api::exercise.exercise', 'thumbnail', 1),
(35, 64, 19, 'general.image-text-section', 'thumbnail', 1),
(36, 65, 20, 'general.image-text-section', 'thumbnail', 1),
(37, 61, 21, 'general.image-text-section', 'thumbnail', 1),
(38, 63, 22, 'general.image-text-section', 'thumbnail', 1),
(39, 64, 5, 'api::exercise.exercise', 'thumbnail', 1),
(48, 78, 27, 'general.image-text-section', 'thumbnail', 1),
(49, 79, 28, 'general.image-text-section', 'thumbnail', 1),
(50, 78, 7, 'api::exercise.exercise', 'thumbnail', 1),
(52, 19, 30, 'general.image-text-section', 'thumbnail', 1),
(53, 23, 31, 'general.image-text-section', 'thumbnail', 1),
(54, 28, 32, 'general.image-text-section', 'thumbnail', 1),
(55, 28, 33, 'general.image-text-section', 'thumbnail', 1),
(56, 19, 8, 'api::exercise.exercise', 'thumbnail', 1),
(58, 35, 34, 'general.image-text-section', 'thumbnail', 1),
(59, 36, 35, 'general.image-text-section', 'thumbnail', 1),
(60, 35, 9, 'api::exercise.exercise', 'thumbnail', 1),
(63, 31, 36, 'general.image-text-section', 'thumbnail', 1),
(64, 32, 37, 'general.image-text-section', 'thumbnail', 1),
(65, 31, 10, 'api::exercise.exercise', 'thumbnail', 1),
(67, 42, 38, 'general.image-text-section', 'thumbnail', 1),
(68, 41, 39, 'general.image-text-section', 'thumbnail', 1),
(69, 39, 40, 'general.image-text-section', 'thumbnail', 1),
(70, 40, 41, 'general.image-text-section', 'thumbnail', 1),
(71, 42, 11, 'api::exercise.exercise', 'thumbnail', 1),
(73, 26, 42, 'general.image-text-section', 'thumbnail', 1),
(74, 29, 43, 'general.image-text-section', 'thumbnail', 1),
(75, 33, 44, 'general.image-text-section', 'thumbnail', 1),
(76, 34, 45, 'general.image-text-section', 'thumbnail', 1),
(77, 26, 12, 'api::exercise.exercise', 'thumbnail', 1),
(79, 5, 46, 'general.image-text-section', 'thumbnail', 1),
(80, 7, 47, 'general.image-text-section', 'thumbnail', 1),
(81, 6, 48, 'general.image-text-section', 'thumbnail', 1),
(82, 5, 13, 'api::exercise.exercise', 'thumbnail', 1),
(84, 15, 49, 'general.image-text-section', 'thumbnail', 1),
(85, 20, 50, 'general.image-text-section', 'thumbnail', 1),
(86, 11, 51, 'general.image-text-section', 'thumbnail', 1),
(87, 15, 14, 'api::exercise.exercise', 'thumbnail', 1),
(89, 80, 52, 'general.image-text-section', 'thumbnail', 1),
(90, 81, 53, 'general.image-text-section', 'thumbnail', 1),
(91, 80, 15, 'api::exercise.exercise', 'thumbnail', 1),
(93, 84, 56, 'general.image-text-section', 'thumbnail', 1),
(94, 85, 57, 'general.image-text-section', 'thumbnail', 1),
(95, 84, 16, 'api::exercise.exercise', 'thumbnail', 1),
(97, 72, 59, 'general.image-text-section', 'thumbnail', 1),
(98, 74, 60, 'general.image-text-section', 'thumbnail', 1),
(99, 72, 17, 'api::exercise.exercise', 'thumbnail', 1),
(101, 53, 62, 'general.image-text-section', 'thumbnail', 1),
(102, 51, 63, 'general.image-text-section', 'thumbnail', 1),
(103, 54, 64, 'general.image-text-section', 'thumbnail', 1),
(104, 55, 65, 'general.image-text-section', 'thumbnail', 1),
(105, 56, 66, 'general.image-text-section', 'thumbnail', 1),
(106, 58, 67, 'general.image-text-section', 'thumbnail', 1),
(107, 57, 68, 'general.image-text-section', 'thumbnail', 1),
(108, 59, 69, 'general.image-text-section', 'thumbnail', 1),
(109, 53, 18, 'api::exercise.exercise', 'thumbnail', 1),
(111, 66, 70, 'general.image-text-section', 'thumbnail', 1),
(112, 67, 71, 'general.image-text-section', 'thumbnail', 1),
(113, 66, 19, 'api::exercise.exercise', 'thumbnail', 1),
(115, 48, 72, 'general.image-text-section', 'thumbnail', 1),
(116, 49, 73, 'general.image-text-section', 'thumbnail', 1),
(117, 50, 74, 'general.image-text-section', 'thumbnail', 1),
(118, 52, 75, 'general.image-text-section', 'thumbnail', 1),
(119, 48, 20, 'api::exercise.exercise', 'thumbnail', 1),
(121, 16, 76, 'general.image-text-section', 'thumbnail', 1),
(122, 17, 77, 'general.image-text-section', 'thumbnail', 1),
(123, 16, 21, 'api::exercise.exercise', 'thumbnail', 1),
(125, 37, 79, 'general.image-text-section', 'thumbnail', 1),
(126, 38, 80, 'general.image-text-section', 'thumbnail', 1),
(127, 38, 22, 'api::exercise.exercise', 'thumbnail', 1),
(129, 10, 81, 'general.image-text-section', 'thumbnail', 1),
(130, 12, 82, 'general.image-text-section', 'thumbnail', 1),
(131, 10, 23, 'api::exercise.exercise', 'thumbnail', 1),
(133, 70, 83, 'general.image-text-section', 'thumbnail', 1),
(134, 71, 84, 'general.image-text-section', 'thumbnail', 1),
(135, 70, 24, 'api::exercise.exercise', 'thumbnail', 1),
(137, 68, 85, 'general.image-text-section', 'thumbnail', 1),
(138, 69, 86, 'general.image-text-section', 'thumbnail', 1),
(139, 68, 25, 'api::exercise.exercise', 'thumbnail', 1),
(141, 8, 87, 'general.image-text-section', 'thumbnail', 1),
(142, 9, 88, 'general.image-text-section', 'thumbnail', 1),
(143, 8, 26, 'api::exercise.exercise', 'thumbnail', 1),
(148, 90, 91, 'general.image-text-section', 'thumbnail', 1),
(149, 91, 92, 'general.image-text-section', 'thumbnail', 1),
(150, 90, 28, 'api::exercise.exercise', 'thumbnail', 1),
(152, 96, 95, 'general.image-text-section', 'thumbnail', 1),
(153, 97, 96, 'general.image-text-section', 'thumbnail', 1),
(154, 96, 29, 'api::exercise.exercise', 'thumbnail', 1),
(158, 98, 98, 'general.image-text-section', 'thumbnail', 1),
(159, 99, 97, 'general.image-text-section', 'thumbnail', 1),
(160, 99, 30, 'api::exercise.exercise', 'thumbnail', 1),
(165, 93, 99, 'general.image-text-section', 'thumbnail', 1),
(166, 95, 100, 'general.image-text-section', 'thumbnail', 1),
(167, 93, 31, 'api::exercise.exercise', 'thumbnail', 1),
(169, 24, 101, 'general.image-text-section', 'thumbnail', 1),
(170, 25, 102, 'general.image-text-section', 'thumbnail', 1),
(171, 24, 32, 'api::exercise.exercise', 'thumbnail', 1),
(173, 13, 103, 'general.image-text-section', 'thumbnail', 1),
(174, 14, 104, 'general.image-text-section', 'thumbnail', 1),
(175, 13, 33, 'api::exercise.exercise', 'thumbnail', 1),
(177, 92, 106, 'general.image-text-section', 'thumbnail', 1),
(178, 94, 107, 'general.image-text-section', 'thumbnail', 1),
(179, 92, 34, 'api::exercise.exercise', 'thumbnail', 1),
(181, 60, 108, 'general.image-text-section', 'thumbnail', 1),
(182, 62, 109, 'general.image-text-section', 'thumbnail', 1),
(183, 60, 35, 'api::exercise.exercise', 'thumbnail', 1),
(185, 43, 110, 'general.image-text-section', 'thumbnail', 1),
(186, 45, 111, 'general.image-text-section', 'thumbnail', 1),
(187, 43, 36, 'api::exercise.exercise', 'thumbnail', 1),
(188, 86, 17, 'general.image-text-section', 'thumbnail', 1),
(189, 88, 18, 'general.image-text-section', 'thumbnail', 1),
(190, 86, 4, 'api::exercise.exercise', 'thumbnail', 1),
(191, 73, 5, 'general.image-text-section', 'thumbnail', 1),
(192, 75, 6, 'general.image-text-section', 'thumbnail', 1),
(193, 76, 7, 'general.image-text-section', 'thumbnail', 1),
(194, 77, 8, 'general.image-text-section', 'thumbnail', 1),
(195, 73, 2, 'api::exercise.exercise', 'thumbnail', 1),
(199, 89, 89, 'general.image-text-section', 'thumbnail', 1),
(200, 87, 90, 'general.image-text-section', 'thumbnail', 1),
(201, 89, 27, 'api::exercise.exercise', 'thumbnail', 1),
(202, 44, 23, 'general.image-text-section', 'thumbnail', 1),
(203, 47, 25, 'general.image-text-section', 'thumbnail', 1),
(204, 44, 6, 'api::exercise.exercise', 'thumbnail', 1),
(205, 82, 11, 'general.image-text-section', 'thumbnail', 1),
(206, 83, 12, 'general.image-text-section', 'thumbnail', 1),
(207, 82, 3, 'api::exercise.exercise', 'thumbnail', 1);

INSERT INTO "public"."i18n_locale" ("id", "name", "code", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(1, 'English (en)', 'en', '2023-02-02 14:47:03.42', '2023-02-02 14:47:03.42', NULL, NULL);

INSERT INTO "public"."strapi_core_store_settings" ("id", "key", "value", "type", "environment", "tag") VALUES
(1, 'strapi_content_types_schema', '{"admin::permission":{"collectionName":"admin_permissions","info":{"name":"Permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"properties":{"type":"json","configurable":false,"required":false,"default":{}},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::role"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"admin_permissions","info":{"name":"Permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"properties":{"type":"json","configurable":false,"required":false,"default":{}},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::role"}},"kind":"collectionType"},"modelType":"contentType","modelName":"permission","connection":"default","uid":"admin::permission","plugin":"admin","globalId":"AdminPermission"},"admin::user":{"collectionName":"admin_users","info":{"name":"User","description":"","singularName":"user","pluralName":"users","displayName":"User"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true},"resetPasswordToken":{"type":"string","configurable":false,"private":true},"registrationToken":{"type":"string","configurable":false,"private":true},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"configurable":false,"private":true,"type":"relation","relation":"manyToMany","inversedBy":"users","target":"admin::role","collectionName":"strapi_users_roles"},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true},"preferedLanguage":{"type":"string","configurable":false,"required":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"admin_users","info":{"name":"User","description":"","singularName":"user","pluralName":"users","displayName":"User"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true},"resetPasswordToken":{"type":"string","configurable":false,"private":true},"registrationToken":{"type":"string","configurable":false,"private":true},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"configurable":false,"private":true,"type":"relation","relation":"manyToMany","inversedBy":"users","target":"admin::role","collectionName":"strapi_users_roles"},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true},"preferedLanguage":{"type":"string","configurable":false,"required":false}},"kind":"collectionType"},"modelType":"contentType","modelName":"user","connection":"default","uid":"admin::user","plugin":"admin","globalId":"AdminUser"},"admin::role":{"collectionName":"admin_roles","info":{"name":"Role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"type":"relation","relation":"manyToMany","mappedBy":"roles","target":"admin::user"},"permissions":{"configurable":false,"type":"relation","relation":"oneToMany","mappedBy":"role","target":"admin::permission"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"admin_roles","info":{"name":"Role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"type":"relation","relation":"manyToMany","mappedBy":"roles","target":"admin::user"},"permissions":{"configurable":false,"type":"relation","relation":"oneToMany","mappedBy":"role","target":"admin::permission"}},"kind":"collectionType"},"modelType":"contentType","modelName":"role","connection":"default","uid":"admin::role","plugin":"admin","globalId":"AdminRole"},"admin::api-token":{"collectionName":"strapi_api_tokens","info":{"name":"Api Token","singularName":"api-token","pluralName":"api-tokens","displayName":"Api Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"type":{"type":"enumeration","enum":["read-only","full-access","custom"],"configurable":false,"required":true,"default":"read-only"},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::api-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"strapi_api_tokens","info":{"name":"Api Token","singularName":"api-token","pluralName":"api-tokens","displayName":"Api Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"type":{"type":"enumeration","enum":["read-only","full-access","custom"],"configurable":false,"required":true,"default":"read-only"},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::api-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false}},"kind":"collectionType"},"modelType":"contentType","modelName":"api-token","connection":"default","uid":"admin::api-token","plugin":"admin","globalId":"AdminApiToken"},"admin::api-token-permission":{"collectionName":"strapi_api_token_permissions","info":{"name":"API Token Permission","description":"","singularName":"api-token-permission","pluralName":"api-token-permissions","displayName":"API Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::api-token"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"strapi_api_token_permissions","info":{"name":"API Token Permission","description":"","singularName":"api-token-permission","pluralName":"api-token-permissions","displayName":"API Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::api-token"}},"kind":"collectionType"},"modelType":"contentType","modelName":"api-token-permission","connection":"default","uid":"admin::api-token-permission","plugin":"admin","globalId":"AdminApiTokenPermission"},"plugin::upload.file":{"collectionName":"files","info":{"singularName":"file","pluralName":"files","displayName":"File","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"string","configurable":false},"caption":{"type":"string","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"string","configurable":false,"required":true},"previewUrl":{"type":"string","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"type":"relation","relation":"morphToMany","configurable":false},"folder":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"files","private":true},"folderPath":{"type":"string","min":1,"required":true,"private":true},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"indexes":[{"name":"upload_files_folder_path_index","columns":["folder_path"],"type":null},{"name":"upload_files_created_at_index","columns":["created_at"],"type":null},{"name":"upload_files_updated_at_index","columns":["updated_at"],"type":null},{"name":"upload_files_name_index","columns":["name"],"type":null},{"name":"upload_files_size_index","columns":["size"],"type":null},{"name":"upload_files_ext_index","columns":["ext"],"type":null}],"kind":"collectionType","__schema__":{"collectionName":"files","info":{"singularName":"file","pluralName":"files","displayName":"File","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"string","configurable":false},"caption":{"type":"string","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"string","configurable":false,"required":true},"previewUrl":{"type":"string","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"type":"relation","relation":"morphToMany","configurable":false},"folder":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"files","private":true},"folderPath":{"type":"string","min":1,"required":true,"private":true}},"kind":"collectionType"},"modelType":"contentType","modelName":"file","connection":"default","uid":"plugin::upload.file","plugin":"upload","globalId":"UploadFile"},"plugin::upload.folder":{"collectionName":"upload_folders","info":{"singularName":"folder","pluralName":"folders","displayName":"Folder"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"required":true},"pathId":{"type":"integer","unique":true,"required":true},"parent":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","mappedBy":"parent"},"files":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","mappedBy":"folder"},"path":{"type":"string","min":1,"required":true},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"indexes":[{"name":"upload_folders_path_id_index","columns":["path_id"],"type":"unique"},{"name":"upload_folders_path_index","columns":["path"],"type":"unique"}],"kind":"collectionType","__schema__":{"collectionName":"upload_folders","info":{"singularName":"folder","pluralName":"folders","displayName":"Folder"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"required":true},"pathId":{"type":"integer","unique":true,"required":true},"parent":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","mappedBy":"parent"},"files":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","mappedBy":"folder"},"path":{"type":"string","min":1,"required":true}},"kind":"collectionType"},"modelType":"contentType","modelName":"folder","connection":"default","uid":"plugin::upload.folder","plugin":"upload","globalId":"UploadFolder"},"plugin::i18n.locale":{"info":{"singularName":"locale","pluralName":"locales","collectionName":"locales","displayName":"Locale","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"max":50,"configurable":false},"code":{"type":"string","unique":true,"configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"info":{"singularName":"locale","pluralName":"locales","collectionName":"locales","displayName":"Locale","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"max":50,"configurable":false},"code":{"type":"string","unique":true,"configurable":false}},"kind":"collectionType"},"modelType":"contentType","modelName":"locale","connection":"default","uid":"plugin::i18n.locale","plugin":"i18n","collectionName":"i18n_locale","globalId":"I18NLocale"},"plugin::users-permissions.permission":{"collectionName":"up_permissions","info":{"name":"permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"permissions","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"up_permissions","info":{"name":"permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"permissions","configurable":false}},"kind":"collectionType"},"modelType":"contentType","modelName":"permission","connection":"default","uid":"plugin::users-permissions.permission","plugin":"users-permissions","globalId":"UsersPermissionsPermission"},"plugin::users-permissions.role":{"collectionName":"up_roles","info":{"name":"role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","mappedBy":"role","configurable":false},"users":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","mappedBy":"role","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"up_roles","info":{"name":"role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","mappedBy":"role","configurable":false},"users":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","mappedBy":"role","configurable":false}},"kind":"collectionType"},"modelType":"contentType","modelName":"role","connection":"default","uid":"plugin::users-permissions.role","plugin":"users-permissions","globalId":"UsersPermissionsRole"},"plugin::users-permissions.user":{"collectionName":"up_users","info":{"name":"user","description":"","singularName":"user","pluralName":"users","displayName":"User"},"options":{"draftAndPublish":false,"timestamps":true},"attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true},"resetPasswordToken":{"type":"string","configurable":false,"private":true},"confirmationToken":{"type":"string","configurable":false,"private":true},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"users","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"config":{"attributes":{"resetPasswordToken":{"hidden":true},"confirmationToken":{"hidden":true},"provider":{"hidden":true}}},"kind":"collectionType","__schema__":{"collectionName":"up_users","info":{"name":"user","description":"","singularName":"user","pluralName":"users","displayName":"User"},"options":{"draftAndPublish":false,"timestamps":true},"attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true},"resetPasswordToken":{"type":"string","configurable":false,"private":true},"confirmationToken":{"type":"string","configurable":false,"private":true},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"users","configurable":false}},"kind":"collectionType"},"modelType":"contentType","modelName":"user","connection":"default","uid":"plugin::users-permissions.user","plugin":"users-permissions","globalId":"UsersPermissionsUser"},"api::category.category":{"kind":"collectionType","collectionName":"categories","info":{"singularName":"category","pluralName":"categories","displayName":"Category"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"title":{"type":"string","required":true},"slug":{"type":"uid","targetField":"title","required":true},"exercises":{"type":"relation","relation":"manyToMany","target":"api::exercise.exercise","mappedBy":"categories"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"__schema__":{"collectionName":"categories","info":{"singularName":"category","pluralName":"categories","displayName":"Category"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"title":{"type":"string","required":true},"slug":{"type":"uid","targetField":"title","required":true},"exercises":{"type":"relation","relation":"manyToMany","target":"api::exercise.exercise","mappedBy":"categories"}},"kind":"collectionType"},"modelType":"contentType","modelName":"category","connection":"default","uid":"api::category.category","apiName":"category","globalId":"Category","actions":{},"lifecycles":{}},"api::exercise.exercise":{"kind":"collectionType","collectionName":"exercises","info":{"singularName":"exercise","pluralName":"exercises","displayName":"Exercise","description":""},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"title":{"type":"string","required":true},"slug":{"type":"uid","targetField":"title"},"purpose":{"type":"string"},"thumbnail":{"type":"media","multiple":false,"required":false,"allowedTypes":["images"]},"Body":{"type":"dynamiczone","components":["exercises.steps","exercises.progressions","exercises.description"]},"categories":{"type":"relation","relation":"manyToMany","target":"api::category.category","inversedBy":"exercises"},"test":{"type":"string"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"__schema__":{"collectionName":"exercises","info":{"singularName":"exercise","pluralName":"exercises","displayName":"Exercise","description":""},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"title":{"type":"string","required":true},"slug":{"type":"uid","targetField":"title"},"purpose":{"type":"string"},"thumbnail":{"type":"media","multiple":false,"required":false,"allowedTypes":["images"]},"Body":{"type":"dynamiczone","components":["exercises.steps","exercises.progressions","exercises.description"]},"categories":{"type":"relation","relation":"manyToMany","target":"api::category.category","inversedBy":"exercises"},"test":{"type":"string"}},"kind":"collectionType"},"modelType":"contentType","modelName":"exercise","connection":"default","uid":"api::exercise.exercise","apiName":"exercise","globalId":"Exercise","actions":{},"lifecycles":{}},"api::workout.workout":{"kind":"collectionType","collectionName":"workouts","info":{"singularName":"workout","pluralName":"workouts","displayName":"Workout","description":""},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"title":{"type":"string"},"day":{"type":"component","repeatable":true,"component":"workout.day"},"slug":{"type":"uid","targetField":"title","required":true},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"__schema__":{"collectionName":"workouts","info":{"singularName":"workout","pluralName":"workouts","displayName":"Workout","description":""},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"title":{"type":"string"},"day":{"type":"component","repeatable":true,"component":"workout.day"},"slug":{"type":"uid","targetField":"title","required":true}},"kind":"collectionType"},"modelType":"contentType","modelName":"workout","connection":"default","uid":"api::workout.workout","apiName":"workout","globalId":"Workout","actions":{},"lifecycles":{}}}', 'object', NULL, NULL),
(2, 'plugin_content_manager_configuration_components::exercises.description', '{"uid":"exercises.description","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":false,"sortable":false}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":false,"sortable":false}}},"layouts":{"list":["id","description"],"edit":[[{"name":"description","size":12}]]},"isComponent":true}', 'object', NULL, NULL),
(3, 'plugin_content_manager_configuration_components::general.copy-section', '{"uid":"general.copy-section","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":false,"sortable":false}},"copy":{"edit":{"label":"copy","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"copy","searchable":false,"sortable":false}}},"layouts":{"list":["id"],"edit":[[{"name":"copy","size":12}]]},"isComponent":true}', 'object', NULL, NULL),
(4, 'plugin_content_manager_configuration_components::exercises.progressions', '{"uid":"exercises.progressions","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":false,"sortable":false}},"progressions":{"edit":{"label":"progressions","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"progressions","searchable":false,"sortable":false}}},"layouts":{"list":["id","progressions"],"edit":[[{"name":"progressions","size":12}]]},"isComponent":true}', 'object', NULL, NULL),
(5, 'plugin_content_manager_configuration_components::exercises.steps', '{"uid":"exercises.steps","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":false,"sortable":false}},"steps":{"edit":{"label":"steps","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"steps","searchable":false,"sortable":false}}},"layouts":{"list":["id","steps"],"edit":[[{"name":"steps","size":12}]]},"isComponent":true}', 'object', NULL, NULL),
(6, 'plugin_content_manager_configuration_components::general.image-text-section', '{"uid":"general.image-text-section","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":false,"sortable":false}},"thumbnail":{"edit":{"label":"thumbnail","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"thumbnail","searchable":false,"sortable":false}},"copy":{"edit":{"label":"copy","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"copy","searchable":false,"sortable":false}}},"layouts":{"list":["id","thumbnail"],"edit":[[{"name":"thumbnail","size":6}],[{"name":"copy","size":12}]]},"isComponent":true}', 'object', NULL, NULL),
(7, 'plugin_content_manager_configuration_components::workout.day', '{"uid":"workout.day","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":false,"sortable":false}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"day":{"edit":{"label":"day","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"day","searchable":false,"sortable":false}}},"layouts":{"list":["id","title","day"],"edit":[[{"name":"title","size":6}],[{"name":"day","size":12}]]},"isComponent":true}', 'object', NULL, NULL),
(8, 'plugin_content_manager_configuration_components::workout.exercise', '{"uid":"workout.exercise","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":false,"sortable":false}},"exercise":{"edit":{"label":"exercise","description":"","placeholder":"","visible":true,"editable":true,"mainField":"title"},"list":{"label":"exercise","searchable":true,"sortable":true}},"sets":{"edit":{"label":"sets","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"sets","searchable":true,"sortable":true}},"reps":{"edit":{"label":"reps","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"reps","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}}},"layouts":{"list":["id","exercise","sets","reps"],"edit":[[{"name":"exercise","size":6},{"name":"sets","size":4}],[{"name":"reps","size":4},{"name":"title","size":6}]]},"isComponent":true}', 'object', NULL, NULL),
(9, 'plugin_content_manager_configuration_content_types::admin::user', '{"uid":"admin::user","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"firstname","defaultSortBy":"firstname","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"firstname":{"edit":{"label":"firstname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"firstname","searchable":true,"sortable":true}},"lastname":{"edit":{"label":"lastname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastname","searchable":true,"sortable":true}},"username":{"edit":{"label":"username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"username","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"password":{"edit":{"label":"password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"resetPasswordToken","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"resetPasswordToken","searchable":true,"sortable":true}},"registrationToken":{"edit":{"label":"registrationToken","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"registrationToken","searchable":true,"sortable":true}},"isActive":{"edit":{"label":"isActive","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isActive","searchable":true,"sortable":true}},"roles":{"edit":{"label":"roles","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"roles","searchable":false,"sortable":false}},"blocked":{"edit":{"label":"blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"blocked","searchable":true,"sortable":true}},"preferedLanguage":{"edit":{"label":"preferedLanguage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"preferedLanguage","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}}},"layouts":{"list":["id","firstname","lastname","username"],"edit":[[{"name":"firstname","size":6},{"name":"lastname","size":6}],[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"resetPasswordToken","size":6}],[{"name":"registrationToken","size":6},{"name":"isActive","size":4}],[{"name":"roles","size":6},{"name":"blocked","size":4}],[{"name":"preferedLanguage","size":6}]]}}', 'object', NULL, NULL),
(10, 'plugin_content_manager_configuration_content_types::admin::role', '{"uid":"admin::role","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"code":{"edit":{"label":"code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"code","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"users":{"edit":{"label":"users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"users","searchable":false,"sortable":false}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","description"],"edit":[[{"name":"name","size":6},{"name":"code","size":6}],[{"name":"description","size":6},{"name":"users","size":6}],[{"name":"permissions","size":6}]]}}', 'object', NULL, NULL),
(11, 'plugin_content_manager_configuration_content_types::admin::api-token', '{"uid":"admin::api-token","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"accessKey":{"edit":{"label":"accessKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessKey","searchable":true,"sortable":true}},"lastUsedAt":{"edit":{"label":"lastUsedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastUsedAt","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"lifespan":{"edit":{"label":"lifespan","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lifespan","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6},{"name":"accessKey","size":6}],[{"name":"lastUsedAt","size":6},{"name":"permissions","size":6}],[{"name":"expiresAt","size":6},{"name":"lifespan","size":4}]]}}', 'object', NULL, NULL),
(12, 'plugin_content_manager_configuration_content_types::admin::api-token-permission', '{"uid":"admin::api-token-permission","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"token":{"edit":{"label":"token","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"token","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","token","createdAt"],"edit":[[{"name":"action","size":6},{"name":"token","size":6}]]}}', 'object', NULL, NULL),
(13, 'plugin_content_manager_configuration_content_types::plugin::i18n.locale', '{"uid":"plugin::i18n.locale","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"code":{"edit":{"label":"code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"code","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","createdAt"],"edit":[[{"name":"name","size":6},{"name":"code","size":6}]]}}', 'object', NULL, NULL),
(14, 'plugin_content_manager_configuration_content_types::admin::permission', '{"uid":"admin::permission","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"subject":{"edit":{"label":"subject","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"subject","searchable":true,"sortable":true}},"properties":{"edit":{"label":"properties","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"properties","searchable":false,"sortable":false}},"conditions":{"edit":{"label":"conditions","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"conditions","searchable":false,"sortable":false}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","subject","role"],"edit":[[{"name":"action","size":6},{"name":"subject","size":6}],[{"name":"properties","size":12}],[{"name":"conditions","size":12}],[{"name":"role","size":6}]]}}', 'object', NULL, NULL),
(15, 'plugin_content_manager_configuration_content_types::plugin::users-permissions.role', '{"uid":"plugin::users-permissions.role","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"users":{"edit":{"label":"users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"users","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6},{"name":"permissions","size":6}],[{"name":"users","size":6}]]}}', 'object', NULL, NULL),
(16, 'plugin_content_manager_configuration_content_types::api::category.category', '{"uid":"api::category.category","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"exercises":{"edit":{"label":"exercises","description":"","placeholder":"","visible":true,"editable":true,"mainField":"title"},"list":{"label":"exercises","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}}},"layouts":{"list":["id","title","slug","exercises"],"edit":[[{"name":"title","size":6},{"name":"slug","size":6}],[{"name":"exercises","size":6}]]}}', 'object', NULL, NULL),
(17, 'plugin_content_manager_configuration_content_types::plugin::upload.file', '{"uid":"plugin::upload.file","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"alternativeText":{"edit":{"label":"alternativeText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"alternativeText","searchable":true,"sortable":true}},"caption":{"edit":{"label":"caption","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"caption","searchable":true,"sortable":true}},"width":{"edit":{"label":"width","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"width","searchable":true,"sortable":true}},"height":{"edit":{"label":"height","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"height","searchable":true,"sortable":true}},"formats":{"edit":{"label":"formats","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"formats","searchable":false,"sortable":false}},"hash":{"edit":{"label":"hash","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"hash","searchable":true,"sortable":true}},"ext":{"edit":{"label":"ext","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ext","searchable":true,"sortable":true}},"mime":{"edit":{"label":"mime","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"mime","searchable":true,"sortable":true}},"size":{"edit":{"label":"size","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"size","searchable":true,"sortable":true}},"url":{"edit":{"label":"url","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"url","searchable":true,"sortable":true}},"previewUrl":{"edit":{"label":"previewUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"previewUrl","searchable":true,"sortable":true}},"provider":{"edit":{"label":"provider","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"provider","searchable":true,"sortable":true}},"provider_metadata":{"edit":{"label":"provider_metadata","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"provider_metadata","searchable":false,"sortable":false}},"folder":{"edit":{"label":"folder","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"folder","searchable":true,"sortable":true}},"folderPath":{"edit":{"label":"folderPath","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"folderPath","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","alternativeText","caption"],"edit":[[{"name":"name","size":6},{"name":"alternativeText","size":6}],[{"name":"caption","size":6},{"name":"width","size":4}],[{"name":"height","size":4}],[{"name":"formats","size":12}],[{"name":"hash","size":6},{"name":"ext","size":6}],[{"name":"mime","size":6},{"name":"size","size":4}],[{"name":"url","size":6},{"name":"previewUrl","size":6}],[{"name":"provider","size":6}],[{"name":"provider_metadata","size":12}],[{"name":"folder","size":6},{"name":"folderPath","size":6}]]}}', 'object', NULL, NULL),
(18, 'plugin_content_manager_configuration_content_types::plugin::users-permissions.permission', '{"uid":"plugin::users-permissions.permission","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","role","createdAt"],"edit":[[{"name":"action","size":6},{"name":"role","size":6}]]}}', 'object', NULL, NULL),
(19, 'plugin_content_manager_configuration_content_types::api::workout.workout', '{"uid":"api::workout.workout","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"day":{"edit":{"label":"day","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"day","searchable":false,"sortable":false}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}}},"layouts":{"edit":[[{"name":"title","size":6},{"name":"slug","size":6}],[{"name":"day","size":12}]],"list":["id","title","day","slug"]}}', 'object', NULL, NULL),
(20, 'plugin_content_manager_configuration_content_types::plugin::users-permissions.user', '{"uid":"plugin::users-permissions.user","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"username","defaultSortBy":"username","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"username":{"edit":{"label":"username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"username","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"provider":{"edit":{"label":"provider","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"provider","searchable":true,"sortable":true}},"password":{"edit":{"label":"password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"resetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"resetPasswordToken","searchable":true,"sortable":true}},"confirmationToken":{"edit":{"label":"confirmationToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"confirmationToken","searchable":true,"sortable":true}},"confirmed":{"edit":{"label":"confirmed","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"confirmed","searchable":true,"sortable":true}},"blocked":{"edit":{"label":"blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"blocked","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}}},"layouts":{"list":["id","username","email","confirmed"],"edit":[[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"confirmed","size":4}],[{"name":"blocked","size":4},{"name":"role","size":6}]]}}', 'object', NULL, NULL),
(21, 'plugin_content_manager_configuration_content_types::plugin::upload.folder', '{"uid":"plugin::upload.folder","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"pathId":{"edit":{"label":"pathId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"pathId","searchable":true,"sortable":true}},"parent":{"edit":{"label":"parent","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"parent","searchable":true,"sortable":true}},"children":{"edit":{"label":"children","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"children","searchable":false,"sortable":false}},"files":{"edit":{"label":"files","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"files","searchable":false,"sortable":false}},"path":{"edit":{"label":"path","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"path","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","pathId","parent"],"edit":[[{"name":"name","size":6},{"name":"pathId","size":4}],[{"name":"parent","size":6},{"name":"children","size":6}],[{"name":"files","size":6},{"name":"path","size":6}]]}}', 'object', NULL, NULL),
(22, 'plugin_content_manager_configuration_content_types::api::exercise.exercise', '{"uid":"api::exercise.exercise","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"purpose":{"edit":{"label":"purpose","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"purpose","searchable":true,"sortable":true}},"thumbnail":{"edit":{"label":"thumbnail","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"thumbnail","searchable":false,"sortable":false}},"Body":{"edit":{"label":"Body","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Body","searchable":false,"sortable":false}},"categories":{"edit":{"label":"categories","description":"","placeholder":"","visible":true,"editable":true,"mainField":"title"},"list":{"label":"categories","searchable":false,"sortable":false}},"test":{"edit":{"label":"test","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"test","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}}},"layouts":{"list":["id","title","slug","purpose"],"edit":[[{"name":"title","size":6},{"name":"slug","size":6}],[{"name":"purpose","size":6},{"name":"thumbnail","size":6}],[{"name":"Body","size":12}],[{"name":"categories","size":6},{"name":"test","size":6}]]}}', 'object', NULL, NULL),
(23, 'plugin_upload_settings', '{"sizeOptimization":true,"responsiveDimensions":true,"autoOrientation":false}', 'object', NULL, NULL),
(24, 'plugin_upload_view_configuration', '{"pageSize":10,"sort":"createdAt:DESC"}', 'object', NULL, NULL),
(25, 'plugin_upload_metrics', '{"weeklySchedule":"18 28 12 * * 0","lastWeeklyUpdate":1677410898021}', 'object', NULL, NULL),
(26, 'plugin_i18n_default_locale', '"en"', 'string', NULL, NULL),
(27, 'plugin_users-permissions_grant', '{"email":{"enabled":true,"icon":"envelope"},"discord":{"enabled":false,"icon":"discord","key":"","secret":"","callback":"api/auth/discord/callback","scope":["identify","email"],"redirectUri":"http://localhost:1337/api/connect/discord/callback"},"facebook":{"enabled":false,"icon":"facebook-square","key":"","secret":"","callback":"api/auth/facebook/callback","scope":["email"],"redirectUri":"http://localhost:1337/api/connect/facebook/callback"},"google":{"enabled":true,"icon":"google","key":"739895288960-5h0ca2j6h9n1fsv736ojp4hgcq5025da.apps.googleusercontent.com","secret":"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","callback":"api/auth/google/callback","scope":["email"],"redirectUri":"http://localhost:1337/api/connect/google/callback"},"github":{"enabled":true,"icon":"github","key":"8466b7b088231425b287","secret":"1744a92f310b42f334cce114d791facfc5635e5e","callback":"api/auth/github/callback","scope":["user","user:email"],"redirectUri":"http://localhost:1337/api/connect/github/callback"},"microsoft":{"enabled":false,"icon":"windows","key":"","secret":"","callback":"api/auth/microsoft/callback","scope":["user.read"],"redirectUri":"http://localhost:1337/api/connect/microsoft/callback"},"twitter":{"enabled":false,"icon":"twitter","key":"","secret":"","callback":"api/auth/twitter/callback","redirectUri":"http://localhost:1337/api/connect/twitter/callback"},"instagram":{"enabled":false,"icon":"instagram","key":"","secret":"","callback":"api/auth/instagram/callback","scope":["user_profile"],"redirectUri":"http://localhost:1337/api/connect/instagram/callback"},"vk":{"enabled":false,"icon":"vk","key":"","secret":"","callback":"api/auth/vk/callback","scope":["email"],"redirectUri":"http://localhost:1337/api/connect/vk/callback"},"twitch":{"enabled":false,"icon":"twitch","key":"","secret":"","callback":"api/auth/twitch/callback","scope":["user:read:email"],"redirectUri":"http://localhost:1337/api/connect/twitch/callback"},"linkedin":{"enabled":false,"icon":"linkedin","key":"","secret":"","callback":"api/auth/linkedin/callback","scope":["r_liteprofile","r_emailaddress"],"redirectUri":"http://localhost:1337/api/connect/linkedin/callback"},"cognito":{"enabled":false,"icon":"aws","key":"","secret":"","subdomain":"my.subdomain.com","callback":"api/auth/cognito/callback","scope":["email","openid","profile"],"redirectUri":"http://localhost:1337/api/connect/cognito/callback"},"reddit":{"enabled":false,"icon":"reddit","key":"","secret":"","state":true,"callback":"api/auth/reddit/callback","scope":["identity"],"redirectUri":"http://localhost:1337/api/connect/reddit/callback"},"auth0":{"enabled":false,"icon":"","key":"","secret":"","subdomain":"my-tenant.eu","callback":"api/auth/auth0/callback","scope":["openid","email","profile"],"redirectUri":"http://localhost:1337/api/connect/auth0/callback"},"cas":{"enabled":false,"icon":"book","key":"","secret":"","callback":"api/auth/cas/callback","scope":["openid email"],"subdomain":"my.subdomain.com/cas","redirectUri":"http://localhost:1337/api/connect/cas/callback"},"patreon":{"enabled":false,"icon":"","key":"","secret":"","callback":"api/auth/patreon/callback","scope":["identity","identity[email]"]}}', 'object', NULL, NULL),
(28, 'plugin_users-permissions_email', '{"reset_password":{"display":"Email.template.reset_password","icon":"sync","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Reset password","message":"<p>We heard that you lost your password. Sorry about that!</p>\n\n<p>But don’t worry! You can use the following link to reset your password:</p>\n<p><%= URL %>?code=<%= TOKEN %></p>\n\n<p>Thanks.</p>"}},"email_confirmation":{"display":"Email.template.email_confirmation","icon":"check-square","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Account confirmation","message":"<p>Thank you for registering!</p>\n\n<p>You have to confirm your email address. Please click on the link below.</p>\n\n<p><%= URL %>?confirmation=<%= CODE %></p>\n\n<p>Thanks.</p>"}}}', 'object', NULL, NULL),
(29, 'plugin_users-permissions_advanced', '{"unique_email":true,"allow_register":true,"email_confirmation":false,"email_reset_password":null,"email_confirmation_redirection":null,"default_role":"authenticated"}', 'object', NULL, NULL),
(30, 'core_admin_auth', '{"providers":{"autoRegister":false,"defaultRole":null}}', 'object', NULL, NULL);

INSERT INTO "public"."strapi_database_schema" ("id", "schema", "time", "hash") VALUES
(3, '{"tables":[{"name":"strapi_core_store_settings","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"value","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"environment","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"tag","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_webhooks","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"url","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"headers","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"events","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"enabled","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_ee_store_settings","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"value","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_permissions","indexes":[{"name":"admin_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"subject","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"properties","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"conditions","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_users","indexes":[{"name":"admin_users_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_users_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_users_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_users_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"firstname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lastname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"username","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"password","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reset_password_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"registration_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_active","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"blocked","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"prefered_language","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_roles","indexes":[{"name":"admin_roles_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_roles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_roles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_roles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_api_tokens","indexes":[{"name":"strapi_api_tokens_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_api_tokens_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_api_tokens_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_api_tokens_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_used_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lifespan","type":"bigInteger","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_api_token_permissions","indexes":[{"name":"strapi_api_token_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_api_token_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_api_token_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_api_token_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"files","indexes":[{"name":"upload_files_folder_path_index","columns":["folder_path"],"type":null},{"name":"upload_files_created_at_index","columns":["created_at"],"type":null},{"name":"upload_files_updated_at_index","columns":["updated_at"],"type":null},{"name":"upload_files_name_index","columns":["name"],"type":null},{"name":"upload_files_size_index","columns":["size"],"type":null},{"name":"upload_files_ext_index","columns":["ext"],"type":null},{"name":"files_created_by_id_fk","columns":["created_by_id"]},{"name":"files_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"files_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"files_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"alternative_text","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"caption","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"width","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"height","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"formats","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hash","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"ext","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"mime","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"size","type":"decimal","args":[10,2],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"url","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"preview_url","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider_metadata","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"folder_path","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"upload_folders","indexes":[{"name":"upload_folders_path_id_index","columns":["path_id"],"type":"unique"},{"name":"upload_folders_path_index","columns":["path"],"type":"unique"},{"name":"upload_folders_created_by_id_fk","columns":["created_by_id"]},{"name":"upload_folders_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"upload_folders_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"upload_folders_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"path_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"path","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"i18n_locale","indexes":[{"name":"i18n_locale_created_by_id_fk","columns":["created_by_id"]},{"name":"i18n_locale_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"i18n_locale_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"i18n_locale_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_permissions","indexes":[{"name":"up_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"up_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_roles","indexes":[{"name":"up_roles_created_by_id_fk","columns":["created_by_id"]},{"name":"up_roles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_roles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_roles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_users","indexes":[{"name":"up_users_created_by_id_fk","columns":["created_by_id"]},{"name":"up_users_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_users_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_users_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"username","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"password","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reset_password_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"confirmation_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"confirmed","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"blocked","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"categories","indexes":[{"type":"unique","name":"categories_slug_unique","columns":["slug"]},{"name":"categories_created_by_id_fk","columns":["created_by_id"]},{"name":"categories_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"categories_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"categories_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false,"unique":true},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"exercises","indexes":[{"type":"unique","name":"exercises_slug_unique","columns":["slug"]},{"name":"exercises_created_by_id_fk","columns":["created_by_id"]},{"name":"exercises_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"exercises_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"exercises_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false,"unique":true},{"name":"purpose","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"test","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"workouts","indexes":[{"type":"unique","name":"workouts_slug_unique","columns":["slug"]},{"name":"workouts_created_by_id_fk","columns":["created_by_id"]},{"name":"workouts_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"workouts_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"workouts_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false,"unique":true},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"components_exercises_descriptions","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false}]},{"name":"components_exercises_progressions","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false}]},{"name":"components_exercises_steps","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false}]},{"name":"components_general_copy_sections","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"copy","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"components_general_image_text_sections","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"copy","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"components_workout_days","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"components_workout_exercises","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"sets","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reps","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_permissions_role_links","indexes":[{"name":"admin_permissions_role_links_fk","columns":["permission_id"]},{"name":"admin_permissions_role_links_inv_fk","columns":["role_id"]},{"name":"admin_permissions_role_links_unique","columns":["permission_id","role_id"],"type":"unique"},{"name":"admin_permissions_role_links_order_inv_fk","columns":["permission_order"]}],"foreignKeys":[{"name":"admin_permissions_role_links_fk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"admin_permissions","onDelete":"CASCADE"},{"name":"admin_permissions_role_links_inv_fk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"admin_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_users_roles_links","indexes":[{"name":"admin_users_roles_links_fk","columns":["user_id"]},{"name":"admin_users_roles_links_inv_fk","columns":["role_id"]},{"name":"admin_users_roles_links_unique","columns":["user_id","role_id"],"type":"unique"},{"name":"admin_users_roles_links_order_fk","columns":["role_order"]},{"name":"admin_users_roles_links_order_inv_fk","columns":["user_order"]}],"foreignKeys":[{"name":"admin_users_roles_links_fk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"admin_users","onDelete":"CASCADE"},{"name":"admin_users_roles_links_inv_fk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"admin_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_api_token_permissions_token_links","indexes":[{"name":"strapi_api_token_permissions_token_links_fk","columns":["api_token_permission_id"]},{"name":"strapi_api_token_permissions_token_links_inv_fk","columns":["api_token_id"]},{"name":"strapi_api_token_permissions_token_links_unique","columns":["api_token_permission_id","api_token_id"],"type":"unique"},{"name":"strapi_api_token_permissions_token_links_order_inv_fk","columns":["api_token_permission_order"]}],"foreignKeys":[{"name":"strapi_api_token_permissions_token_links_fk","columns":["api_token_permission_id"],"referencedColumns":["id"],"referencedTable":"strapi_api_token_permissions","onDelete":"CASCADE"},{"name":"strapi_api_token_permissions_token_links_inv_fk","columns":["api_token_id"],"referencedColumns":["id"],"referencedTable":"strapi_api_tokens","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"api_token_permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"api_token_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"api_token_permission_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"files_related_morphs","indexes":[{"name":"files_related_morphs_fk","columns":["file_id"]}],"foreignKeys":[{"name":"files_related_morphs_fk","columns":["file_id"],"referencedColumns":["id"],"referencedTable":"files","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"file_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"related_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"related_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"files_folder_links","indexes":[{"name":"files_folder_links_fk","columns":["file_id"]},{"name":"files_folder_links_inv_fk","columns":["folder_id"]},{"name":"files_folder_links_unique","columns":["file_id","folder_id"],"type":"unique"},{"name":"files_folder_links_order_inv_fk","columns":["file_order"]}],"foreignKeys":[{"name":"files_folder_links_fk","columns":["file_id"],"referencedColumns":["id"],"referencedTable":"files","onDelete":"CASCADE"},{"name":"files_folder_links_inv_fk","columns":["folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"file_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"file_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"upload_folders_parent_links","indexes":[{"name":"upload_folders_parent_links_fk","columns":["folder_id"]},{"name":"upload_folders_parent_links_inv_fk","columns":["inv_folder_id"]},{"name":"upload_folders_parent_links_unique","columns":["folder_id","inv_folder_id"],"type":"unique"},{"name":"upload_folders_parent_links_order_inv_fk","columns":["folder_order"]}],"foreignKeys":[{"name":"upload_folders_parent_links_fk","columns":["folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"},{"name":"upload_folders_parent_links_inv_fk","columns":["inv_folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"inv_folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"folder_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_permissions_role_links","indexes":[{"name":"up_permissions_role_links_fk","columns":["permission_id"]},{"name":"up_permissions_role_links_inv_fk","columns":["role_id"]},{"name":"up_permissions_role_links_unique","columns":["permission_id","role_id"],"type":"unique"},{"name":"up_permissions_role_links_order_inv_fk","columns":["permission_order"]}],"foreignKeys":[{"name":"up_permissions_role_links_fk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"up_permissions","onDelete":"CASCADE"},{"name":"up_permissions_role_links_inv_fk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"up_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_users_role_links","indexes":[{"name":"up_users_role_links_fk","columns":["user_id"]},{"name":"up_users_role_links_inv_fk","columns":["role_id"]},{"name":"up_users_role_links_unique","columns":["user_id","role_id"],"type":"unique"},{"name":"up_users_role_links_order_inv_fk","columns":["user_order"]}],"foreignKeys":[{"name":"up_users_role_links_fk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"up_users","onDelete":"CASCADE"},{"name":"up_users_role_links_inv_fk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"up_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"exercises_components","indexes":[{"name":"exercises_field_index","columns":["field"],"type":null},{"name":"exercises_component_type_index","columns":["component_type"],"type":null},{"name":"exercises_entity_fk","columns":["entity_id"]},{"name":"exercises_unique","columns":["entity_id","component_id","field","component_type"],"type":"unique"}],"foreignKeys":[{"name":"exercises_entity_fk","columns":["entity_id"],"referencedColumns":["id"],"referencedTable":"exercises","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"entity_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"exercises_categories_links","indexes":[{"name":"exercises_categories_links_fk","columns":["exercise_id"]},{"name":"exercises_categories_links_inv_fk","columns":["category_id"]},{"name":"exercises_categories_links_unique","columns":["exercise_id","category_id"],"type":"unique"},{"name":"exercises_categories_links_order_fk","columns":["category_order"]},{"name":"exercises_categories_links_order_inv_fk","columns":["exercise_order"]}],"foreignKeys":[{"name":"exercises_categories_links_fk","columns":["exercise_id"],"referencedColumns":["id"],"referencedTable":"exercises","onDelete":"CASCADE"},{"name":"exercises_categories_links_inv_fk","columns":["category_id"],"referencedColumns":["id"],"referencedTable":"categories","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"exercise_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"category_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"category_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"exercise_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"workouts_components","indexes":[{"name":"workouts_field_index","columns":["field"],"type":null},{"name":"workouts_component_type_index","columns":["component_type"],"type":null},{"name":"workouts_entity_fk","columns":["entity_id"]},{"name":"workouts_unique","columns":["entity_id","component_id","field","component_type"],"type":"unique"}],"foreignKeys":[{"name":"workouts_entity_fk","columns":["entity_id"],"referencedColumns":["id"],"referencedTable":"workouts","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"entity_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"components_exercises_descriptions_components","indexes":[{"name":"components_exercises_descriptions_field_index","columns":["field"],"type":null},{"name":"components_exercises_descriptions_component_type_index","columns":["component_type"],"type":null},{"name":"components_exercises_descriptions_entity_fk","columns":["entity_id"]},{"name":"components_exercises_descriptions_unique","columns":["entity_id","component_id","field","component_type"],"type":"unique"}],"foreignKeys":[{"name":"components_exercises_descriptions_entity_fk","columns":["entity_id"],"referencedColumns":["id"],"referencedTable":"components_exercises_descriptions","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"entity_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"components_exercises_progressions_components","indexes":[{"name":"components_exercises_progressions_field_index","columns":["field"],"type":null},{"name":"components_exercises_progressions_component_type_index","columns":["component_type"],"type":null},{"name":"components_exercises_progressions_entity_fk","columns":["entity_id"]},{"name":"components_exercises_progressions_unique","columns":["entity_id","component_id","field","component_type"],"type":"unique"}],"foreignKeys":[{"name":"components_exercises_progressions_entity_fk","columns":["entity_id"],"referencedColumns":["id"],"referencedTable":"components_exercises_progressions","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"entity_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"components_exercises_steps_components","indexes":[{"name":"components_exercises_steps_field_index","columns":["field"],"type":null},{"name":"components_exercises_steps_component_type_index","columns":["component_type"],"type":null},{"name":"components_exercises_steps_entity_fk","columns":["entity_id"]},{"name":"components_exercises_steps_unique","columns":["entity_id","component_id","field","component_type"],"type":"unique"}],"foreignKeys":[{"name":"components_exercises_steps_entity_fk","columns":["entity_id"],"referencedColumns":["id"],"referencedTable":"components_exercises_steps","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"entity_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"components_workout_days_components","indexes":[{"name":"components_workout_days_field_index","columns":["field"],"type":null},{"name":"components_workout_days_component_type_index","columns":["component_type"],"type":null},{"name":"components_workout_days_entity_fk","columns":["entity_id"]},{"name":"components_workout_days_unique","columns":["entity_id","component_id","field","component_type"],"type":"unique"}],"foreignKeys":[{"name":"components_workout_days_entity_fk","columns":["entity_id"],"referencedColumns":["id"],"referencedTable":"components_workout_days","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"entity_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"components_workout_exercises_exercise_links","indexes":[{"name":"components_workout_exercises_exercise_links_fk","columns":["exercise_id"]},{"name":"components_workout_exercises_exercise_links_inv_fk","columns":["inv_exercise_id"]},{"name":"components_workout_exercises_exercise_links_unique","columns":["exercise_id","inv_exercise_id"],"type":"unique"}],"foreignKeys":[{"name":"components_workout_exercises_exercise_links_fk","columns":["exercise_id"],"referencedColumns":["id"],"referencedTable":"components_workout_exercises","onDelete":"CASCADE"},{"name":"components_workout_exercises_exercise_links_inv_fk","columns":["inv_exercise_id"],"referencedColumns":["id"],"referencedTable":"exercises","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"exercise_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"inv_exercise_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]}]}', '2023-02-26 12:23:17.756', '42ae4fa80c35b1fce7889220186d3305');

INSERT INTO "public"."up_permissions" ("id", "action", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(1, 'plugin::users-permissions.user.me', '2023-02-02 14:47:03.527', '2023-02-02 14:47:03.527', NULL, NULL),
(2, 'plugin::users-permissions.auth.changePassword', '2023-02-02 14:47:03.527', '2023-02-02 14:47:03.527', NULL, NULL),
(3, 'plugin::users-permissions.auth.forgotPassword', '2023-02-02 14:47:03.548', '2023-02-02 14:47:03.548', NULL, NULL),
(4, 'plugin::users-permissions.auth.sendEmailConfirmation', '2023-02-02 14:47:03.548', '2023-02-02 14:47:03.548', NULL, NULL),
(5, 'plugin::users-permissions.auth.callback', '2023-02-02 14:47:03.548', '2023-02-02 14:47:03.548', NULL, NULL),
(6, 'plugin::users-permissions.auth.emailConfirmation', '2023-02-02 14:47:03.548', '2023-02-02 14:47:03.548', NULL, NULL),
(7, 'plugin::users-permissions.auth.resetPassword', '2023-02-02 14:47:03.548', '2023-02-02 14:47:03.548', NULL, NULL),
(8, 'plugin::users-permissions.auth.register', '2023-02-02 14:47:03.548', '2023-02-02 14:47:03.548', NULL, NULL),
(9, 'plugin::users-permissions.auth.connect', '2023-02-02 14:47:03.548', '2023-02-02 14:47:03.548', NULL, NULL),
(10, 'api::category.category.findOne', '2023-02-02 15:34:21.938', '2023-02-02 15:34:21.938', NULL, NULL),
(11, 'api::category.category.find', '2023-02-02 15:34:21.938', '2023-02-02 15:34:21.938', NULL, NULL),
(12, 'api::exercise.exercise.find', '2023-02-02 15:34:21.938', '2023-02-02 15:34:21.938', NULL, NULL),
(13, 'api::exercise.exercise.findOne', '2023-02-02 15:34:21.938', '2023-02-02 15:34:21.938', NULL, NULL),
(14, 'api::workout.workout.find', '2023-02-02 15:34:21.938', '2023-02-02 15:34:21.938', NULL, NULL),
(15, 'api::workout.workout.findOne', '2023-02-02 15:34:21.938', '2023-02-02 15:34:21.938', NULL, NULL),
(16, 'plugin::upload.content-api.find', '2023-02-02 15:34:21.938', '2023-02-02 15:34:21.938', NULL, NULL),
(17, 'plugin::upload.content-api.findOne', '2023-02-02 15:34:21.938', '2023-02-02 15:34:21.938', NULL, NULL),
(18, 'api::category.category.find', '2023-02-02 15:37:14.592', '2023-02-02 15:37:14.592', NULL, NULL),
(19, 'api::category.category.findOne', '2023-02-02 15:37:14.592', '2023-02-02 15:37:14.592', NULL, NULL),
(20, 'api::exercise.exercise.find', '2023-02-02 15:37:14.592', '2023-02-02 15:37:14.592', NULL, NULL),
(21, 'api::exercise.exercise.findOne', '2023-02-02 15:37:14.592', '2023-02-02 15:37:14.592', NULL, NULL),
(22, 'api::workout.workout.find', '2023-02-02 15:37:14.592', '2023-02-02 15:37:14.592', NULL, NULL),
(23, 'api::workout.workout.findOne', '2023-02-02 15:37:14.592', '2023-02-02 15:37:14.592', NULL, NULL),
(24, 'plugin::upload.content-api.findOne', '2023-02-02 15:37:14.592', '2023-02-02 15:37:14.592', NULL, NULL),
(25, 'plugin::upload.content-api.find', '2023-02-02 15:37:14.592', '2023-02-02 15:37:14.592', NULL, NULL);

INSERT INTO "public"."up_permissions_role_links" ("id", "permission_id", "role_id", "permission_order") VALUES
(1, 1, 1, 1),
(2, 2, 1, 1),
(3, 7, 2, 1),
(4, 3, 2, 1),
(5, 6, 2, 1),
(6, 9, 2, 1),
(7, 5, 2, 1),
(8, 4, 2, 1),
(9, 8, 2, 1),
(10, 12, 2, 2),
(11, 13, 2, 2),
(12, 10, 2, 2),
(13, 16, 2, 2),
(14, 14, 2, 2),
(15, 11, 2, 2),
(16, 15, 2, 3),
(17, 17, 2, 3),
(18, 18, 1, 2),
(19, 19, 1, 2),
(20, 20, 1, 2),
(21, 21, 1, 3),
(22, 22, 1, 3),
(23, 24, 1, 3),
(24, 23, 1, 3),
(25, 25, 1, 3);

INSERT INTO "public"."up_roles" ("id", "name", "description", "type", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(1, 'Authenticated', 'Default role given to authenticated user.', 'authenticated', '2023-02-02 14:47:03.506', '2023-02-02 15:37:14.581', NULL, NULL),
(2, 'Public', 'Default role given to unauthenticated user.', 'public', '2023-02-02 14:47:03.515', '2023-02-02 15:37:38.858', NULL, NULL);

INSERT INTO "public"."up_users" ("id", "username", "email", "provider", "password", "reset_password_token", "confirmation_token", "confirmed", "blocked", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(1, 'volkmann.magnus', 'volkmann.magnus@gmail.com', 'google', NULL, NULL, NULL, 't', 'f', '2023-02-02 15:30:56.877', '2023-02-02 15:30:56.877', NULL, NULL),
(2, 'mrpitch', 'mrpitch@outlook.com', 'github', NULL, NULL, NULL, 't', 'f', '2023-02-02 15:31:35.702', '2023-02-02 15:31:35.702', NULL, NULL);

INSERT INTO "public"."up_users_role_links" ("id", "user_id", "role_id", "user_order") VALUES
(1, 1, 1, 1),
(2, 2, 1, 2);

INSERT INTO "public"."upload_folders" ("id", "name", "path_id", "path", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(1, 'Exercises', 1, '/1', NULL, NULL, 1, 1);

INSERT INTO "public"."workouts" ("id", "title", "slug", "created_at", "updated_at", "published_at", "created_by_id", "updated_by_id") VALUES
(1, 'Hang the Banner - Week 1', 'hang-the-banner-week-1', '2023-02-02 15:25:40.702', '2023-02-02 15:40:50.349', '2023-02-02 15:40:50.342', 1, 1),
(2, 'Hang the Banner - Week 2', 'hang-the-banner-week-2', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, NULL),
(3, 'Hang the Banner - Week 3', 'hang-the-banner-week-3', '2023-02-02 15:25:40.702', '2023-02-02 15:41:18.904', '2023-02-02 15:41:18.897', 1, 1),
(4, 'Hang the Banner - Week 4', 'hang-the-banner-week-4', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', '2023-02-02 15:25:40.702', 1, NULL);

INSERT INTO "public"."workouts_components" ("id", "entity_id", "component_id", "component_type", "field", "order") VALUES
(39, 1, 1, 'workout.day', 'day', 1),
(40, 1, 2, 'workout.day', 'day', 2),
(41, 1, 3, 'workout.day', 'day', 3),
(45, 3, 7, 'workout.day', 'day', 1),
(46, 3, 8, 'workout.day', 'day', 2),
(47, 3, 9, 'workout.day', 'day', 3),
(51, 4, 10, 'workout.day', 'day', 1),
(52, 4, 11, 'workout.day', 'day', 2),
(53, 4, 12, 'workout.day', 'day', 3),
(54, 2, 4, 'workout.day', 'day', 1),
(55, 2, 5, 'workout.day', 'day', 2),
(56, 2, 6, 'workout.day', 'day', 3);

ALTER TABLE "public"."admin_permissions" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."admin_permissions" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."admin_permissions_role_links" ADD FOREIGN KEY ("permission_id") REFERENCES "public"."admin_permissions"("id") ON DELETE CASCADE;
ALTER TABLE "public"."admin_permissions_role_links" ADD FOREIGN KEY ("role_id") REFERENCES "public"."admin_roles"("id") ON DELETE CASCADE;
ALTER TABLE "public"."admin_roles" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."admin_roles" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."admin_users" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."admin_users" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."admin_users_roles_links" ADD FOREIGN KEY ("role_id") REFERENCES "public"."admin_roles"("id") ON DELETE CASCADE;
ALTER TABLE "public"."admin_users_roles_links" ADD FOREIGN KEY ("user_id") REFERENCES "public"."admin_users"("id") ON DELETE CASCADE;
ALTER TABLE "public"."categories" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."categories" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."components_exercises_descriptions_components" ADD FOREIGN KEY ("entity_id") REFERENCES "public"."components_exercises_descriptions"("id") ON DELETE CASCADE;
ALTER TABLE "public"."components_exercises_progressions_components" ADD FOREIGN KEY ("entity_id") REFERENCES "public"."components_exercises_progressions"("id") ON DELETE CASCADE;
ALTER TABLE "public"."components_exercises_steps_components" ADD FOREIGN KEY ("entity_id") REFERENCES "public"."components_exercises_steps"("id") ON DELETE CASCADE;
ALTER TABLE "public"."components_workout_days_components" ADD FOREIGN KEY ("entity_id") REFERENCES "public"."components_workout_days"("id") ON DELETE CASCADE;
ALTER TABLE "public"."components_workout_exercises_exercise_links" ADD FOREIGN KEY ("exercise_id") REFERENCES "public"."components_workout_exercises"("id") ON DELETE CASCADE;
ALTER TABLE "public"."components_workout_exercises_exercise_links" ADD FOREIGN KEY ("inv_exercise_id") REFERENCES "public"."exercises"("id") ON DELETE CASCADE;
ALTER TABLE "public"."exercises" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."exercises" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."exercises_categories_links" ADD FOREIGN KEY ("exercise_id") REFERENCES "public"."exercises"("id") ON DELETE CASCADE;
ALTER TABLE "public"."exercises_categories_links" ADD FOREIGN KEY ("category_id") REFERENCES "public"."categories"("id") ON DELETE CASCADE;
ALTER TABLE "public"."exercises_components" ADD FOREIGN KEY ("entity_id") REFERENCES "public"."exercises"("id") ON DELETE CASCADE;
ALTER TABLE "public"."files" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."files" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."files_folder_links" ADD FOREIGN KEY ("file_id") REFERENCES "public"."files"("id") ON DELETE CASCADE;
ALTER TABLE "public"."files_folder_links" ADD FOREIGN KEY ("folder_id") REFERENCES "public"."upload_folders"("id") ON DELETE CASCADE;
ALTER TABLE "public"."files_related_morphs" ADD FOREIGN KEY ("file_id") REFERENCES "public"."files"("id") ON DELETE CASCADE;
ALTER TABLE "public"."i18n_locale" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."i18n_locale" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."strapi_api_token_permissions" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."strapi_api_token_permissions" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."strapi_api_token_permissions_token_links" ADD FOREIGN KEY ("api_token_permission_id") REFERENCES "public"."strapi_api_token_permissions"("id") ON DELETE CASCADE;
ALTER TABLE "public"."strapi_api_token_permissions_token_links" ADD FOREIGN KEY ("api_token_id") REFERENCES "public"."strapi_api_tokens"("id") ON DELETE CASCADE;
ALTER TABLE "public"."strapi_api_tokens" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."strapi_api_tokens" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."up_permissions" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."up_permissions" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."up_permissions_role_links" ADD FOREIGN KEY ("role_id") REFERENCES "public"."up_roles"("id") ON DELETE CASCADE;
ALTER TABLE "public"."up_permissions_role_links" ADD FOREIGN KEY ("permission_id") REFERENCES "public"."up_permissions"("id") ON DELETE CASCADE;
ALTER TABLE "public"."up_roles" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."up_roles" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."up_users" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."up_users" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."up_users_role_links" ADD FOREIGN KEY ("user_id") REFERENCES "public"."up_users"("id") ON DELETE CASCADE;
ALTER TABLE "public"."up_users_role_links" ADD FOREIGN KEY ("role_id") REFERENCES "public"."up_roles"("id") ON DELETE CASCADE;
ALTER TABLE "public"."upload_folders" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."upload_folders" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."upload_folders_parent_links" ADD FOREIGN KEY ("folder_id") REFERENCES "public"."upload_folders"("id") ON DELETE CASCADE;
ALTER TABLE "public"."upload_folders_parent_links" ADD FOREIGN KEY ("inv_folder_id") REFERENCES "public"."upload_folders"("id") ON DELETE CASCADE;
ALTER TABLE "public"."workouts" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."workouts" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."workouts_components" ADD FOREIGN KEY ("entity_id") REFERENCES "public"."workouts"("id") ON DELETE CASCADE;
